import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sprout,
  Calendar,
  Droplets,
  FlaskConical,
  ShieldAlert,
  Volume2,
  VolumeX,
  X,
  CheckCircle2,
  Clock,
  ArrowRight,
  Sparkles,
  Layers,
  ChevronRight,
  Sun,
  Activity,
  Scan,
  Mic,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DEFAULT_CROP_LIFECYCLE_STAGES } from '../data/mockAgriData';
import { CropLifecycleStage } from '../types';

export const CropLifecycleModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    openModal,
    language,
    crops,
    farmer,
    speakText,
    isSpeaking,
    stopSpeaking,
  } = useApp();

  const [selectedStageIndex, setSelectedStageIndex] = useState<number>(2); // Default to current stage (Growth)
  const [stages, setStages] = useState<CropLifecycleStage[]>(DEFAULT_CROP_LIFECYCLE_STAGES);
  const [isAudioActive, setIsAudioActive] = useState<boolean>(false);

  const isOpen = activeModal === 'cropLifecycle' || activeModal === 'cropDetail';
  if (!isOpen) return null;

  const currentCrop = crops[0] || {
    name: 'Soybean (फुले संगम KDS-726)',
    variety: 'KDS-726',
    plotSizeAcres: 4.5,
    sowingDate: '15 June 2026',
    harvestDate: '15 October 2026',
    stage: 'Vegetative',
    progressPercentage: 42,
  };

  const selectedStage = stages[selectedStageIndex] || stages[0];

  const getStageTitle = (stage: CropLifecycleStage) => {
    switch (language) {
      case 'mr':
        return stage.nameMr;
      case 'hi':
        return stage.nameHi;
      case 'en':
      default:
        return stage.nameEn;
    }
  };

  const getStageDesc = (stage: CropLifecycleStage) => {
    switch (language) {
      case 'mr':
        return stage.descriptionMr;
      case 'hi':
        return stage.descriptionHi;
      case 'en':
      default:
        return stage.descriptionEn;
    }
  };

  const handleSpeakStage = () => {
    if (isSpeaking && isAudioActive) {
      stopSpeaking();
      setIsAudioActive(false);
      return;
    }

    setIsAudioActive(true);
    let speech = '';
    const stageTitle = getStageTitle(selectedStage);
    const stageDesc = getStageDesc(selectedStage);

    if (language === 'mr') {
      speech = `पीक अवस्था क्रमांक ${selectedStage.stageNumber}: ${stageTitle}. ${stageDesc}. मुख्य कामे: ${selectedStage.keyActions.join('. ')}. पाणी व्यवस्थापन: ${selectedStage.waterRequirement}. खत व्यवस्थापन: ${selectedStage.fertilizerSchedule}.`;
    } else if (language === 'hi') {
      speech = `फसल अवस्था चरण ${selectedStage.stageNumber}: ${stageTitle}. ${stageDesc}. मुख्य कार्य: ${selectedStage.keyActions.join('. ')}. जल प्रबंधन: ${selectedStage.waterRequirement}. खाद प्रबंधन: ${selectedStage.fertilizerSchedule}.`;
    } else {
      speech = `Crop stage number ${selectedStage.stageNumber}: ${stageTitle}. ${stageDesc}. Key actions: ${selectedStage.keyActions.join('. ')}. Irrigation schedule: ${selectedStage.waterRequirement}. Fertilizer dosage: ${selectedStage.fertilizerSchedule}.`;
    }

    speakText(speech, language);
  };

  return (
    <div
      id="crop-lifecycle-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-emerald-950/80 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-5xl max-h-[92vh] rounded-3xl bg-white dark:bg-[#072418] border border-emerald-500/30 shadow-2xl flex flex-col overflow-hidden text-zinc-900 dark:text-white"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-emerald-500/20 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-100/50 dark:from-emerald-950 dark:via-[#072b1d] dark:to-emerald-950 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-white flex items-center justify-center shadow-lg shadow-emerald-500/25">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-white font-outfit">
                  {language === 'mr'
                    ? '🌾 पीक जीवनचक्र व वाढ अवस्था सल्ला'
                    : language === 'hi'
                    ? '🌾 फसल जीवन चक्र व वृद्धि सलाह'
                    : '🌾 Crop Lifecycle & Growth Advisory'}
                </h3>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                  {currentCrop.name}
                </span>
              </div>
              <p className="text-xs text-emerald-700/80 dark:text-emerald-400/80 font-medium">
                {farmer.district}, {farmer.state} • {currentCrop.plotSizeAcres} Acres • Day 34 of 110
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSpeakStage}
              className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer shadow-sm ${
                isSpeaking && isAudioActive
                  ? 'bg-amber-400 text-emerald-950 animate-pulse'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white'
              }`}
            >
              {isSpeaking && isAudioActive ? (
                <>
                  <VolumeX className="w-4 h-4" />
                  <span>{language === 'mr' ? 'थांबवा' : 'Stop'}</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4" />
                  <span>{language === 'mr' ? '🔊 सल्ला ऐका' : '🔊 Listen Voice'}</span>
                </>
              )}
            </button>

            <button
              onClick={closeModal}
              className="p-2 rounded-xl bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 text-zinc-700 dark:text-zinc-200 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Progress Bar & Growth Stage Strip */}
          <div className="p-4 sm:p-5 rounded-3xl bg-emerald-50/60 dark:bg-emerald-950/40 border border-emerald-500/20 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider">
                {language === 'mr' ? 'पिकाचा एकूण प्रवास (६ टप्पे)' : 'Crop Growth Stages (6 Key Milestones)'}
              </span>
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                ४२% पूर्ण (Day 34 / 110)
              </span>
            </div>

            {/* Stage Selector Pills */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
              {stages.map((stage, idx) => {
                const isSelected = selectedStageIndex === idx;
                const isCompleted = stage.status === 'Completed';
                const isCurrent = stage.status === 'Current';

                return (
                  <button
                    key={stage.id}
                    onClick={() => setSelectedStageIndex(idx)}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between min-h-[90px] ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-400 shadow-md ring-2 ring-emerald-400/50'
                        : isCurrent
                        ? 'bg-emerald-500/20 dark:bg-emerald-900/40 border-emerald-400 text-emerald-950 dark:text-white'
                        : isCompleted
                        ? 'bg-emerald-100/50 dark:bg-emerald-950/30 border-emerald-500/20 text-zinc-700 dark:text-zinc-300'
                        : 'bg-white dark:bg-emerald-950/20 border-zinc-200 dark:border-white/10 text-zinc-500 dark:text-zinc-400'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-lg">{stage.icon}</span>
                      {isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 dark:text-emerald-300" />
                      ) : isCurrent ? (
                        <span className="px-1.5 py-0.5 rounded-full bg-amber-400 text-emerald-950 text-[9px] font-black animate-pulse">
                          सध्या (Now)
                        </span>
                      ) : (
                        <Clock className="w-3.5 h-3.5 opacity-60" />
                      )}
                    </div>

                    <div>
                      <span className="text-[10px] opacity-75 font-mono block">
                        Step {stage.stageNumber}
                      </span>
                      <h5 className="text-xs font-bold truncate mt-0.5">
                        {getStageTitle(stage).split('(')[0].trim()}
                      </h5>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Stage Detailed Card */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Left 2 Cols: Detailed Agronomic Actions */}
            <div className="lg:col-span-2 space-y-4">
              {/* Stage Overview Banner */}
              <div className="p-5 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/25 space-y-3 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{selectedStage.icon}</span>
                      <h4 className="text-lg font-black text-emerald-950 dark:text-white font-outfit">
                        {getStageTitle(selectedStage)}
                      </h4>
                    </div>
                    <p className="text-xs text-emerald-700 dark:text-emerald-400 font-bold">
                      {selectedStage.currentDayRange} • {selectedStage.durationRangeDays}
                    </p>
                  </div>

                  <span
                    className={`px-3 py-1 rounded-full text-xs font-black shrink-0 ${
                      selectedStage.status === 'Completed'
                        ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-300'
                        : selectedStage.status === 'Current'
                        ? 'bg-amber-400/20 text-amber-600 dark:text-amber-300 border border-amber-400/40'
                        : 'bg-zinc-500/20 text-zinc-500 dark:text-zinc-400'
                    }`}
                  >
                    {selectedStage.status}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-zinc-700 dark:text-emerald-100/90 leading-relaxed font-medium">
                  {getStageDesc(selectedStage)}
                </p>
              </div>

              {/* Key Action Checklist for this Stage */}
              <div className="p-5 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/25 space-y-3 shadow-sm">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-500" />
                  <h5 className="text-sm font-bold text-emerald-950 dark:text-white font-outfit">
                    {language === 'mr'
                      ? 'या टप्प्यासाठी आवश्यक शेती कामे (Key Actions)'
                      : language === 'hi'
                      ? 'इस अवस्था के जरूरी कृषि कार्य'
                      : 'Essential Agronomic Tasks for this Stage'}
                  </h5>
                </div>

                <div className="space-y-2">
                  {selectedStage.keyActions.map((act, i) => (
                    <div
                      key={i}
                      className="p-3 rounded-2xl bg-emerald-50/50 dark:bg-emerald-900/30 border border-emerald-500/15 flex items-start gap-3 text-xs text-zinc-800 dark:text-emerald-100 font-medium"
                    >
                      <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-black">
                        {i + 1}
                      </div>
                      <span className="leading-relaxed">{act}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Col: Water, Fertilizer, and Pest Protocols */}
            <div className="space-y-4">
              {/* Irrigation Schedule */}
              <div className="p-4 rounded-3xl bg-sky-50/70 dark:bg-sky-950/30 border border-sky-500/30 space-y-2">
                <div className="flex items-center gap-2 text-sky-700 dark:text-sky-300">
                  <Droplets className="w-4 h-4" />
                  <h6 className="text-xs font-bold uppercase tracking-wider">
                    {language === 'mr' ? 'पाणी व सिंचन वेळापत्रक' : 'Water & Irrigation'}
                  </h6>
                </div>
                <p className="text-xs text-zinc-800 dark:text-sky-100 font-medium leading-relaxed">
                  {selectedStage.waterRequirement}
                </p>
              </div>

              {/* Fertilizer & NPK Dosage */}
              <div className="p-4 rounded-3xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-500/30 space-y-2">
                <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-300">
                  <FlaskConical className="w-4 h-4" />
                  <h6 className="text-xs font-bold uppercase tracking-wider">
                    {language === 'mr' ? 'खतांचे प्रमाण व डोस' : 'Fertilizer & NPK Dosage'}
                  </h6>
                </div>
                <p className="text-xs text-zinc-800 dark:text-emerald-100 font-medium leading-relaxed">
                  {selectedStage.fertilizerSchedule}
                </p>
              </div>

              {/* Pest & Disease Prevention */}
              <div className="p-4 rounded-3xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-500/30 space-y-2">
                <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300">
                  <ShieldAlert className="w-4 h-4" />
                  <h6 className="text-xs font-bold uppercase tracking-wider">
                    {language === 'mr' ? 'कीड व रोग प्रतिबंधक उपाय' : 'Pest & Disease Prevention'}
                  </h6>
                </div>
                <p className="text-xs text-zinc-800 dark:text-amber-100 font-medium leading-relaxed">
                  {selectedStage.pestPrevention}
                </p>
              </div>

              {/* Quick AI Advisor / Disease Scanner action triggers */}
              <div className="p-4 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white space-y-3 shadow-md">
                <div className="space-y-1">
                  <h6 className="text-xs font-black uppercase tracking-wider">
                    {language === 'mr' ? 'झाडावर रोग किंवा कीड दिसतेय?' : 'Pest or Disease Detected?'}
                  </h6>
                  <p className="text-[11px] text-emerald-100 leading-snug">
                    {language === 'mr'
                      ? 'पानाचा फोटो काढा किंवा AI ला थेट विचारा.'
                      : 'Take a leaf photo or speak directly with AI Agronomist.'}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      closeModal();
                      openModal('diagnose');
                    }}
                    className="px-2.5 py-2 rounded-xl bg-white text-emerald-900 font-black text-xs flex items-center justify-center gap-1.5 shadow hover:bg-emerald-50 transition-all cursor-pointer"
                  >
                    <Scan className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{language === 'mr' ? 'फोटो तपासा' : 'Diagnose'}</span>
                  </button>

                  <button
                    onClick={() => {
                      closeModal();
                      openModal('askAi');
                    }}
                    className="px-2.5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow transition-all cursor-pointer border border-emerald-400/30"
                  >
                    <Mic className="w-3.5 h-3.5 text-amber-300" />
                    <span>{language === 'mr' ? 'बोलून विचारा' : 'Ask AI'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
