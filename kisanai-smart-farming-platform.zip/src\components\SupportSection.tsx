import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Phone,
  Mail,
  MessageSquare,
  MapPin,
  Headphones,
  CheckCircle,
  Sparkles,
  Send,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const SupportSection: React.FC = () => {
  const { openModal } = useApp();
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="support" className="py-16 sm:py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 text-xs font-semibold">
            <Headphones className="w-4 h-4 text-emerald-500" />
            <span>Kisan Mitra Helpdesk & Field Agronomists</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-emerald-950 dark:text-white font-outfit tracking-tight">
            We’re Standing by to Assist Every Farmer
          </h2>

          <p className="text-base text-zinc-600 dark:text-zinc-300">
            Have questions about plant diseases, soil testing kits, or app usage? Connect with our team 24/7.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Contact Direct Cards */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-6 rounded-3xl bg-white/90 dark:bg-emerald-950/60 border border-emerald-500/20 shadow-lg space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md">
                <Phone className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-emerald-950 dark:text-white font-outfit">
                Kisan Toll-Free Helpline
              </h4>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Direct toll-free telephonic advisory with senior agricultural scientists in your local language.
              </p>
              <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                1800-180-1551
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-white/90 dark:bg-emerald-950/60 border border-emerald-500/20 shadow-lg space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-teal-600 text-white flex items-center justify-center shadow-md">
                <MessageSquare className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-emerald-950 dark:text-white font-outfit">
                Instant WhatsApp Agri-Bot
              </h4>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Send leaf photos on WhatsApp to receive instant remedy instructions in seconds.
              </p>
              <button
                onClick={() => openModal('askAi')}
                className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:underline cursor-pointer"
              >
                +91 94231 88000 (Click to Launch AI Chat)
              </button>
            </div>
          </div>

          {/* Quick Query Form */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-3xl bg-white/90 dark:bg-emerald-950/60 backdrop-blur-xl border border-emerald-500/30 shadow-2xl space-y-5">
              <h3 className="text-xl font-bold text-emerald-950 dark:text-white font-outfit">
                Request Agronomist Call-back
              </h3>

              {submitted ? (
                <div className="p-6 rounded-2xl bg-emerald-500/20 text-emerald-900 dark:text-emerald-100 text-center space-y-2">
                  <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto" />
                  <h4 className="text-base font-bold">Request Received!</h4>
                  <p className="text-xs text-zinc-600 dark:text-zinc-300">
                    A KisanAI agronomist from your district Krishi Vigyan Kendra will contact you within 2 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1">
                        Farmer Full Name
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Ramesh Patel"
                        className="w-full px-4 py-2.5 rounded-xl bg-emerald-50/50 dark:bg-emerald-900/30 border border-emerald-500/20 text-xs text-emerald-950 dark:text-emerald-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1">
                        WhatsApp / Mobile Number
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="e.g. 9823456789"
                        className="w-full px-4 py-2.5 rounded-xl bg-emerald-50/50 dark:bg-emerald-900/30 border border-emerald-500/20 text-xs text-emerald-950 dark:text-emerald-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1">
                      Farm Issue / Query Details
                    </label>
                    <textarea
                      rows={3}
                      required
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Describe your crop condition, leaf spots, or mandi questions..."
                      className="w-full p-3 rounded-xl bg-emerald-50/50 dark:bg-emerald-900/30 border border-emerald-500/20 text-xs text-emerald-950 dark:text-emerald-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Submit Query to Agronomist</span>
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
