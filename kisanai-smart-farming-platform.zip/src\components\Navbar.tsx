import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sprout,
  Sun,
  Moon,
  Globe,
  User,
  Menu,
  X,
  ChevronDown,
  Sparkles,
  CheckCircle2,
  Mic,
  Scan,
  TrendingUp,
  CloudSun,
  LogOut,
  MapPin,
  Navigation,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { LiveMandiTicker } from './LiveMandiTicker';
import { SUPPORTED_LANGUAGES } from '../data/mockAgriData';
import { LanguageCode } from '../types';
import { KisanLogo } from './KisanLogo';

export const Navbar: React.FC = () => {
  const {
    theme,
    toggleTheme,
    language,
    setLanguage,
    appMode,
    setAppMode,
    activeTab,
    setActiveTab,
    openModal,
    farmer,
    isLoggedIn,
    logoutFarmer,
    t,
  } = useApp();

  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);

  const currentLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setIsLangOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems = [
    { id: 'home', label: t('navHome') },
    { id: 'features', label: t('navFeatures') },
    { id: 'about', label: t('navAbout') },
    { id: 'support', label: t('navSupport') },
  ];

  return (
    <header
      id="main-navbar"
      className="sticky top-0 z-50 w-full transition-all duration-300 backdrop-blur-xl bg-white/80 dark:bg-emerald-950/85 border-b border-emerald-900/10 dark:border-emerald-500/20 shadow-xs"
    >
      <LiveMandiTicker />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <div
            id="brand-logo-btn"
            onClick={() => setActiveTab('home')}
            className="cursor-pointer group select-none"
          >
            <KisanLogo size="md" animate={true} />
          </div>

          {/* Desktop Navigation Links */}
          <nav id="desktop-nav" className="hidden md:flex items-center gap-1 bg-emerald-50/60 dark:bg-emerald-900/30 p-1.5 rounded-full border border-emerald-500/15">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`relative px-4 py-2 text-sm font-semibold rounded-full transition-all duration-200 whitespace-nowrap ${
                    isActive
                      ? 'text-emerald-950 dark:text-white'
                      : 'text-emerald-800/80 dark:text-emerald-200/70 hover:text-emerald-950 dark:hover:text-white hover:bg-emerald-100/50 dark:hover:bg-emerald-800/30'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeNavPill"
                      className="absolute inset-0 bg-white dark:bg-emerald-700/80 rounded-full shadow-xs border border-emerald-500/20"
                      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Actions & Utilities */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Direct Google Maps GPS Tracker Button */}
            <button
              id="navbar-gps-tracker-btn"
              onClick={() => openModal('gpsTracker')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-gradient-to-r from-teal-500/20 to-emerald-500/20 text-emerald-800 dark:text-emerald-200 border border-emerald-500/30 hover:bg-emerald-500/30 transition-all cursor-pointer shadow-2xs"
              title="Open Live GPS & Google Map Tracker"
            >
              <Navigation className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
              <span className="hidden md:inline font-black">GPS Map</span>
            </button>

            {/* Farmer Mode Toggle / Switcher */}
            <button
              id="navbar-farmer-mode-btn"
              onClick={() => setAppMode(appMode === 'farmer' ? 'pro' : 'farmer')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition-all cursor-pointer border ${
                appMode === 'farmer'
                  ? 'bg-emerald-600 text-white border-emerald-400/50 shadow-md ring-2 ring-emerald-400/30'
                  : 'bg-emerald-50 dark:bg-emerald-900/40 text-emerald-900 dark:text-emerald-100 border-emerald-500/20 hover:border-emerald-500/50'
              }`}
              title="Toggle Farmer Mode / Pro Dashboard"
            >
              <span>🌾</span>
              <span className="hidden sm:inline">
                {appMode === 'farmer' ? t('farmerMode') : t('proMode')}
              </span>
            </button>

            {/* Language Selector Dropdown */}
            <div className="relative" ref={langRef}>
              <button
                id="language-selector-btn"
                onClick={() => setIsLangOpen(!isLangOpen)}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl bg-emerald-50 dark:bg-emerald-900/40 text-emerald-900 dark:text-emerald-100 border border-emerald-500/20 hover:border-emerald-500/40 transition-colors shadow-2xs"
                title="Change Language"
              >
                <Globe className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span className="hidden sm:inline">{currentLangObj.nativeName}</span>
                <span className="sm:hidden">{currentLangObj.flag}</span>
                <ChevronDown className="w-3 h-3 text-emerald-600/70 dark:text-emerald-400/70" />
              </button>

              <AnimatePresence>
                {isLangOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 mt-2 w-48 rounded-2xl bg-white dark:bg-emerald-950 border border-emerald-500/20 shadow-xl shadow-emerald-950/15 py-2 z-50 overflow-hidden"
                  >
                    <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-emerald-700/60 dark:text-emerald-400/60">
                      Select Farm Language
                    </div>
                    <div className="max-h-64 overflow-y-auto">
                      {SUPPORTED_LANGUAGES.map((lang) => {
                        const isSelected = language === lang.code;
                        return (
                          <button
                            key={lang.code}
                            id={`lang-option-${lang.code}`}
                            onClick={() => {
                              setLanguage(lang.code);
                              setIsLangOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 text-xs text-left transition-colors ${
                              isSelected
                                ? 'bg-emerald-500/15 text-emerald-900 dark:text-emerald-100 font-bold'
                                : 'text-zinc-700 dark:text-zinc-300 hover:bg-emerald-50 dark:hover:bg-emerald-900/30'
                            }`}
                          >
                            <span className="flex items-center gap-2">
                              <span>{lang.flag}</span>
                              <span>{lang.nativeName}</span>
                              <span className="text-[10px] text-zinc-500 dark:text-zinc-400">({lang.name})</span>
                            </span>
                            {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />}
                          </button>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Dark / Light Mode Toggle */}
            <button
              id="theme-toggle-btn"
              onClick={toggleTheme}
              className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-900/40 text-emerald-900 dark:text-emerald-100 border border-emerald-500/20 hover:border-emerald-500/40 transition-colors shadow-2xs"
              aria-label="Toggle Dark Mode"
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400 hover:rotate-45 transition-transform" />
              ) : (
                <Moon className="w-4 h-4 text-emerald-700 hover:-rotate-12 transition-transform" />
              )}
            </button>

            {/* Farmer Profile / Logout / Login Button */}
            {isLoggedIn ? (
              <div className="flex items-center gap-1.5">
                <button
                  id="farmer-profile-nav-btn"
                  onClick={() => setActiveTab('profile')}
                  className="flex items-center gap-2 pl-1.5 pr-3 py-1.5 rounded-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold text-xs shadow-md shadow-emerald-600/20 hover:from-emerald-500 hover:to-teal-500 transition-all cursor-pointer"
                >
                  <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-white font-bold text-[11px] overflow-hidden">
                    {farmer.avatarUrl ? (
                      <img src={farmer.avatarUrl} alt={farmer.name || farmer.fullName || 'User'} className="w-full h-full object-cover" />
                    ) : (
                      (farmer.fullName || farmer.name || 'श').charAt(0).toUpperCase()
                    )}
                  </div>
                  <span className="hidden sm:inline font-medium tracking-tight truncate max-w-[110px]">
                    {(farmer.fullName || farmer.name || 'शेतकरी').split(' ')[0]}
                  </span>
                  <span className="hidden lg:inline-block w-1.5 h-1.5 bg-emerald-300 rounded-full animate-ping" />
                </button>

                <button
                  id="navbar-logout-btn"
                  onClick={logoutFarmer}
                  className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/30 transition-all cursor-pointer"
                  title={language === 'mr' ? 'लॉगआउट करा' : 'Logout'}
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                id="farmer-login-nav-btn"
                onClick={() => openModal('login')}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-md shadow-emerald-600/25 transition-all cursor-pointer"
              >
                <User className="w-3.5 h-3.5" />
                <span>{t('farmerLogin')}</span>
              </button>
            )}

            {/* Mobile Hamburger Toggle */}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-xl bg-emerald-50 dark:bg-emerald-900/40 text-emerald-900 dark:text-emerald-100 border border-emerald-500/20"
              aria-label="Open mobile menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden border-b border-emerald-500/20 bg-white/95 dark:bg-emerald-950/95 backdrop-blur-xl px-4 pt-2 pb-6 space-y-3"
          >
            <div className="grid grid-cols-2 gap-2 pt-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  id={`mobile-nav-${item.id}`}
                  onClick={() => {
                    setActiveTab(item.id as any);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`px-4 py-3 rounded-xl text-left text-sm font-semibold transition-all ${
                    activeTab === item.id
                      ? 'bg-emerald-500/20 text-emerald-900 dark:text-emerald-100 border border-emerald-500/30'
                      : 'bg-emerald-50/50 dark:bg-emerald-900/20 text-emerald-800 dark:text-emerald-200'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Quick action shortcuts in drawer */}
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 space-y-2">
              <div className="text-xs font-bold text-emerald-900 dark:text-emerald-200">Quick Agri Tools</div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  id="mobile-quick-diagnose-btn"
                  onClick={() => {
                    openModal('diagnose');
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex items-center gap-2 p-2.5 rounded-xl bg-white dark:bg-emerald-900/40 text-xs font-medium text-emerald-900 dark:text-emerald-100 border border-emerald-500/20 shadow-2xs"
                >
                  <Scan className="w-4 h-4 text-emerald-500" />
                  <span>Diagnose Leaf</span>
                </button>
                <button
                  id="mobile-quick-askai-btn"
                  onClick={() => {
                    openModal('askAi');
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex items-center gap-2 p-2.5 rounded-xl bg-white dark:bg-emerald-900/40 text-xs font-medium text-emerald-900 dark:text-emerald-100 border border-emerald-500/20 shadow-2xs"
                >
                  <Mic className="w-4 h-4 text-purple-500" />
                  <span>Voice Q&A</span>
                </button>
                <button
                  id="mobile-quick-mandi-btn"
                  onClick={() => {
                    openModal('mandiPrices');
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex items-center gap-2 p-2.5 rounded-xl bg-white dark:bg-emerald-900/40 text-xs font-medium text-emerald-900 dark:text-emerald-100 border border-emerald-500/20 shadow-2xs"
                >
                  <TrendingUp className="w-4 h-4 text-amber-500" />
                  <span>Mandi Rates</span>
                </button>
                <button
                  id="mobile-quick-weather-btn"
                  onClick={() => {
                    openModal('weatherAdvisory');
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex items-center gap-2 p-2.5 rounded-xl bg-white dark:bg-emerald-900/40 text-xs font-medium text-emerald-900 dark:text-emerald-100 border border-emerald-500/20 shadow-2xs"
                >
                  <CloudSun className="w-4 h-4 text-sky-500" />
                  <span>Spray Advisory</span>
                </button>
              </div>
            </div>

            {isLoggedIn && (
              <button
                id="mobile-drawer-logout-btn"
                onClick={() => {
                  logoutFarmer();
                  setIsMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30 text-xs font-bold cursor-pointer hover:bg-rose-500/20 transition-all"
              >
                <LogOut className="w-4 h-4" />
                <span>{language === 'mr' ? 'लॉगआउट (Logout)' : 'Logout'}</span>
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
