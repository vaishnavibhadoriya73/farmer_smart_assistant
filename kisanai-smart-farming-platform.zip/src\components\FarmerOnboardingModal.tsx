import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  X,
  Sparkles,
  Check,
  Languages,
  Sprout,
  MapPin,
  Maximize2,
  ArrowRight,
  ShieldCheck,
  CheckCircle,
  Volume2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ONBOARDING_CROPS, SUPPORTED_LANGUAGES } from '../data/mockAgriData';
import { LanguageCode } from '../types';

export const FarmerOnboardingModal: React.FC = () => {
  const { activeModal, closeModal, language, setLanguage, updateFarmer, addCrop, farmer } = useApp();

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageCode>(language);
  const [selectedCropIds, setSelectedCropIds] = useState<string[]>(['crop-cotton', 'crop-soybean']);
  const [landAcres, setLandAcres] = useState<number>(farmer.totalLandAcres || 5);
  const [farmerName, setFarmerName] = useState<string>(farmer.fullName || farmer.name || '');
  const [district, setDistrict] = useState<string>(farmer.district || 'Nashik');

  if (activeModal !== 'onboarding') return null;

  const toggleCropSelection = (cropId: string) => {
    setSelectedCropIds((prev) =>
      prev.includes(cropId) ? prev.filter((id) => id !== cropId) : [...prev, cropId]
    );
  };

  const handleCompleteOnboarding = () => {
    setLanguage(selectedLanguage);
    updateFarmer({
      fullName: farmerName,
      language: selectedLanguage,
      totalLandAcres: landAcres,
      district,
      registeredCropsCount: selectedCropIds.length,
    });

    closeModal();
  };

  const speakWelcome = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const text =
        selectedLanguage === 'mr'
          ? 'किसान AI मध्ये आपले स्वागत आहे. आम्ही आपल्या शेतीसाठी नेहमी सोबत आहोत.'
          : selectedLanguage === 'hi'
          ? 'किसान AI में आपका स्वागत है। आपकी समृद्ध खेती ही हमारा संकल्प है।'
          : 'Welcome to KisanAI. Your intelligent agronomy companion.';
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = selectedLanguage === 'mr' ? 'mr-IN' : selectedLanguage === 'hi' ? 'hi-IN' : 'en-IN';
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div
      id="onboarding-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-emerald-950/85 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.2 }}
        className="relative w-full max-w-2xl max-h-[90vh] rounded-3xl bg-white dark:bg-[#072418] border border-emerald-500/30 shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-emerald-500/20 bg-emerald-50/80 dark:bg-emerald-950/90 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 text-white flex items-center justify-center shadow-md">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-emerald-950 dark:text-white font-outfit">
                {selectedLanguage === 'mr'
                  ? 'शेतकरी नोंदणी व पिके निवडा'
                  : selectedLanguage === 'hi'
                  ? 'किसान पंजीकरण व फसल चयन'
                  : 'Farmer Profile & Crop Setup'}
              </h3>
              <p className="text-xs text-emerald-700/80 dark:text-emerald-400/80">
                Step {step} of 3 • Customizing AI for your farm
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={speakWelcome}
              className="p-2 rounded-xl bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/25 transition-colors cursor-pointer"
              title="Voice Guide"
            >
              <Volume2 className="w-4 h-4" />
            </button>
            <button
              onClick={closeModal}
              className="p-2 rounded-xl bg-emerald-100/60 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-200 hover:bg-emerald-200 dark:hover:bg-emerald-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Step Progress Bar */}
        <div className="w-full bg-emerald-100 dark:bg-emerald-950/50 h-1.5 flex">
          <div
            className="bg-emerald-500 h-full transition-all duration-300"
            style={{ width: `${(step / 3) * 100}%` }}
          />
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* STEP 1: Select Language */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <h4 className="text-xl font-bold text-emerald-950 dark:text-white font-outfit">
                  आपली भाषा निवडा / अपनी भाषा चुनें
                </h4>
                <p className="text-xs text-slate-600 dark:text-emerald-200/70">
                  Select your primary language for voice queries and AI advisory
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                {[
                  { code: 'mr' as LanguageCode, title: 'मराठी', sub: 'Marathi', flag: '🇮🇳' },
                  { code: 'hi' as LanguageCode, title: 'हिन्दी', sub: 'Hindi', flag: '🇮🇳' },
                  { code: 'en' as LanguageCode, title: 'English', sub: 'All India', flag: '🇬🇧' },
                ].map((item) => (
                  <button
                    key={item.code}
                    onClick={() => setSelectedLanguage(item.code)}
                    className={`p-4 rounded-2xl border-2 text-left transition-all cursor-pointer relative flex flex-col justify-between h-28 ${
                      selectedLanguage === item.code
                        ? 'border-emerald-500 bg-emerald-50/80 dark:bg-emerald-900/40 shadow-md'
                        : 'border-slate-200 dark:border-emerald-900/60 bg-white dark:bg-emerald-950/40 hover:border-emerald-400/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-2xl">{item.flag}</span>
                      {selectedLanguage === item.code && (
                        <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                          <Check className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </div>
                    <div>
                      <div className="text-base font-bold text-emerald-950 dark:text-white font-outfit">
                        {item.title}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-emerald-400/80">{item.sub}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: Select Crops */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <h4 className="text-xl font-bold text-emerald-950 dark:text-white font-outfit">
                  {selectedLanguage === 'mr'
                    ? 'आपली मुख्य पिके निवडा'
                    : selectedLanguage === 'hi'
                    ? 'अपनी मुख्य फसलें चुनें'
                    : 'Select Your Active Crops'}
                </h4>
                <p className="text-xs text-slate-600 dark:text-emerald-200/70">
                  {selectedLanguage === 'mr'
                    ? 'एकापेक्षा जास्त पिके निवडू शकता'
                    : 'Select one or more crops for customized disease and mandi alerts'}
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                {ONBOARDING_CROPS.map((crop) => {
                  const isSelected = selectedCropIds.includes(crop.id);
                  const cropName =
                    selectedLanguage === 'mr'
                      ? crop.nameMr
                      : selectedLanguage === 'hi'
                      ? crop.nameHi
                      : crop.nameEn;

                  return (
                    <button
                      key={crop.id}
                      onClick={() => toggleCropSelection(crop.id)}
                      className={`p-3 rounded-2xl border-2 text-center transition-all cursor-pointer relative flex flex-col items-center gap-2 ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-500/15 dark:bg-emerald-900/50 shadow-md'
                          : 'border-slate-200 dark:border-emerald-900/60 bg-white dark:bg-emerald-950/40 hover:border-emerald-400/40'
                      }`}
                    >
                      {isSelected && (
                        <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                          <Check className="w-3 h-3" />
                        </div>
                      )}
                      <div className="w-12 h-12 rounded-xl overflow-hidden shadow-xs">
                        <img src={crop.image} alt={crop.nameEn} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-emerald-950 dark:text-white">{cropName}</div>
                        <div className="text-[10px] text-slate-500 dark:text-emerald-400/70">{crop.category}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 3: Land & Location */}
          {step === 3 && (
            <div className="space-y-5">
              <div className="text-center space-y-1">
                <h4 className="text-xl font-bold text-emerald-950 dark:text-white font-outfit">
                  {selectedLanguage === 'mr'
                    ? 'शेतजमीन व पत्ता'
                    : selectedLanguage === 'hi'
                    ? 'खेत का आकार व पता'
                    : 'Land Size & Location'}
                </h4>
                <p className="text-xs text-slate-600 dark:text-emerald-200/70">
                  Used for precise localized weather radar and APMC market arrivals
                </p>
              </div>

              <div className="space-y-4 max-w-md mx-auto">
                <div>
                  <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1.5">
                    {selectedLanguage === 'mr' ? 'शेतकऱ्याचे नाव' : 'Farmer Full Name'}
                  </label>
                  <input
                    type="text"
                    value={farmerName}
                    onChange={(e) => setFarmerName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-900/30 border border-emerald-500/25 text-emerald-950 dark:text-emerald-100 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1.5">
                    {selectedLanguage === 'mr' ? 'एकूण जमीन (एकर)' : 'Total Land (Acres)'}: {landAcres} Acres
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="50"
                    step="0.5"
                    value={landAcres}
                    onChange={(e) => setLandAcres(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 pt-1">
                    <span>1 Acre</span>
                    <span>10 Acres</span>
                    <span>25 Acres</span>
                    <span>50+ Acres</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1.5">
                    {selectedLanguage === 'mr' ? 'जिल्हा / राज्य' : 'District & State'}
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      placeholder="District (e.g. Nashik, Latur)"
                      className="px-4 py-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-900/30 border border-emerald-500/25 text-emerald-950 dark:text-emerald-100 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <div className="px-4 py-2.5 rounded-xl bg-emerald-100/50 dark:bg-emerald-900/50 border border-emerald-500/25 text-emerald-950 dark:text-emerald-200 text-sm font-semibold flex items-center">
                      Maharashtra
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Buttons */}
        <div className="px-6 py-4 border-t border-emerald-500/20 bg-emerald-50/50 dark:bg-emerald-950/80 flex items-center justify-between">
          {step > 1 ? (
            <button
              onClick={() => setStep((s) => (s - 1) as any)}
              className="px-5 py-2.5 rounded-xl border border-slate-300 dark:border-emerald-800 text-slate-700 dark:text-emerald-300 font-bold text-xs hover:bg-slate-100 dark:hover:bg-emerald-900/50 cursor-pointer"
            >
              {selectedLanguage === 'mr' ? 'मागे' : 'Back'}
            </button>
          ) : (
            <div />
          )}

          {step < 3 ? (
            <button
              onClick={() => setStep((s) => (s + 1) as any)}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-md cursor-pointer"
            >
              <span>{selectedLanguage === 'mr' ? 'पुढे जा' : 'Next'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              id="finish-onboarding-btn"
              onClick={handleCompleteOnboarding}
              className="px-7 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/30 cursor-pointer"
            >
              <CheckCircle className="w-4 h-4" />
              <span>
                {selectedLanguage === 'mr'
                  ? 'किसान ॲप सुरू करा 🚀'
                  : selectedLanguage === 'hi'
                  ? 'किसान ऐप शुरू करें 🚀'
                  : 'Launch KisanAI 🚀'}
              </span>
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
};
