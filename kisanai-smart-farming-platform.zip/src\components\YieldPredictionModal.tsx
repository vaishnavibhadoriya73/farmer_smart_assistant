import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  TrendingUp,
  Calendar,
  Activity,
  ShieldAlert,
  Volume2,
  VolumeX,
  X,
  Sparkles,
  Layers,
  CheckCircle2,
  RefreshCw,
  Droplets,
  Sun,
  ShieldCheck,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Cell,
} from 'recharts';
import { useApp } from '../context/AppContext';
import { YieldPredictionData } from '../types';

export const YieldPredictionModal: React.FC = () => {
  const { activeModal, closeModal, language, speakText, isSpeaking, stopSpeaking, selectedCrop, savePredictionRecord } = useApp();

  const [plotSize, setPlotSize] = useState<number>(selectedCrop?.plotSizeAcres || 3.0);
  const [selectedCropName, setSelectedCropName] = useState<string>(selectedCrop?.name || 'Red Onion (कांदा)');
  const [soilHealthScore, setSoilHealthScore] = useState<number>(92);
  const [weatherIndex, setWeatherIndex] = useState<number>(88);
  const [pestControlScore, setPestControlScore] = useState<number>(95);
  const [yieldData, setYieldData] = useState<YieldPredictionData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const fetchYieldPrediction = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/ai/yield-prediction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cropName: selectedCropName,
          plotSizeAcres: plotSize,
          soilHealthScore,
          weatherIndex,
          pestControlAdherence: pestControlScore,
        }),
      });
      const data = await res.json();
      if (data.data) {
        setYieldData(data.data);
        // Persist yield prediction to Firestore
        savePredictionRecord({
          id: `yield_${Date.now()}`,
          type: 'yield',
          cropName: selectedCropName,
          plotSizeAcres: plotSize,
          predictedAmount: data.data.estimatedYieldQuintals,
          unit: 'Quintals',
          confidenceScore: data.data.confidencePercentage,
          factors: data.data.factors?.map((f: any) => `${f.name}: ${f.impact}`) || [],
          recommendation: language === 'mr' ? data.data.recommendationMr : data.data.recommendationEn,
          timestamp: new Date().toISOString(),
        });
      }
    } catch (e) {
      console.error('Error fetching yield prediction:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (activeModal === 'yieldPrediction') {
      fetchYieldPrediction();
    }
  }, [activeModal, plotSize, selectedCropName, soilHealthScore, weatherIndex, pestControlScore]);

  if (activeModal !== 'yieldPrediction') return null;

  const handleSpeak = () => {
    if (!yieldData) return;
    if (isSpeaking) {
      stopSpeaking();
    } else {
      const textToSpeak =
        language === 'mr'
          ? yieldData.audioSummaryMr
          : language === 'hi'
          ? yieldData.audioSummaryHi
          : yieldData.audioSummaryEn;
      speakText(textToSpeak, language);
    }
  };

  const chartColors = ['#10b981', '#06b6d4', '#f59e0b', '#8b5cf6'];

  return (
    <div
      id="yield-prediction-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-emerald-950/80 backdrop-blur-md overflow-y-auto"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        className="relative w-full max-w-5xl max-h-[92vh] rounded-3xl bg-white dark:bg-[#072418] border border-emerald-500/30 shadow-2xl flex flex-col overflow-hidden text-slate-900 dark:text-emerald-50"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-emerald-500/20 bg-emerald-50/90 dark:bg-emerald-950/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-cyan-500 text-white flex items-center justify-center shadow-md">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold font-outfit text-emerald-950 dark:text-white">
                  {language === 'mr' ? 'AI उत्पादन अंदाज व काढणी वेळ' : language === 'hi' ? 'AI फसल पैदावार अनुमान' : 'AI Crop Yield Prediction'}
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                  Precision Bio-Model
                </span>
              </div>
              <p className="text-xs text-emerald-800/80 dark:text-emerald-300/80">
                {language === 'mr'
                  ? 'अपेक्षित उत्पादन, काढणीची तारीख, पिकांचे आरोग्य व जोखीम विश्लेषण'
                  : 'Expected Yield, Harvest Date, Crop Health & Multi-factor Risk Analysis'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="listen-yield-btn"
              onClick={handleSpeak}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-800 dark:text-emerald-200 text-xs font-bold transition-all cursor-pointer"
            >
              {isSpeaking ? (
                <>
                  <VolumeX className="w-4 h-4 text-emerald-600 dark:text-emerald-300 animate-pulse" />
                  <span>{language === 'mr' ? 'थांबवा' : 'Stop'}</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 text-emerald-600 dark:text-emerald-300" />
                  <span>🔊 {language === 'mr' ? 'ऐका' : 'Listen'}</span>
                </>
              )}
            </button>

            <button
              id="close-yield-modal"
              onClick={closeModal}
              className="p-2 rounded-xl bg-emerald-100/60 dark:bg-emerald-900/40 hover:bg-emerald-200 dark:hover:bg-emerald-800/60 text-emerald-800 dark:text-emerald-200 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Controls Bar */}
          <div className="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/40 border border-emerald-500/20 grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                🌾 {language === 'mr' ? 'पिक निवडा' : 'Select Crop'}
              </label>
              <select
                value={selectedCropName}
                onChange={(e) => setSelectedCropName(e.target.value)}
                className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 font-medium focus:outline-none focus:border-emerald-500"
              >
                <option value="Red Onion (कांदा)">Red Onion (कांदा)</option>
                <option value="Bt Cotton (कापूस)">Bt Cotton (कापूस)</option>
                <option value="Soybean (सोयाबीन)">Soybean (सोयाबीन)</option>
                <option value="Wheat (गहू)">Wheat (गहू)</option>
                <option value="Tomato (टोमॅटो)">Tomato (टोमॅटो)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                🚜 {language === 'mr' ? 'जमीन क्षेत्र (एकर)' : 'Land Area (Acres)'}
              </label>
              <input
                type="number"
                min="0.5"
                max="50"
                step="0.5"
                value={plotSize}
                onChange={(e) => setPlotSize(parseFloat(e.target.value) || 1)}
                className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 font-medium focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                🧪 {language === 'mr' ? 'माती सुपीकता' : 'Soil Health (%):'} {soilHealthScore}%
              </label>
              <input
                type="range"
                min="50"
                max="100"
                value={soilHealthScore}
                onChange={(e) => setSoilHealthScore(parseInt(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                🛡️ {language === 'mr' ? 'कीड नियंत्रण दक्षता' : 'Pest Control (%):'} {pestControlScore}%
              </label>
              <input
                type="range"
                min="50"
                max="100"
                value={pestControlScore}
                onChange={(e) => setPestControlScore(parseInt(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>
          </div>

          {yieldData && (
            <>
              {/* Top 4 KPI Metrics */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {/* 1. Expected Yield */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500/10 to-teal-500/20 border border-emerald-500/30">
                  <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 uppercase block">
                    {language === 'mr' ? 'अपेक्षित एकूण उत्पादन' : 'Expected Total Yield'}
                  </span>
                  <div className="text-2xl sm:text-3xl font-black font-outfit text-emerald-600 dark:text-emerald-400 mt-1">
                    {yieldData.expectedYieldQuintals} Q
                  </div>
                  <span className="text-[10px] text-zinc-500 dark:text-emerald-400/80">
                    ({yieldData.expectedYieldPerAcre} Quintals / Acre)
                  </span>
                </div>

                {/* 2. Harvest Date Window */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-sky-500/10 to-cyan-500/20 border border-sky-500/30">
                  <span className="text-[11px] font-bold text-sky-800 dark:text-sky-300 uppercase block">
                    {language === 'mr' ? 'काढणीची अंदाजित तारीख' : 'Harvest Date Window'}
                  </span>
                  <div className="text-xl sm:text-2xl font-black font-outfit text-sky-700 dark:text-sky-300 mt-1">
                    {yieldData.predictedHarvestDate}
                  </div>
                  <span className="text-[10px] text-zinc-500 dark:text-sky-300/80">{yieldData.harvestWindow}</span>
                </div>

                {/* 3. Crop Health Index */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500/10 to-green-500/20 border border-emerald-500/30">
                  <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 uppercase block">
                    {language === 'mr' ? 'पिकांचे आरोग्य निर्देशांक' : 'Crop Health Index'}
                  </span>
                  <div className="text-2xl sm:text-3xl font-black font-outfit text-emerald-500 mt-1 flex items-center gap-1.5">
                    <Activity className="w-5 h-5 text-emerald-500 animate-pulse" />
                    <span>{yieldData.cropHealthIndex}%</span>
                  </div>
                  <span className="text-[10px] text-zinc-500 dark:text-emerald-400/80">
                    NDVI {yieldData.ndviScore} • Moisture {yieldData.soilMoistureLevel}%
                  </span>
                </div>

                {/* 4. Risk Level */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 to-yellow-500/20 border border-amber-500/30">
                  <span className="text-[11px] font-bold text-amber-800 dark:text-amber-300 uppercase block">
                    {language === 'mr' ? 'एकूण जोखीम पातळी' : 'Overall Risk Profile'}
                  </span>
                  <div className="text-2xl sm:text-3xl font-black font-outfit text-amber-600 dark:text-amber-400 mt-1 flex items-center gap-1.5">
                    <ShieldCheck className="w-5 h-5 text-amber-500" />
                    <span>{yieldData.riskLevel} Risk</span>
                  </div>
                  <span className="text-[10px] text-zinc-500 dark:text-amber-300/80">Weather & Pests in Safe Zone</span>
                </div>
              </div>

              {/* Interactive Charts Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Area Chart: Phenological Yield Accumulation */}
                <div className="lg:col-span-7 p-5 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs sm:text-sm font-bold font-outfit text-emerald-950 dark:text-white flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-emerald-500" />
                      <span>{language === 'mr' ? 'टप्प्यानुसार उत्पादन वाढ (Yield Trajectory)' : 'Stage-wise Yield Accumulation'}</span>
                    </h3>
                    <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
                      vs Regional Benchmark
                    </span>
                  </div>

                  <div className="h-60 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={yieldData.monthlyYieldTrend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <defs>
                          <linearGradient id="yieldGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                            <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#10b981" opacity={0.15} />
                        <XAxis dataKey="stage" tick={{ fontSize: 10, fill: '#64748b' }} />
                        <YAxis tick={{ fontSize: 10, fill: '#64748b' }} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#06291a',
                            borderRadius: '12px',
                            border: '1px solid #10b981',
                            color: '#fff',
                            fontSize: '12px',
                          }}
                        />
                        <Legend />
                        <Area
                          type="monotone"
                          dataKey="predictedYield"
                          name="Predicted Yield (Q)"
                          stroke="#10b981"
                          strokeWidth={2.5}
                          fillOpacity={1}
                          fill="url(#yieldGradient)"
                        />
                        <Area
                          type="monotone"
                          dataKey="benchmarkYield"
                          name="Benchmark Yield (Q)"
                          stroke="#94a3b8"
                          strokeDasharray="4 4"
                          fill="none"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Bar Chart: Yield Contributing Drivers */}
                <div className="lg:col-span-5 p-5 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 space-y-3">
                  <h3 className="text-xs sm:text-sm font-bold font-outfit text-emerald-950 dark:text-white flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-emerald-500" />
                    <span>{language === 'mr' ? 'उत्पादनावर प्रभाव टाकणारे घटक' : 'Yield Contributing Drivers'}</span>
                  </h3>

                  <div className="h-60 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={yieldData.yieldContributingFactors} layout="vertical" margin={{ top: 5, right: 15, left: 10, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#10b981" opacity={0.15} />
                        <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 10, fill: '#64748b' }} />
                        <YAxis dataKey="name" type="category" width={110} tick={{ fontSize: 9, fill: '#64748b' }} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#06291a',
                            borderRadius: '12px',
                            border: '1px solid #10b981',
                            color: '#fff',
                            fontSize: '12px',
                          }}
                        />
                        <Bar dataKey="score" name="Score %" radius={[0, 8, 8, 0]}>
                          {yieldData.yieldContributingFactors.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={chartColors[index % chartColors.length]} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Risk Mitigation Table */}
              <div className="p-5 rounded-3xl bg-amber-50/50 dark:bg-emerald-950/40 border border-amber-500/20 space-y-3">
                <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-bold text-xs">
                  <ShieldAlert className="w-4 h-4 text-amber-500" />
                  <span>{language === 'mr' ? 'जोखीम घटक व उपाययोजना (Risk Mitigation)' : 'Risk Factors & Proactive Mitigations'}</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {yieldData.riskFactors.map((rf, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-2xl bg-white dark:bg-emerald-900/40 border border-amber-500/20 text-xs space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 dark:text-white leading-tight">{rf.factor}</span>
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-700 dark:text-amber-300">
                          {rf.impact} Impact
                        </span>
                      </div>
                      <p className="text-zinc-600 dark:text-emerald-200/90 text-[11px] leading-relaxed">
                        <strong>{language === 'mr' ? 'उपाय:' : 'Mitigation:'}</strong> {rf.mitigation}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
};
