import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Sprout,
  CheckCircle2,
  TrendingUp,
  Volume2,
  VolumeX,
  X,
  Sparkles,
  MapPin,
  Droplets,
  Thermometer,
  ShieldAlert,
  Percent,
  Coins,
  ArrowRight,
  RefreshCw,
  Award,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { RecommendedCrop, CropRecommendationInput } from '../types';

export const CropRecommendationModal: React.FC = () => {
  const { activeModal, closeModal, language, speakText, isSpeaking, stopSpeaking, farmer } = useApp();

  const [inputParams, setInputParams] = useState<CropRecommendationInput>({
    state: farmer.state || 'Maharashtra',
    district: farmer.district || 'Nashik',
    soilType: 'काळी कसदार (Black Cotton)',
    season: 'Kharif',
    rainfall: 'Medium (500-1000mm)',
    temperatureRange: '22°C - 34°C',
    waterAvailability: 'Borewell / Drip',
    marketDemand: 'High Demand',
    landAcres: farmer.totalLandAcres || 3,
  });

  const [recommendations, setRecommendations] = useState<RecommendedCrop[]>([]);
  const [selectedCrop, setSelectedCrop] = useState<RecommendedCrop | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const fetchRecommendations = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/ai/crop-recommendation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...inputParams, language }),
      });
      const data = await res.json();
      if (data.recommendations) {
        setRecommendations(data.recommendations);
        const best = data.recommendations.find((c: RecommendedCrop) => c.isBestCrop) || data.recommendations[0];
        setSelectedCrop(best);
      }
    } catch (e) {
      console.error('Error fetching crop recommendations:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (activeModal === 'cropRecommendation') {
      fetchRecommendations();
    }
  }, [activeModal]);

  if (activeModal !== 'cropRecommendation') return null;

  const handleSpeak = (crop: RecommendedCrop) => {
    if (isSpeaking) {
      stopSpeaking();
    } else {
      const textToSpeak =
        language === 'mr' ? crop.audioAdvisoryMr : language === 'hi' ? crop.audioAdvisoryHi : crop.audioAdvisoryEn;
      speakText(textToSpeak, language);
    }
  };

  const getCropName = (crop: RecommendedCrop) => {
    if (language === 'mr') return crop.cropNameMr;
    if (language === 'hi') return crop.cropNameHi;
    return crop.cropNameEn;
  };

  const bestCrop = recommendations.find((c) => c.isBestCrop) || recommendations[0];

  return (
    <div
      id="crop-recommendation-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-emerald-950/80 backdrop-blur-md overflow-y-auto"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        className="relative w-full max-w-5xl max-h-[92vh] rounded-3xl bg-white dark:bg-[#072418] border border-emerald-500/30 shadow-2xl flex flex-col overflow-hidden text-slate-900 dark:text-emerald-50"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-emerald-500/20 bg-emerald-50/90 dark:bg-emerald-950/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-md">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold font-outfit text-emerald-950 dark:text-white">
                  {language === 'mr' ? 'AI पीक शिफारस मॉडेल' : language === 'hi' ? 'AI फसल सिफारिश' : 'AI Crop Recommendation'}
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                  Precision Agronomy
                </span>
              </div>
              <p className="text-xs text-emerald-800/80 dark:text-emerald-300/80">
                {language === 'mr'
                  ? 'स्थान, माती, ऋतू, पाऊस, तापमान, पाणी उपलब्धता व बाजार मागणीवर आधारित'
                  : 'Based on Location, Soil, Season, Rainfall, Temperature, Water & Market demand'}
              </p>
            </div>
          </div>

          <button
            id="close-crop-rec-modal"
            onClick={closeModal}
            className="p-2 rounded-xl bg-emerald-100/60 dark:bg-emerald-900/40 hover:bg-emerald-200 dark:hover:bg-emerald-800/60 text-emerald-800 dark:text-emerald-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Input Filter Panel */}
          <div className="p-4 sm:p-5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/40 border border-emerald-500/20 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                {language === 'mr' ? 'शेतीचे मापदंड व परिस्थिती' : 'Your Farm Environmental Parameters'}
              </span>
              <button
                onClick={fetchRecommendations}
                disabled={isLoading}
                className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-300 hover:text-emerald-900 dark:hover:text-white transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>{language === 'mr' ? 'पुन्हा विश्लेषण करा' : 'Recalculate AI'}</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 text-xs">
              {/* Location */}
              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  📍 {language === 'mr' ? 'स्थान / जिल्हा' : 'Location / District'}
                </label>
                <select
                  value={inputParams.district}
                  onChange={(e) => setInputParams({ ...inputParams, district: e.target.value })}
                  className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 text-xs font-medium focus:outline-none focus:border-emerald-500"
                >
                  <option value="Nashik">Nashik (नाशिक)</option>
                  <option value="Pune">Pune (पुणे)</option>
                  <option value="Latur">Latur (लातूर)</option>
                  <option value="Akola">Akola (अकोला)</option>
                  <option value="Indore">Indore (इंदौर)</option>
                  <option value="Rajkot">Rajkot (राजकोट)</option>
                  <option value="Karnal">Karnal (करनाल)</option>
                </select>
              </div>

              {/* Soil */}
              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  🌱 {language === 'mr' ? 'मातीचा प्रकार' : 'Soil Type'}
                </label>
                <select
                  value={inputParams.soilType}
                  onChange={(e) => setInputParams({ ...inputParams, soilType: e.target.value })}
                  className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 text-xs font-medium focus:outline-none focus:border-emerald-500"
                >
                  <option value="काळी कसदार (Black Cotton)">काळी कसदार (Black Cotton)</option>
                  <option value="लाल तांबडी (Red Loamy)">लाल तांबडी (Red Loamy)</option>
                  <option value="गाळाची जमीन (Alluvial)">गाळाची जमीन (Alluvial)</option>
                  <option value="रेताड मध्यम (Sandy Loam)">रेताड मध्यम (Sandy Loam)</option>
                </select>
              </div>

              {/* Season */}
              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  ☀️ {language === 'mr' ? 'हंगाम' : 'Season'}
                </label>
                <select
                  value={inputParams.season}
                  onChange={(e) => setInputParams({ ...inputParams, season: e.target.value as any })}
                  className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 text-xs font-medium focus:outline-none focus:border-emerald-500"
                >
                  <option value="Kharif">Kharif (खरीप - पावसाळी)</option>
                  <option value="Rabi">Rabi (रब्बी - हिवाळी)</option>
                  <option value="Zaid">Zaid (उन्हाळी / बारमाही)</option>
                </select>
              </div>

              {/* Rainfall */}
              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  🌧️ {language === 'mr' ? 'अपेक्षित पाऊस' : 'Rainfall'}
                </label>
                <select
                  value={inputParams.rainfall}
                  onChange={(e) => setInputParams({ ...inputParams, rainfall: e.target.value as any })}
                  className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 text-xs font-medium focus:outline-none focus:border-emerald-500"
                >
                  <option value="Medium (500-1000mm)">Medium (500-1000mm)</option>
                  <option value="Low (<500mm)">Low (&lt;500mm)</option>
                  <option value="High (>1000mm)">High (&gt;1000mm)</option>
                </select>
              </div>

              {/* Temperature */}
              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  🌡️ {language === 'mr' ? 'तापमान' : 'Temperature'}
                </label>
                <select
                  value={inputParams.temperatureRange}
                  onChange={(e) => setInputParams({ ...inputParams, temperatureRange: e.target.value })}
                  className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 text-xs font-medium focus:outline-none focus:border-emerald-500"
                >
                  <option value="22°C - 34°C">22°C - 34°C (Moderate)</option>
                  <option value="15°C - 28°C">15°C - 28°C (Cool Rabi)</option>
                  <option value="28°C - 42°C">28°C - 42°C (Warm Summer)</option>
                </select>
              </div>

              {/* Water Availability */}
              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  💧 {language === 'mr' ? 'पाणी उपलब्धता' : 'Water Availability'}
                </label>
                <select
                  value={inputParams.waterAvailability}
                  onChange={(e) => setInputParams({ ...inputParams, waterAvailability: e.target.value as any })}
                  className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 text-xs font-medium focus:outline-none focus:border-emerald-500"
                >
                  <option value="Borewell / Drip">Borewell / Drip (ठिबक सिंचन)</option>
                  <option value="Canal">Canal (कालवा / पाटपाणी)</option>
                  <option value="Open Well">Open Well (विहीर)</option>
                  <option value="Rainfed">Rainfed (जिरायती / पावसावर)</option>
                </select>
              </div>

              {/* Market Demand */}
              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  📈 {language === 'mr' ? 'बाजार मागणी' : 'Market Demand'}
                </label>
                <select
                  value={inputParams.marketDemand}
                  onChange={(e) => setInputParams({ ...inputParams, marketDemand: e.target.value as any })}
                  className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 text-xs font-medium focus:outline-none focus:border-emerald-500"
                >
                  <option value="High Demand">High Demand (उच्च मागणी)</option>
                  <option value="Rising Trend">Rising Trend (वाढती मागणी)</option>
                  <option value="Export Oriented">Export Oriented (निर्यातक्षम)</option>
                  <option value="Steady">Steady (स्थिर)</option>
                </select>
              </div>

              {/* Land Acres */}
              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  🚜 {language === 'mr' ? 'जमीन क्षेत्र (एकर)' : 'Land Area (Acres)'}
                </label>
                <input
                  type="number"
                  min="0.5"
                  max="100"
                  step="0.5"
                  value={inputParams.landAcres}
                  onChange={(e) => setInputParams({ ...inputParams, landAcres: parseFloat(e.target.value) || 1 })}
                  className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 text-xs font-medium focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Top Feature: Best Crop For You */}
          {bestCrop && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative rounded-3xl p-5 sm:p-6 bg-gradient-to-br from-emerald-600 via-teal-700 to-emerald-900 text-white shadow-xl border-2 border-emerald-400/60 overflow-hidden"
            >
              {/* Highlight Badge */}
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400 text-emerald-950 font-black text-xs shadow-lg uppercase tracking-wider">
                  <Award className="w-4 h-4" />
                  <span>{language === 'mr' ? 'तुमच्यासाठी सर्वोत्तम पीक' : 'Best Crop For You'}</span>
                </div>

                {/* 🔊 ऐका TTS Action */}
                <button
                  id="listen-best-crop-btn"
                  onClick={() => handleSpeak(bestCrop)}
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/20 hover:bg-white/30 text-white font-bold text-xs border border-white/30 backdrop-blur-md transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-4 h-4 text-amber-300 animate-pulse" />
                      <span>{language === 'mr' ? 'थांबवा' : 'Stop'}</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4 text-amber-300" />
                      <span>🔊 {language === 'mr' ? 'ऐका (Listen)' : 'Listen Aloud'}</span>
                    </>
                  )}
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                {/* Crop Name & Image */}
                <div className="lg:col-span-5 flex items-center gap-4">
                  <img
                    src={bestCrop.image}
                    alt={bestCrop.cropNameEn}
                    className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-2 border-white/30 shadow-lg shrink-0"
                  />
                  <div className="space-y-1">
                    <h3 className="text-2xl sm:text-3xl font-black font-outfit text-white leading-tight">
                      {getCropName(bestCrop)}
                    </h3>
                    <p className="text-xs text-emerald-200 font-semibold">{bestCrop.variety}</p>
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-emerald-400/20 text-emerald-200 text-[11px]">
                      <span>{bestCrop.durationDays}</span>
                    </div>
                  </div>
                </div>

                {/* Suitability Score & Core Metrics */}
                <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {/* Suitability Score */}
                  <div className="p-3.5 rounded-2xl bg-white/10 border border-white/20 backdrop-blur-xs text-center">
                    <span className="text-[10px] text-emerald-200 font-semibold uppercase block">
                      {language === 'mr' ? 'अनुकूलता स्कोअर' : 'Suitability Score'}
                    </span>
                    <div className="text-2xl font-black text-amber-300 font-outfit mt-0.5 flex items-center justify-center gap-0.5">
                      <span>{bestCrop.suitabilityScore}</span>
                      <Percent className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-[9px] text-emerald-300">96% High Match</span>
                  </div>

                  {/* Expected Yield */}
                  <div className="p-3.5 rounded-2xl bg-white/10 border border-white/20 backdrop-blur-xs text-center">
                    <span className="text-[10px] text-emerald-200 font-semibold uppercase block">
                      {language === 'mr' ? 'अपेक्षित उत्पादन' : 'Expected Yield'}
                    </span>
                    <div className="text-lg font-black text-white font-outfit mt-0.5">
                      {bestCrop.expectedYieldQuintalsPerAcre} Q / Acre
                    </div>
                    <span className="text-[9px] text-emerald-200">
                      Total: {(bestCrop.expectedYieldQuintalsPerAcre * inputParams.landAcres).toFixed(0)} Quintals
                    </span>
                  </div>

                  {/* Investment */}
                  <div className="p-3.5 rounded-2xl bg-white/10 border border-white/20 backdrop-blur-xs text-center">
                    <span className="text-[10px] text-emerald-200 font-semibold uppercase block">
                      {language === 'mr' ? 'भांडवली खर्च' : 'Investment'}
                    </span>
                    <div className="text-lg font-black text-white font-outfit mt-0.5">
                      ₹{bestCrop.investmentPerAcre.toLocaleString('en-IN')}
                    </div>
                    <span className="text-[9px] text-emerald-200">
                      Total: ₹{(bestCrop.investmentPerAcre * inputParams.landAcres).toLocaleString('en-IN')}
                    </span>
                  </div>

                  {/* Expected Profit */}
                  <div className="p-3.5 rounded-2xl bg-amber-400/20 border border-amber-300/40 backdrop-blur-xs text-center">
                    <span className="text-[10px] text-amber-200 font-bold uppercase block">
                      {language === 'mr' ? 'अपेक्षित नफा' : 'Expected Profit'}
                    </span>
                    <div className="text-xl font-black text-amber-300 font-outfit mt-0.5">
                      ₹{bestCrop.expectedProfitPerAcre.toLocaleString('en-IN')}
                    </div>
                    <span className="text-[9px] text-amber-200 font-bold">ROI {bestCrop.roiPercentage}%</span>
                  </div>
                </div>
              </div>

              {/* Risk Level & Key Advantages */}
              <div className="mt-4 pt-4 border-t border-white/15 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="flex items-start gap-2 text-emerald-100">
                  <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0 mt-0.5" />
                  <span>
                    <strong>{language === 'mr' ? 'मुख्य फायदे:' : 'Key Advantages:'}</strong>{' '}
                    {bestCrop.keyAdvantages.join(' • ')}
                  </span>
                </div>
                <div className="flex items-start gap-2 text-emerald-100">
                  <ShieldAlert className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                  <span>
                    <strong>{language === 'mr' ? 'धोका (Risk):' : 'Risk & Watchouts:'}</strong>{' '}
                    <span className="px-1.5 py-0.5 rounded bg-amber-500/30 text-amber-200 font-bold">
                      {bestCrop.riskLevel} Risk
                    </span>{' '}
                    - {bestCrop.riskFactors.join(', ')}
                  </span>
                </div>
              </div>
            </motion.div>
          )}

          {/* All Recommended Alternatives Grid */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold font-outfit text-emerald-950 dark:text-emerald-200">
              {language === 'mr' ? 'सर्व शिफारस केलेली पिके (Alternative Top Crops)' : 'All Suitable Crops Comparison'}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {recommendations.map((crop) => (
                <div
                  key={crop.id}
                  onClick={() => setSelectedCrop(crop)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                    selectedCrop?.id === crop.id
                      ? 'bg-emerald-500/10 dark:bg-emerald-900/50 border-emerald-500 shadow-md ring-1 ring-emerald-500'
                      : 'bg-white dark:bg-emerald-950/60 border-emerald-500/20 hover:border-emerald-500/40'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <img src={crop.image} alt={crop.cropNameEn} className="w-12 h-12 rounded-xl object-cover" />
                    <div>
                      <h4 className="font-bold text-sm text-emerald-950 dark:text-white">{getCropName(crop)}</h4>
                      <p className="text-[11px] text-zinc-500 dark:text-emerald-400/80">{crop.variety}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-emerald-500/15">
                    <div>
                      <span className="text-zinc-500 dark:text-emerald-400/70 block">Suitability</span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">{crop.suitabilityScore}%</span>
                    </div>
                    <div>
                      <span className="text-zinc-500 dark:text-emerald-400/70 block">Exp. Profit/Acre</span>
                      <span className="font-bold text-amber-600 dark:text-amber-400">
                        ₹{crop.expectedProfitPerAcre.toLocaleString('en-IN')}
                      </span>
                    </div>
                    <div>
                      <span className="text-zinc-500 dark:text-emerald-400/70 block">Investment/Acre</span>
                      <span className="font-semibold text-zinc-700 dark:text-zinc-300">
                        ₹{crop.investmentPerAcre.toLocaleString('en-IN')}
                      </span>
                    </div>
                    <div>
                      <span className="text-zinc-500 dark:text-emerald-400/70 block">Risk</span>
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400">{crop.riskLevel}</span>
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSpeak(crop);
                    }}
                    className="w-full py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 font-bold text-[11px] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>🔊 {language === 'mr' ? 'ऐका' : 'Listen Advice'}</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
