import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  User,
  Phone,
  X,
  Sparkles,
  RefreshCw,
  Zap,
  CheckCircle,
  ShieldCheck
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { KisanLogo } from './KisanLogo';

export const FarmerLoginModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    loginFarmerWithMobile,
    sendMobileOtp,
    verifyMobileOtp,
    loginWithGoogle,
    language,
    speakText,
  } = useApp();

  const [mobileNumber, setMobileNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [isLoggedInSuccess, setIsLoggedInSuccess] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [incomingSms, setIncomingSms] = useState<{ text: string; code: string } | null>(null);

  // Resend Countdown Timer (30s)
  const [countdown, setCountdown] = useState(30);
  const [canResend, setCanResend] = useState(false);

  useEffect(() => {
    let timer: any;
    if (isOtpSent && countdown > 0) {
      timer = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    } else if (countdown === 0) {
      setCanResend(true);
    }
    return () => clearInterval(timer);
  }, [isOtpSent, countdown]);

  if (activeModal !== 'login') return null;

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mobileNumber || mobileNumber.length < 10) {
      setErrorMessage(
        language === 'mr'
          ? 'कृपया १० अंकी मोबाईल नंबर प्रविष्ट करा.'
          : 'Please enter a 10-digit mobile number.'
      );
      return;
    }

    setErrorMessage('');
    setIsProcessing(true);

    try {
      const result = await sendMobileOtp(mobileNumber);
      if (result.success) {
        setIsOtpSent(true);
        setCountdown(30);
        setCanResend(false);

        if (result.otpCode) {
          setIncomingSms({
            text: result.smsText || `KisanAI Mobile OTP code is ${result.otpCode}`,
            code: result.otpCode,
          });
          if (language === 'mr') {
            speakText(`तुमच्या मोबाईलवर ${result.otpCode.split('').join(' ')} हा ओटीपी पाठवला आहे.`, 'mr');
          } else if (language === 'hi') {
            speakText(`आपके मोबाइल पर ${result.otpCode.split('').join(' ')} ओटीपी भेजा गया है।`, 'hi');
          }
        }
      } else {
        setErrorMessage(result.message || 'OTP delivery failed.');
      }
    } catch (err) {
      console.error(err);
      setErrorMessage('Network connection error.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp || otp.length < 4) {
      setErrorMessage(language === 'mr' ? 'ओटीपी प्रविष्ट करा.' : 'Please enter the OTP.');
      return;
    }

    setErrorMessage('');
    setIsProcessing(true);

    try {
      const verifyRes = await verifyMobileOtp(mobileNumber, otp);
      if (verifyRes.success) {
        await loginFarmerWithMobile(mobileNumber);
        setIsLoggedInSuccess(true);
        setTimeout(() => {
          closeModal();
          setIsLoggedInSuccess(false);
          setIsOtpSent(false);
          setIncomingSms(null);
          setMobileNumber('');
          setOtp('');
        }, 1200);
      } else {
        setErrorMessage(verifyRes.message || 'Invalid OTP code.');
      }
    } catch (err) {
      console.warn('OTP verification error:', err);
      setErrorMessage('OTP verification failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleContinueDemoFarmer = async () => {
    setIsProcessing(true);
    try {
      await loginFarmerWithMobile('9876543210');
      setIsLoggedInSuccess(true);
      setTimeout(() => {
        closeModal();
        setIsLoggedInSuccess(false);
      }, 800);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div
      id="farmer-login-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-emerald-950/80 backdrop-blur-md overflow-y-auto"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-4xl rounded-3xl bg-slate-900 border border-emerald-500/30 shadow-2xl overflow-hidden text-white flex flex-col md:flex-row"
      >
        {/* Left Side Hero Panel */}
        <div className="md:w-1/2 p-6 sm:p-8 bg-gradient-to-br from-emerald-950 via-slate-950 to-emerald-900 flex flex-col justify-between border-b md:border-b-0 md:border-r border-emerald-500/20 relative overflow-hidden">
          <div className="relative z-10 space-y-6">
            <KisanLogo size="lg" showTagline={true} />

            <div className="space-y-3 pt-4">
              <div className="inline-flex items-center space-x-2 px-3 py-1 bg-amber-500/20 border border-amber-400/40 text-amber-300 rounded-full text-xs font-bold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Verified Agricultural Portal</span>
              </div>
              <h2 className="text-2xl font-extrabold text-white leading-tight font-outfit">
                {language === 'mr' ? 'शेतकऱ्यांचा स्मार्ट AI साथीदार' : 'Smart Farming. Better Decisions.'}
              </h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                Access crop disease diagnostics, live APMC mandi rates, government schemes, weather radar, and smart supply chain tracking in one place.
              </p>
            </div>
          </div>

          <div className="relative z-10 pt-6 text-[11px] text-emerald-400 font-semibold flex items-center space-x-2">
            <span>🌾 Empowering Indian Farmers</span>
          </div>

          {/* Background Decorative Gradient */}
          <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
        </div>

        {/* Right Side Form Panel */}
        <div className="md:w-1/2 p-6 sm:p-8 space-y-6 relative flex flex-col justify-center">
          
          <button
            onClick={closeModal}
            className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="space-y-1 text-center md:text-left">
            <h3 className="text-xl font-bold text-white">Welcome Back 👋</h3>
            <p className="text-xs text-slate-400">Sign in to access your Central Farmer Dashboard</p>
          </div>

          {/* Quick Google Sign In Button */}
          <button
            type="button"
            onClick={async () => {
              setIsProcessing(true);
              const res = await loginWithGoogle();
              setIsProcessing(false);
              if (res.success) {
                setIsLoggedInSuccess(true);
                setTimeout(() => {
                  closeModal();
                  setIsLoggedInSuccess(false);
                }, 800);
              }
            }}
            className="w-full py-3.5 px-4 bg-white hover:bg-slate-100 text-slate-900 font-extrabold rounded-2xl text-xs shadow-md transition flex items-center justify-center space-x-2 border border-slate-200 cursor-pointer"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
            </svg>
            <span>Sign in with Google Account</span>
          </button>

          <div className="flex items-center my-2">
            <div className="flex-1 border-t border-slate-800" />
            <span className="px-3 text-[10px] uppercase font-bold text-slate-500">or Mobile OTP</span>
            <div className="flex-1 border-t border-slate-800" />
          </div>

          {isLoggedInSuccess ? (
            <div className="py-6 text-center space-y-3">
              <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
              <h4 className="text-base font-bold text-white">Login Successful!</h4>
              <p className="text-xs text-emerald-400">Opening Dashboard...</p>
            </div>
          ) : !isOtpSent ? (
            <form onSubmit={handleSendOtp} className="space-y-4">
              {errorMessage && (
                <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-semibold text-center">
                  {errorMessage}
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Mobile Number</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3.5 text-xs font-bold text-slate-500">+91</span>
                  <input
                    type="tel"
                    maxLength={10}
                    placeholder="9876543210"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                    className="w-full pl-12 pr-4 py-3 bg-slate-950 border border-slate-700 rounded-2xl text-sm font-bold text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-extrabold text-sm shadow-lg transition disabled:opacity-50 flex items-center justify-center space-x-2"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Sending OTP...</span>
                  </>
                ) : (
                  <>
                    <Phone className="w-4 h-4" />
                    <span>Send Mobile OTP</span>
                  </>
                )}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              {incomingSms && (
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-xs space-y-1">
                  <div className="font-bold flex items-center space-x-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Incoming SMS OTP Preview:</span>
                  </div>
                  <div className="font-mono text-base font-bold text-amber-400">{incomingSms.code}</div>
                  <button
                    type="button"
                    onClick={() => setOtp(incomingSms.code)}
                    className="underline text-[11px] font-bold hover:text-white"
                  >
                    Auto-fill OTP
                  </button>
                </div>
              )}

              {errorMessage && (
                <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-semibold text-center">
                  {errorMessage}
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Enter 6-Digit OTP</label>
                <input
                  type="text"
                  maxLength={6}
                  placeholder="123456"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  className="w-full text-center tracking-widest py-3 bg-slate-950 border border-slate-700 rounded-2xl text-lg font-bold text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-extrabold text-sm shadow-lg transition disabled:opacity-50 flex items-center justify-center space-x-2"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Verifying...</span>
                  </>
                ) : (
                  <span>Verify OTP & Enter Portal</span>
                )}
              </button>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
};
