import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Sprout,
  TrendingUp,
  CloudSun,
  DollarSign,
  Truck,
  Landmark,
  Scan,
  Calendar,
  Sparkles,
  ChevronRight,
  Bell,
  MapPin,
  CheckCircle,
  AlertTriangle,
  Bot,
  BarChart2,
  Clock,
  User,
  ShieldCheck,
  Building2,
  ExternalLink,
  Droplets,
  Wind,
  Sun
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { useApp } from '../context/AppContext';
import { LiveMandiTicker } from './LiveMandiTicker';

export const CentralFarmerDashboard: React.FC = () => {
  const { farmer, openModal, language, setLanguage, speakText } = useApp();
  const [selectedCropChart, setSelectedCropChart] = useState<string>('Tomato');

  const farmerName = farmer?.fullName || farmer?.name || 'Farmer';

  // Date formatted in active language
  const todayStr = new Date().toLocaleDateString(
    language === 'mr' ? 'mr-IN' : language === 'hi' ? 'hi-IN' : 'en-IN',
    {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }
  );

  // Multilingual Dictionary Engine
  const textDict = {
    badgeCmd: { en: '🌾 KisanAI Central Command', hi: '🌾 किसान AI मुख्य डैशबोर्ड', mr: '🌾 किसान AI मुख्य डॅशबोर्ड' },
    badgeMode: {
      verified: { en: 'Verified Profile', hi: 'सत्यापित प्रोफाइल', mr: 'प्रमाणित प्रोफाईल' },
      demo: { en: 'Demo Farmer Mode', hi: 'डेमो किसान मोड', mr: 'डेमो शेतकरी मोड' }
    },
    greeting: {
      en: `Good Morning, ${farmerName}! 👋`,
      hi: `शुभ प्रभात, ${farmerName}! 👋`,
      mr: `शुभ प्रभात, ${farmerName}! 👋`
    },
    subGreeting: {
      en: "Here's your farming intelligence summary for today.",
      hi: 'आज की आपकी कृषि बुद्धिमत्ता की जानकारी।',
      mr: 'आजची तुमची सर्वसमावेशक शेती माहिती.'
    },
    // Summary Cards
    cards: {
      myCrops: { title: { en: 'Active Crops', hi: 'सक्रिय फसलें', mr: 'सक्रिय पिके' }, badge: { en: 'Active', hi: 'सक्रिय', mr: 'सक्रिय' }, action: { en: 'View Details', hi: 'विवरण देखें', mr: 'सविस्तर पहा' } },
      mandiPrice: { title: { en: 'Top Mandi Price', hi: 'मुख्य मंडी भाव', mr: 'मुख्य दर' }, action: { en: 'Check Rates', hi: 'भाव देखें', mr: 'दर पहा' } },
      weather: { title: { en: 'Weather Radar', hi: 'मौसम पूर्वानुमान', mr: 'हवामान अंदाज' }, badge: { en: 'Safe', hi: 'सुरक्षित', mr: 'सुरक्षित' }, action: { en: 'Forecast', hi: 'पूर्वानुमान', mr: 'अंदाज पहा' } },
      earnings: { title: { en: 'Expected Revenue', hi: 'अनुमानित आय', mr: 'अपेक्षित उत्पन्न' }, action: { en: 'Calculate', hi: 'गणना करें', mr: 'अंदाज काढा' } },
      shipments: { title: { en: 'Active Shipments', hi: 'सक्रिय शिपमेंट', mr: 'सक्रिय वाहतूक' }, action: { en: 'Track Live', hi: 'ट्रैक करें', mr: 'ट्रॅक करा' } },
      schemes: { title: { en: 'Govt Schemes', hi: 'सरकारी योजनाएँ', mr: 'सरकारी योजना' }, action: { en: 'Apply Now', hi: 'आवेदन करें', mr: 'अर्ज करा' } },
    },
    // Overview Section
    overview: {
      title: { en: 'Farm Overview', hi: 'खेत का विवरण', mr: 'शेत जमीन माहिती' },
      demoBadge: { en: 'Demo Data', hi: 'डेमो डेटा', mr: 'डेमो माहिती' },
      loc: { en: 'Farm Location:', hi: 'खेत का स्थान:', mr: 'शेताचे ठिकाण:' },
      land: { en: 'Total Land:', hi: 'कुल भूमि:', mr: 'एकूण जमीन:' },
      crops: { en: 'Primary Crops:', hi: 'मुख्य फसलें:', mr: 'मुख्य पिके:' },
      soil: { en: 'Soil & Irrigation:', hi: 'मिट्टी और सिंचाई:', mr: 'माती व सिंचन प्रकार:' },
      rev: { en: 'Estimated Revenue:', hi: 'अनुमानित कुल आय:', mr: 'अपेक्षित उत्पन्न:' },
      editBtn: { en: 'Edit Farm Details', hi: 'विवरण संपादित करें', mr: 'माहिती बदला' }
    },
    // Quick Actions
    quickActions: {
      title: { en: 'Quick Actions Control Center', hi: 'त्वरित कार्रवाई केंद्र', mr: 'स्मार्ट शेतकाम शॉर्टकट्स' },
      subtitle: { en: 'Direct shortcuts to active AI features', hi: 'एआई सुविधाओं के त्वरित विकल्प', mr: 'थेट AI फीचर्स वापरा' },
      detect: { title: { en: 'Detect Crop Disease', hi: 'फसल रोग पहचान', mr: 'पिक रोग निदान' }, sub: { en: 'Camera Scan', hi: 'कैमरा स्कैन', mr: 'कॅमेरा स्कॅन' } },
      mandi: { title: { en: 'Check Mandi Rates', hi: 'मंडी भाव देखें', mr: 'मंडी दर पहा' }, sub: { en: 'Live APMC Prices', hi: 'लाइव एपीएमसी', mr: 'थेट APMC दर' } },
      schemes: { title: { en: 'Government Schemes', hi: 'सरकारी योजनाएँ', mr: 'सरकारी योजना' }, sub: { en: 'Subsidies & Grants', hi: 'सब्सिडी व अनुदान', mr: 'अनुदान व मदत' } },
      plan: { title: { en: 'Plan My Crop', hi: 'फसल योजना', mr: 'पिक नियोजन' }, sub: { en: 'Lifecycle Advisory', hi: 'सप्ताह वार सलाह', mr: 'अटवडा सल्ला' } },
      weather: { title: { en: 'Check Weather', hi: 'मौसम देखें', mr: 'हवामान पहा' }, sub: { en: 'Spray Suitability', hi: 'स्प्रे अनुकूलता', mr: 'फवारणी वेळ' } },
      supply: { title: { en: 'Track Supply Chain', hi: 'सप्लाई चेन ट्रैकिंग', mr: 'सप्लाय चेन ट्रॅकिंग' }, sub: { en: 'Farm to Mandi', hi: 'खेत से मंडी', mr: 'शेतातून बाजारात' } },
      ai: { title: { en: 'Ask AI Assistant', hi: 'किसान AI से पूछें', mr: 'किसान AI ला विचारा' }, sub: { en: 'Voice & Text', hi: 'वॉइस और टेक्स्ट', mr: 'आवाज व संवाद' } },
      rec: { title: { en: 'Crop Selection', hi: 'फसल चयन', mr: 'पिक निवड' }, sub: { en: 'Best ROI Crop', hi: 'सर्वश्रेष्ठ फसल', mr: 'उत्कृष्ट नफा' } }
    },
    // AI Insights
    aiInsights: {
      title: { en: 'KisanAI Intelligence Insights', hi: 'किसान AI बुद्धिमत्ता सुझाव', mr: 'किसान AI स्मार्ट शेती सल्ला' },
      activeCount: { en: '4 Active Recommendations', hi: '4 सक्रिय सिफारिशें', mr: '४ सक्रिय शिफारशी' }
    },
    // Weather Widget
    weatherWidget: {
      title: { en: 'Live Weather Radar', hi: 'लाइव मौसम रडार', mr: 'थेट हवामान अंदाज' },
      viewFull: { en: 'View Full Weather', hi: 'पूरा मौसम देखें', mr: 'संपूर्ण हवामान पहा' },
      temp: { en: 'Temperature', hi: 'तापमान', mr: 'तापमान' },
      rain: { en: 'Rain Probability', hi: 'बारिश की संभावना', mr: 'पावसाची शक्यता' },
      wind: { en: 'Wind Speed', hi: 'हवा की गति', mr: 'वाऱ्याचा वेग' },
      advTitle: { en: "Today's Spraying Advisory:", hi: 'आज का छिड़काव सुझाव:', mr: 'आजचा फवारणी सल्ला:' },
      advText: {
        en: 'Optimal spray window: 6:30 AM – 9:30 AM. Low wind drift ensures zero chemical wastage.',
        hi: 'छिड़काव का सही समय: सुबह 6:30 से 9:30 बजे। कम हवा के कारण दवा बर्बाद नहीं होगी।',
        mr: 'फवारणीसाठी उत्तम वेळ: सकाळी ६:३० ते ९:३०. वारा शांत असल्याने औषध वाया जाणार नाही.'
      }
    },
    // Mandi Table Widget
    mandiWidget: {
      title: { en: 'Latest APMC Mandi Rates', hi: 'नवीनतम एपीएमसी मंडी भाव', mr: 'ताजे APMC बाजारभाव' },
      viewAll: { en: 'View All Prices', hi: 'सभी भाव देखें', mr: 'सर्व भाव पहा' }
    },
    // Schemes Widget
    schemesWidget: {
      title: { en: 'Government Schemes For You', hi: 'आपके लिए सरकारी योजनाएँ', mr: 'तुमच्यासाठी सरकारी योजना' },
      explore: { en: 'Explore All Schemes', hi: 'सभी योजनाएँ देखें', mr: 'सर्व योजना पहा' },
      totalFound: { en: '15 verified schemes found', hi: '15 कुल योजनाएँ उपलब्ध', mr: '१५ एकूण योजना उपलब्ध' },
      relevantCount: { en: '5 Highly Relevant', hi: '5 सबसे उपयुक्त', mr: '५ अत्यंत उपयुक्त' }
    },
    // Supply Chain Widget
    supplyWidget: {
      title: { en: 'Smart Supply Chain Tracker', hi: 'स्मार्ट सप्लाई चेन ट्रैकर', mr: 'स्मार्ट सप्लाय चेन ट्रॅकर' },
      trackBtn: { en: 'Track Supply Chain', hi: 'ट्रैक करें', mr: 'ट्रॅक करा' }
    },
    // Price Chart Widget
    chartWidget: {
      title: { en: 'Interactive APMC Market Price Trends', hi: 'इंटरएक्टिव मंडी भाव ग्राफ', mr: 'थेट दर घसरण व वाढ आलेख' },
      sub: { en: 'Compare historical price movement across major crops.', hi: 'प्रमुख फसलों की दरों की तुलना करें।', mr: 'प्रमुख पिकांच्या दरांचा तुलनात्मक आलेख.' }
    }
  };

  // Recharts Price Trend Data
  const chartData = [
    { day: 'Mon', Tomato: 2400, Onion: 2150, Wheat: 2420, Cotton: 7300, Soybean: 4500 },
    { day: 'Tue', Tomato: 2480, Onion: 2180, Wheat: 2430, Cotton: 7380, Soybean: 4550 },
    { day: 'Wed', Tomato: 2550, Onion: 2200, Wheat: 2450, Cotton: 7420, Soybean: 4600 },
    { day: 'Thu', Tomato: 2620, Onion: 2190, Wheat: 2460, Cotton: 7500, Soybean: 4620 },
    { day: 'Fri', Tomato: 2700, Onion: 2210, Wheat: 2470, Cotton: 7580, Soybean: 4650 },
    { day: 'Sat', Tomato: 2750, Onion: 2200, Wheat: 2480, Cotton: 7600, Soybean: 4660 },
    { day: 'Today', Tomato: 2800, Onion: 2200, Wheat: 2480, Cotton: 7650, Soybean: 4680 },
  ];

  return (
    <div className="space-y-6 bg-[#f4f7f5] text-slate-800 p-1 sm:p-2 rounded-3xl min-h-screen">
      
      {/* Top Scrolling Live APMC Mandi Ticker */}
      <LiveMandiTicker />

      {/* 1. DASHBOARD HEADER BANNER - Calm Light Sage Theme with Tractor & Google Badge */}
      <div className="bg-white border border-emerald-100/90 rounded-3xl p-6 sm:p-8 shadow-sm shadow-emerald-900/5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          
          <div className="space-y-1.5 flex-1">
            <div className="flex items-center space-x-2 flex-wrap gap-1.5">
              <span className="px-3 py-1 bg-emerald-100/80 text-emerald-800 border border-emerald-200 text-xs font-bold rounded-full flex items-center gap-1">
                <span>🚜</span>
                <span>{language === 'mr' ? textDict.badgeCmd.mr : language === 'hi' ? textDict.badgeCmd.hi : textDict.badgeCmd.en}</span>
              </span>
              <span className="px-2.5 py-0.5 bg-amber-100 text-amber-900 border border-amber-300 text-[11px] font-extrabold rounded-full flex items-center gap-1">
                {farmer?.email ? (
                  <>
                    <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                    </svg>
                    <span>Google Authenticated</span>
                  </>
                ) : farmer?.isRegistered ? (
                  <span>✓ {language === 'mr' ? textDict.badgeMode.verified.mr : language === 'hi' ? textDict.badgeMode.verified.hi : textDict.badgeMode.verified.en}</span>
                ) : (
                  <span>{language === 'mr' ? textDict.badgeMode.demo.mr : language === 'hi' ? textDict.badgeMode.demo.hi : textDict.badgeMode.demo.en}</span>
                )}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-outfit flex items-center gap-2">
              <span>{language === 'mr' ? textDict.greeting.mr : language === 'hi' ? textDict.greeting.hi : textDict.greeting.en}</span>
              <span className="text-xl">🌾</span>
            </h1>

            <p className="text-xs sm:text-sm text-slate-600">
              "{language === 'mr' ? textDict.subGreeting.mr : language === 'hi' ? textDict.subGreeting.hi : textDict.subGreeting.en}" • <strong className="text-emerald-700">{todayStr}</strong>
            </p>
          </div>

          {/* Top Right Quick Controls */}
          <div className="flex items-center space-x-2 self-start sm:self-center flex-wrap gap-2">
            
            {/* Notification Trigger Button */}
            <button
              onClick={() => openModal('notifications')}
              className="relative p-2.5 bg-emerald-50 hover:bg-emerald-100 text-slate-700 border border-emerald-200/80 rounded-2xl transition shadow-xs"
              title="Notification Center"
            >
              <Bell className="w-5 h-5 text-emerald-700" />
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-amber-500 text-white font-extrabold text-[10px] rounded-full flex items-center justify-center shadow-xs">
                4
              </span>
            </button>

            {/* Language Switcher */}
            <div className="flex items-center bg-emerald-50/80 rounded-2xl p-1 border border-emerald-200/80">
              {(['mr', 'hi', 'en'] as const).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setLanguage(lang)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition ${
                    language === lang ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {lang === 'mr' ? 'मराठी' : lang === 'hi' ? 'हिन्दी' : 'English'}
                </button>
              ))}
            </div>

            {/* Profile Button */}
            <button
              onClick={() => openModal('profile')}
              className="p-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 rounded-2xl transition flex items-center space-x-2 shadow-xs"
            >
              <User className="w-5 h-5 text-emerald-700" />
              <span className="text-xs font-bold hidden md:inline">
                {language === 'mr' ? 'प्रोफाईल' : language === 'hi' ? 'प्रोफाइल' : 'Profile'}
              </span>
            </button>

          </div>

        </div>
      </div>

      {/* 2. FARMER SUMMARY CARDS (6 Key Metrics in Clean Light Theme) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        
        {/* Card 1: My Crops */}
        <div
          onClick={() => openModal('cropLifecycle')}
          className="bg-white border border-emerald-100 hover:border-emerald-300 p-4 rounded-2xl space-y-2 cursor-pointer transition hover:scale-102 shadow-xs"
        >
          <div className="flex items-center justify-between text-emerald-700">
            <Sprout className="w-5 h-5" />
            <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
              {language === 'mr' ? textDict.cards.myCrops.badge.mr : language === 'hi' ? textDict.cards.myCrops.badge.hi : textDict.cards.myCrops.badge.en}
            </span>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">6</div>
            <div className="text-xs text-slate-600 font-semibold">
              {language === 'mr' ? textDict.cards.myCrops.title.mr : language === 'hi' ? textDict.cards.myCrops.title.hi : textDict.cards.myCrops.title.en}
            </div>
          </div>
          <div className="text-[10px] text-emerald-700 font-bold flex items-center space-x-1">
            <span>{language === 'mr' ? textDict.cards.myCrops.action.mr : language === 'hi' ? textDict.cards.myCrops.action.hi : textDict.cards.myCrops.action.en}</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>

        {/* Card 2: Mandi Price */}
        <div
          onClick={() => openModal('mandiPrices')}
          className="bg-white border border-emerald-100 hover:border-emerald-300 p-4 rounded-2xl space-y-2 cursor-pointer transition hover:scale-102 shadow-xs"
        >
          <div className="flex items-center justify-between text-emerald-700">
            <TrendingUp className="w-5 h-5" />
            <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">+8.4%</span>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">₹2,850/q</div>
            <div className="text-xs text-slate-600 font-semibold">
              {language === 'mr' ? textDict.cards.mandiPrice.title.mr : language === 'hi' ? textDict.cards.mandiPrice.title.hi : textDict.cards.mandiPrice.title.en}
            </div>
          </div>
          <div className="text-[10px] text-emerald-700 font-bold flex items-center space-x-1">
            <span>{language === 'mr' ? textDict.cards.mandiPrice.action.mr : language === 'hi' ? textDict.cards.mandiPrice.action.hi : textDict.cards.mandiPrice.action.en}</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>

        {/* Card 3: Weather */}
        <div
          onClick={() => openModal('weatherAdvisory')}
          className="bg-white border border-emerald-100 hover:border-emerald-300 p-4 rounded-2xl space-y-2 cursor-pointer transition hover:scale-102 shadow-xs"
        >
          <div className="flex items-center justify-between text-sky-600">
            <CloudSun className="w-5 h-5" />
            <span className="text-[10px] font-bold bg-sky-100 text-sky-800 px-2 py-0.5 rounded-full">
              {language === 'mr' ? textDict.cards.weather.badge.mr : language === 'hi' ? textDict.cards.weather.badge.hi : textDict.cards.weather.badge.en}
            </span>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">28°C</div>
            <div className="text-xs text-slate-600 font-semibold">
              {language === 'mr' ? textDict.cards.weather.title.mr : language === 'hi' ? textDict.cards.weather.title.hi : textDict.cards.weather.title.en}
            </div>
          </div>
          <div className="text-[10px] text-sky-700 font-bold flex items-center space-x-1">
            <span>{language === 'mr' ? textDict.cards.weather.action.mr : language === 'hi' ? textDict.cards.weather.action.hi : textDict.cards.weather.action.en}</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>

        {/* Card 4: Estimated Earnings */}
        <div
          onClick={() => openModal('profitPrediction')}
          className="bg-white border border-emerald-100 hover:border-emerald-300 p-4 rounded-2xl space-y-2 cursor-pointer transition hover:scale-102 shadow-xs"
        >
          <div className="flex items-center justify-between text-amber-600">
            <DollarSign className="w-5 h-5" />
            <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">Est. ROI</span>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">₹4.2L</div>
            <div className="text-xs text-slate-600 font-semibold">
              {language === 'mr' ? textDict.cards.earnings.title.mr : language === 'hi' ? textDict.cards.earnings.title.hi : textDict.cards.earnings.title.en}
            </div>
          </div>
          <div className="text-[10px] text-amber-700 font-bold flex items-center space-x-1">
            <span>{language === 'mr' ? textDict.cards.earnings.action.mr : language === 'hi' ? textDict.cards.earnings.action.hi : textDict.cards.earnings.action.en}</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>

        {/* Card 5: Active Shipments */}
        <div
          onClick={() => openModal('supplyChain')}
          className="bg-white border border-emerald-100 hover:border-emerald-300 p-4 rounded-2xl space-y-2 cursor-pointer transition hover:scale-102 shadow-xs"
        >
          <div className="flex items-center justify-between text-purple-600">
            <Truck className="w-5 h-5" />
            <span className="text-[10px] font-bold bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full">Transit</span>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">3</div>
            <div className="text-xs text-slate-600 font-semibold">
              {language === 'mr' ? textDict.cards.shipments.title.mr : language === 'hi' ? textDict.cards.shipments.title.hi : textDict.cards.shipments.title.en}
            </div>
          </div>
          <div className="text-[10px] text-purple-700 font-bold flex items-center space-x-1">
            <span>{language === 'mr' ? textDict.cards.shipments.action.mr : language === 'hi' ? textDict.cards.shipments.action.hi : textDict.cards.shipments.action.en}</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>

        {/* Card 6: Available Schemes */}
        <div
          onClick={() => openModal('schemes')}
          className="bg-white border border-emerald-100 hover:border-emerald-300 p-4 rounded-2xl space-y-2 cursor-pointer transition hover:scale-102 shadow-xs"
        >
          <div className="flex items-center justify-between text-teal-700">
            <Landmark className="w-5 h-5" />
            <span className="text-[10px] font-bold bg-teal-100 text-teal-800 px-2 py-0.5 rounded-full">5 Match</span>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">15</div>
            <div className="text-xs text-slate-600 font-semibold">
              {language === 'mr' ? textDict.cards.schemes.title.mr : language === 'hi' ? textDict.cards.schemes.title.hi : textDict.cards.schemes.title.en}
            </div>
          </div>
          <div className="text-[10px] text-teal-700 font-bold flex items-center space-x-1">
            <span>{language === 'mr' ? textDict.cards.schemes.action.mr : language === 'hi' ? textDict.cards.schemes.action.hi : textDict.cards.schemes.action.en}</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>

      </div>

      {/* 3. FARM OVERVIEW & QUICK ACTIONS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Large Farm Overview Card */}
        <div className="lg:col-span-1 bg-white border border-emerald-100/90 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-emerald-600" />
              <h3 className="text-base font-bold text-slate-900">
                {language === 'mr' ? textDict.overview.title.mr : language === 'hi' ? textDict.overview.title.hi : textDict.overview.title.en}
              </h3>
            </div>
            <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-200">
              {language === 'mr' ? textDict.overview.demoBadge.mr : language === 'hi' ? textDict.overview.demoBadge.hi : textDict.overview.demoBadge.en}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">{language === 'mr' ? textDict.overview.loc.mr : language === 'hi' ? textDict.overview.loc.hi : textDict.overview.loc.en}</span>
              <strong className="text-slate-800">{farmer?.village || 'Katol'}, {farmer?.district || 'Nagpur'}, {farmer?.state || 'Maharashtra'}</strong>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">{language === 'mr' ? textDict.overview.land.mr : language === 'hi' ? textDict.overview.land.hi : textDict.overview.land.en}</span>
              <strong className="text-emerald-700 font-extrabold">{farmer?.landArea || farmer?.totalLandAcres || 4.5} Acres</strong>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">{language === 'mr' ? textDict.overview.crops.mr : language === 'hi' ? textDict.overview.crops.hi : textDict.overview.crops.en}</span>
              <strong className="text-slate-800">{farmer?.mainCrop || 'Cotton, Soybean & Tomato'}</strong>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">{language === 'mr' ? textDict.overview.soil.mr : language === 'hi' ? textDict.overview.soil.hi : textDict.overview.soil.en}</span>
              <strong className="text-slate-800">{farmer?.soilType || 'Black Soil'} • {farmer?.irrigationSource || 'Drip/Well'}</strong>
            </div>

            <div className="flex justify-between py-1.5">
              <span className="text-slate-500">{language === 'mr' ? textDict.overview.rev.mr : language === 'hi' ? textDict.overview.rev.hi : textDict.overview.rev.en}</span>
              <strong className="text-amber-700 font-extrabold text-sm">₹4,25,000 / Season</strong>
            </div>
          </div>

          <button
            onClick={() => openModal('profile')}
            className="w-full py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1"
          >
            <span>{language === 'mr' ? textDict.overview.editBtn.mr : language === 'hi' ? textDict.overview.editBtn.hi : textDict.overview.editBtn.en}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Actions Grid (2 cols on right) */}
        <div className="lg:col-span-2 bg-white border border-emerald-100/90 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <span>{language === 'mr' ? textDict.quickActions.title.mr : language === 'hi' ? textDict.quickActions.title.hi : textDict.quickActions.title.en}</span>
            </h3>
            <span className="text-xs text-slate-500">{language === 'mr' ? textDict.quickActions.subtitle.mr : language === 'hi' ? textDict.quickActions.subtitle.hi : textDict.quickActions.subtitle.en}</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            
            <button
              onClick={() => openModal('diagnose')}
              className="p-3.5 bg-emerald-50/50 border border-emerald-100 hover:border-emerald-300 rounded-2xl text-left space-y-2 group transition hover:scale-102 shadow-xs"
            >
              <div className="p-2.5 bg-emerald-600 text-white rounded-xl w-fit shadow-xs">
                <Scan className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-700">
                  {language === 'mr' ? textDict.quickActions.detect.title.mr : language === 'hi' ? textDict.quickActions.detect.title.hi : textDict.quickActions.detect.title.en}
                </div>
                <div className="text-[10px] text-slate-500">
                  {language === 'mr' ? textDict.quickActions.detect.sub.mr : language === 'hi' ? textDict.quickActions.detect.sub.hi : textDict.quickActions.detect.sub.en}
                </div>
              </div>
            </button>

            <button
              onClick={() => openModal('mandiPrices')}
              className="p-3.5 bg-amber-50/50 border border-amber-100 hover:border-amber-300 rounded-2xl text-left space-y-2 group transition hover:scale-102 shadow-xs"
            >
              <div className="p-2.5 bg-amber-500 text-white rounded-xl w-fit shadow-xs">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-amber-700">
                  {language === 'mr' ? textDict.quickActions.mandi.title.mr : language === 'hi' ? textDict.quickActions.mandi.title.hi : textDict.quickActions.mandi.title.en}
                </div>
                <div className="text-[10px] text-slate-500">
                  {language === 'mr' ? textDict.quickActions.mandi.sub.mr : language === 'hi' ? textDict.quickActions.mandi.sub.hi : textDict.quickActions.mandi.sub.en}
                </div>
              </div>
            </button>

            <button
              onClick={() => openModal('schemes')}
              className="p-3.5 bg-teal-50/50 border border-teal-100 hover:border-teal-300 rounded-2xl text-left space-y-2 group transition hover:scale-102 shadow-xs"
            >
              <div className="p-2.5 bg-teal-600 text-white rounded-xl w-fit shadow-xs">
                <Landmark className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-teal-700">
                  {language === 'mr' ? textDict.quickActions.schemes.title.mr : language === 'hi' ? textDict.quickActions.schemes.title.hi : textDict.quickActions.schemes.title.en}
                </div>
                <div className="text-[10px] text-slate-500">
                  {language === 'mr' ? textDict.quickActions.schemes.sub.mr : language === 'hi' ? textDict.quickActions.schemes.sub.hi : textDict.quickActions.schemes.sub.en}
                </div>
              </div>
            </button>

            <button
              onClick={() => openModal('cropLifecycle')}
              className="p-3.5 bg-purple-50/50 border border-purple-100 hover:border-purple-300 rounded-2xl text-left space-y-2 group transition hover:scale-102 shadow-xs"
            >
              <div className="p-2.5 bg-purple-600 text-white rounded-xl w-fit shadow-xs">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-purple-700">
                  {language === 'mr' ? textDict.quickActions.plan.title.mr : language === 'hi' ? textDict.quickActions.plan.title.hi : textDict.quickActions.plan.title.en}
                </div>
                <div className="text-[10px] text-slate-500">
                  {language === 'mr' ? textDict.quickActions.plan.sub.mr : language === 'hi' ? textDict.quickActions.plan.sub.hi : textDict.quickActions.plan.sub.en}
                </div>
              </div>
            </button>

            <button
              onClick={() => openModal('weatherAdvisory')}
              className="p-3.5 bg-sky-50/50 border border-sky-100 hover:border-sky-300 rounded-2xl text-left space-y-2 group transition hover:scale-102 shadow-xs"
            >
              <div className="p-2.5 bg-sky-600 text-white rounded-xl w-fit shadow-xs">
                <CloudSun className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-sky-700">
                  {language === 'mr' ? textDict.quickActions.weather.title.mr : language === 'hi' ? textDict.quickActions.weather.title.hi : textDict.quickActions.weather.title.en}
                </div>
                <div className="text-[10px] text-slate-500">
                  {language === 'mr' ? textDict.quickActions.weather.sub.mr : language === 'hi' ? textDict.quickActions.weather.sub.hi : textDict.quickActions.weather.sub.en}
                </div>
              </div>
            </button>

            <button
              onClick={() => openModal('supplyChain')}
              className="p-3.5 bg-rose-50/50 border border-rose-100 hover:border-rose-300 rounded-2xl text-left space-y-2 group transition hover:scale-102 shadow-xs"
            >
              <div className="p-2.5 bg-rose-600 text-white rounded-xl w-fit shadow-xs">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-rose-700">
                  {language === 'mr' ? textDict.quickActions.supply.title.mr : language === 'hi' ? textDict.quickActions.supply.title.hi : textDict.quickActions.supply.title.en}
                </div>
                <div className="text-[10px] text-slate-500">
                  {language === 'mr' ? textDict.quickActions.supply.sub.mr : language === 'hi' ? textDict.quickActions.supply.sub.hi : textDict.quickActions.supply.sub.en}
                </div>
              </div>
            </button>

            <button
              onClick={() => openModal('askAi')}
              className="p-3.5 bg-indigo-50/50 border border-indigo-100 hover:border-indigo-300 rounded-2xl text-left space-y-2 group transition hover:scale-102 shadow-xs"
            >
              <div className="p-2.5 bg-indigo-600 text-white rounded-xl w-fit shadow-xs">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-indigo-700">
                  {language === 'mr' ? textDict.quickActions.ai.title.mr : language === 'hi' ? textDict.quickActions.ai.title.hi : textDict.quickActions.ai.title.en}
                </div>
                <div className="text-[10px] text-slate-500">
                  {language === 'mr' ? textDict.quickActions.ai.sub.mr : language === 'hi' ? textDict.quickActions.ai.sub.hi : textDict.quickActions.ai.sub.en}
                </div>
              </div>
            </button>

            <button
              onClick={() => openModal('cropRecommendation')}
              className="p-3.5 bg-emerald-50/50 border border-emerald-100 hover:border-emerald-300 rounded-2xl text-left space-y-2 group transition hover:scale-102 shadow-xs"
            >
              <div className="p-2.5 bg-emerald-600 text-white rounded-xl w-fit shadow-xs">
                <Sprout className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-700">
                  {language === 'mr' ? textDict.quickActions.rec.title.mr : language === 'hi' ? textDict.quickActions.rec.title.hi : textDict.quickActions.rec.title.en}
                </div>
                <div className="text-[10px] text-slate-500">
                  {language === 'mr' ? textDict.quickActions.rec.sub.mr : language === 'hi' ? textDict.quickActions.rec.sub.hi : textDict.quickActions.rec.sub.en}
                </div>
              </div>
            </button>

          </div>
        </div>

      </div>

      {/* 4. AI FARMING INSIGHTS ("KisanAI Intelligence") */}
      <div className="bg-white border border-emerald-100/90 rounded-3xl p-6 space-y-4 shadow-xs">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <Bot className="w-5 h-5 text-amber-500" />
            <h3 className="text-base font-bold text-slate-900">
              {language === 'mr' ? textDict.aiInsights.title.mr : language === 'hi' ? textDict.aiInsights.title.hi : textDict.aiInsights.title.en}
            </h3>
          </div>
          <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-200">
            {language === 'mr' ? textDict.aiInsights.activeCount.mr : language === 'hi' ? textDict.aiInsights.activeCount.hi : textDict.aiInsights.activeCount.en}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="bg-rose-50/60 p-4 rounded-2xl border border-rose-100 space-y-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-rose-700 flex items-center space-x-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>🌱 Crop Health Alert</span>
            </span>
            <h4 className="text-xs font-bold text-slate-900">
              {language === 'mr' ? 'टोमॅटो करपा रोग चेतावणी' : language === 'hi' ? 'टमाटर रोग चेतावनी' : 'Tomato Leaf Blight Warning'}
            </h4>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              {language === 'mr' ? 'हवेतील दमटपणा ८५% आहे. करपा रोगापासून बचावासाठी डायफेनकोनाझोल १५ मिली/१५L फवारा.' : 'High humidity (85%). Spray Difenoconazole @ 15ml/15L pump for protection.'}
            </p>
          </div>

          <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100 space-y-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-700 flex items-center space-x-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>💰 Market Insight</span>
            </span>
            <h4 className="text-xs font-bold text-slate-900">
              {language === 'mr' ? 'टोमॅटो दर +१२% वाढले' : language === 'hi' ? 'टमाटर भाव में +12% उछाल' : 'Tomato Prices Up +12%'}
            </h4>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              {language === 'mr' ? 'कळमना एपीएमसीमध्ये दर ₹२,८००/क्विंटलवर पोहोचले. माल विकण्यासाठी उत्तम वेळ.' : 'Kalamna APMC reached ₹2,800/quintal. Recommended window to sell.'}
            </p>
          </div>

          <div className="bg-sky-50/60 p-4 rounded-2xl border border-sky-100 space-y-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-sky-700 flex items-center space-x-1">
              <CloudSun className="w-3.5 h-3.5" />
              <span>🌦 Weather Advisory</span>
            </span>
            <h4 className="text-xs font-bold text-slate-900">
              {language === 'mr' ? 'उद्या पावसाचा अंदाज' : language === 'hi' ? 'कल बारिश की संभावना' : 'Rain Expected Tomorrow'}
            </h4>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              {language === 'mr' ? 'हल्क्या ते मध्यम पावसाचा अंदाज. संध्याकाळचे सिंचन २४ तास पुढे ढकला.' : 'Moderate rainfall forecast. Postpone evening irrigation by 24h.'}
            </p>
          </div>

          <div className="bg-purple-50/60 p-4 rounded-2xl border border-purple-100 space-y-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-purple-700 flex items-center space-x-1">
              <Truck className="w-3.5 h-3.5" />
              <span>🚚 Supply Chain</span>
            </span>
            <h4 className="text-xs font-bold text-slate-900">
              {language === 'mr' ? 'वाहतूक #KS102 हायवेवर' : language === 'hi' ? 'गाड़ी #KS102 रास्ते में' : 'Shipment #KS102 In Transit'}
            </h4>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              {language === 'mr' ? '५० क्विंटल कापसाची गाडी टोल प्लाझा पार झाली. २.५ तासात एपीएमसी आगमन.' : '50 Qtl Cotton vehicle crossed toll. Mandi arrival in 2.5 hrs.'}
            </p>
          </div>

        </div>
      </div>

      {/* 5. WEATHER & MANDI PRICE SUMMARY (2 COLUMNS IN LIGHT THEME) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Compact Weather Summary Widget */}
        <div className="bg-white border border-emerald-100/90 rounded-3xl p-6 space-y-4 shadow-xs flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <CloudSun className="w-5 h-5 text-sky-600" />
                <h3 className="text-base font-bold text-slate-900">
                  {language === 'mr' ? textDict.weatherWidget.title.mr : language === 'hi' ? textDict.weatherWidget.title.hi : textDict.weatherWidget.title.en}
                </h3>
              </div>
              <button
                onClick={() => openModal('weatherAdvisory')}
                className="text-xs font-bold text-emerald-700 hover:underline flex items-center space-x-1"
              >
                <span>{language === 'mr' ? textDict.weatherWidget.viewFull.mr : language === 'hi' ? textDict.weatherWidget.viewFull.hi : textDict.weatherWidget.viewFull.en}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-3 bg-emerald-50/40 p-4 rounded-2xl border border-emerald-100 text-center">
              <div>
                <span className="text-[10px] text-slate-500 block font-semibold">{language === 'mr' ? textDict.weatherWidget.temp.mr : language === 'hi' ? textDict.weatherWidget.temp.hi : textDict.weatherWidget.temp.en}</span>
                <strong className="text-xl font-extrabold text-slate-900">28°C</strong>
                <span className="text-[10px] text-emerald-700 block font-semibold">Low Evaporation</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block font-semibold">{language === 'mr' ? textDict.weatherWidget.rain.mr : language === 'hi' ? textDict.weatherWidget.rain.hi : textDict.weatherWidget.rain.en}</span>
                <strong className="text-xl font-extrabold text-sky-700">10%</strong>
                <span className="text-[10px] text-sky-700 block font-semibold">No Risk</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block font-semibold">{language === 'mr' ? textDict.weatherWidget.wind.mr : language === 'hi' ? textDict.weatherWidget.wind.hi : textDict.weatherWidget.wind.en}</span>
                <strong className="text-xl font-extrabold text-slate-900">9 km/h</strong>
                <span className="text-[10px] text-emerald-700 block font-semibold">Spray Safe</span>
              </div>
            </div>

            <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-2xl text-xs text-emerald-900 space-y-1">
              <strong className="text-emerald-800 font-bold block">
                {language === 'mr' ? textDict.weatherWidget.advTitle.mr : language === 'hi' ? textDict.weatherWidget.advTitle.hi : textDict.weatherWidget.advTitle.en}
              </strong>
              <p>
                {language === 'mr' ? textDict.weatherWidget.advText.mr : language === 'hi' ? textDict.weatherWidget.advText.hi : textDict.weatherWidget.advText.en}
              </p>
            </div>
          </div>
        </div>

        {/* Live Mandi Price Summary Table */}
        <div className="bg-white border border-emerald-100/90 rounded-3xl p-6 space-y-4 shadow-xs flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-bold text-slate-900">
                  {language === 'mr' ? textDict.mandiWidget.title.mr : language === 'hi' ? textDict.mandiWidget.title.hi : textDict.mandiWidget.title.en}
                </h3>
              </div>
              <button
                onClick={() => openModal('mandiPrices')}
                className="text-xs font-bold text-emerald-700 hover:underline flex items-center space-x-1"
              >
                <span>{language === 'mr' ? textDict.mandiWidget.viewAll.mr : language === 'hi' ? textDict.mandiWidget.viewAll.hi : textDict.mandiWidget.viewAll.en}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2">
              {[
                { crop: 'Tomato (टमाटर)', market: 'Nagpur APMC', price: '₹2,800/q', change: '+12.0%', trend: 'up' },
                { crop: 'Cotton (कापूस)', market: 'Yavatmal APMC', price: '₹7,650/q', change: '+3.5%', trend: 'up' },
                { crop: 'Soybean (सोयाबीन)', market: 'Indore Mandi', price: '₹4,680/q', change: '-1.8%', trend: 'down' },
                { crop: 'Onion (कांदा)', market: 'Lasalgaon APMC', price: '₹2,200/q', change: '+8.5%', trend: 'up' },
              ].map((row, idx) => (
                <div
                  key={idx}
                  onClick={() => openModal('mandiPrices')}
                  className="bg-slate-50 hover:bg-emerald-50/80 p-3 rounded-xl border border-slate-200/70 hover:border-emerald-300 flex items-center justify-between text-xs cursor-pointer transition-colors"
                >
                  <div>
                    <strong className="text-slate-900 block font-bold">{row.crop}</strong>
                    <span className="text-[10px] text-slate-500">{row.market}</span>
                  </div>
                  <div className="text-right">
                    <strong className="text-emerald-700 font-extrabold block text-sm">{row.price}</strong>
                    <span className={`text-[10px] font-bold ${row.trend === 'up' ? 'text-emerald-700' : 'text-rose-600'}`}>
                      {row.change}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* 6. GOVERNMENT SCHEMES & SMART SUPPLY CHAIN (2 COLUMNS IN LIGHT THEME) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Government Schemes Summary Card */}
        <div className="bg-white border border-emerald-100/90 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center space-x-2">
              <Landmark className="w-5 h-5 text-amber-600" />
              <h3 className="text-base font-bold text-slate-900">
                {language === 'mr' ? textDict.schemesWidget.title.mr : language === 'hi' ? textDict.schemesWidget.title.hi : textDict.schemesWidget.title.en}
              </h3>
            </div>
            <button
              onClick={() => openModal('schemes')}
              className="text-xs font-bold text-emerald-700 hover:underline flex items-center space-x-1"
            >
              <span>{language === 'mr' ? textDict.schemesWidget.explore.mr : language === 'hi' ? textDict.schemesWidget.explore.hi : textDict.schemesWidget.explore.en}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl text-xs text-amber-900 flex items-center justify-between font-semibold">
            <span>{language === 'mr' ? textDict.schemesWidget.totalFound.mr : language === 'hi' ? textDict.schemesWidget.totalFound.hi : textDict.schemesWidget.totalFound.en}</span>
            <strong className="bg-amber-500 text-slate-950 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold shadow-xs">
              {language === 'mr' ? textDict.schemesWidget.relevantCount.mr : language === 'hi' ? textDict.schemesWidget.relevantCount.hi : textDict.schemesWidget.relevantCount.en}
            </strong>
          </div>

          <div className="space-y-2">
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/70 space-y-1">
              <div className="flex items-center justify-between">
                <strong className="text-xs font-bold text-slate-900">PM-KISAN ₹6,000 Direct Income Support</strong>
                <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full border border-blue-200">Central</span>
              </div>
              <p className="text-[11px] text-slate-600">Direct transfer of ₹2,000 every 4 months into farmer bank account.</p>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/70 space-y-1">
              <div className="flex items-center justify-between">
                <strong className="text-xs font-bold text-slate-900">Namo Shetkari Maha Samman Nidhi (MH)</strong>
                <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full border border-amber-200">State</span>
              </div>
              <p className="text-[11px] text-slate-600">Maharashtra top-up grant of ₹6,000/year (Total ₹12,000 with PM-KISAN).</p>
            </div>
          </div>
        </div>

        {/* Smart Supply Chain Summary Card */}
        <div className="bg-white border border-emerald-100/90 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center space-x-2">
              <Truck className="w-5 h-5 text-purple-600" />
              <h3 className="text-base font-bold text-slate-900">
                {language === 'mr' ? textDict.supplyWidget.title.mr : language === 'hi' ? textDict.supplyWidget.title.hi : textDict.supplyWidget.title.en}
              </h3>
            </div>
            <button
              onClick={() => openModal('supplyChain')}
              className="text-xs font-bold text-emerald-700 hover:underline flex items-center space-x-1"
            >
              <span>{language === 'mr' ? textDict.supplyWidget.trackBtn.mr : language === 'hi' ? textDict.supplyWidget.trackBtn.hi : textDict.supplyWidget.trackBtn.en}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mini Visual Timeline */}
          <div className="flex items-center justify-between bg-slate-50 p-3 rounded-2xl border border-slate-200/70 text-[10px] text-slate-600 font-bold">
            <span className="text-emerald-700">🌾 Harvested</span>
            <span>↓</span>
            <span className="text-emerald-700">📦 Collected</span>
            <span>↓</span>
            <span className="text-amber-700">🚚 In Transit</span>
            <span>↓</span>
            <span>🏬 Mandi</span>
          </div>

          {/* Active Shipment Preview Card */}
          <div className="bg-purple-50/50 p-4 rounded-xl border border-purple-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-purple-900">Shipment #SHIP-2026-9041</span>
              <span className="text-xs font-extrabold text-amber-700">75% Progress</span>
            </div>
            <p className="text-xs text-slate-800 font-semibold">Cotton (50 Quintals) • Nagpur Kalamna APMC</p>
            <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
              <div className="bg-purple-600 h-full w-[75%]" />
            </div>
          </div>
        </div>

      </div>

      {/* 7. PRICE TREND ANALYTICS RECHARTS GRAPH IN LIGHT THEME */}
      <div className="bg-white border border-emerald-100/90 rounded-3xl p-6 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center space-x-2">
              <BarChart2 className="w-5 h-5 text-emerald-600" />
              <span>
                {language === 'mr' ? textDict.chartWidget.title.mr : language === 'hi' ? textDict.chartWidget.title.hi : textDict.chartWidget.title.en}
              </span>
            </h3>
            <p className="text-xs text-slate-500">
              {language === 'mr' ? textDict.chartWidget.sub.mr : language === 'hi' ? textDict.chartWidget.sub.hi : textDict.chartWidget.sub.en}
            </p>
          </div>

          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
            {['Tomato', 'Cotton', 'Soybean', 'Wheat', 'Onion'].map((c) => (
              <button
                key={c}
                onClick={() => setSelectedCropChart(c)}
                className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                  selectedCropChart === c ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <div className="h-64 bg-emerald-50/30 p-4 rounded-2xl border border-emerald-100">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="chartGradLight" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#059669" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#059669" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#cbd5e1" />
              <XAxis dataKey="day" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={12} domain={['auto', 'auto']} />
              <Tooltip contentStyle={{ backgroundColor: '#ffffff', borderColor: '#059669', borderRadius: '0.75rem', color: '#0f172a' }} />
              <Area type="monotone" dataKey={selectedCropChart} stroke="#059669" strokeWidth={3} fillOpacity={1} fill="url(#chartGradLight)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 8. FLOATING AI ASSISTANT TRIGGER BUTTON */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => openModal('askAi')}
          className="px-5 py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold rounded-full shadow-xl shadow-emerald-700/30 flex items-center space-x-2.5 hover:scale-105 active:scale-95 transition cursor-pointer border border-emerald-300/40"
        >
          <Bot className="w-6 h-6 text-white animate-bounce" />
          <span className="text-sm">
            {language === 'mr' ? 'किसान AI ला विचारा' : language === 'hi' ? 'किसान AI से पूछें' : 'KisanAI Assistant'}
          </span>
        </button>
      </div>

    </div>
  );
};
