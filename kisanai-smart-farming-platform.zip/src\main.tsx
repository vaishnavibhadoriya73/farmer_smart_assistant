import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Guard against unhandled popup-blocked rejections leaking into window.onerror
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    if (
      reason?.code === 'auth/popup-blocked' ||
      reason?.message?.includes('popup-blocked') ||
      reason?.code === 'auth/cancelled-popup-request' ||
      reason?.code === 'auth/popup-closed-by-user'
    ) {
      event.preventDefault();
      console.warn('Handled authentication popup notice in preview environment:', reason?.code || reason?.message);
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
