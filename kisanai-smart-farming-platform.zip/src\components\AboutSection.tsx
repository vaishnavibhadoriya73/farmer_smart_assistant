import React from 'react';
import { motion } from 'motion/react';
import {
  ShieldCheck,
  Cpu,
  Sprout,
  Users,
  Award,
  Globe2,
  Sparkles,
  CheckCircle,
  TrendingUp,
  HeartHandshake,
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-16 sm:py-24 relative overflow-hidden bg-emerald-50/50 dark:bg-emerald-950/30 border-t border-emerald-500/20">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/15 dark:bg-emerald-500/20 border border-emerald-500/30 text-emerald-900 dark:text-emerald-300 text-xs font-bold shadow-sm">
              <Sparkles className="w-4 h-4 text-emerald-500" />
              <span>Mission: Digital Agritech Sovereignty for Indian Kisans</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-emerald-950 dark:text-white font-outfit tracking-tight leading-tight">
              Bridging Cutting-Edge AI with India’s Grassroots Agriculture
            </h2>

            <p className="text-sm sm:text-base text-zinc-700 dark:text-emerald-100/80 leading-relaxed font-normal">
              KisanAI was founded by agricultural scientists, agronomists, and artificial intelligence researchers to solve everyday farming hurdles: unpredictable crop diseases, volatile wholesale mandi markets, and confusing government subsidies.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-white/90 dark:bg-emerald-900/40 border border-emerald-500/25 shadow-md">
                <ShieldCheck className="w-6 h-6 text-emerald-500 mb-2" />
                <h4 className="text-sm font-bold text-emerald-950 dark:text-white mb-1">
                  ICAR & KVK Grounded
                </h4>
                <p className="text-xs text-zinc-600 dark:text-emerald-300/80">
                  Every recommendation is strictly aligned with the Indian Council of Agricultural Research guidelines.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white/90 dark:bg-emerald-900/40 border border-emerald-500/25 shadow-md">
                <Globe2 className="w-6 h-6 text-teal-500 mb-2" />
                <h4 className="text-sm font-bold text-emerald-950 dark:text-white mb-1">
                  Vernacular First
                </h4>
                <p className="text-xs text-zinc-600 dark:text-emerald-300/80">
                  Voice interaction tuned for regional farmer dialects in Hindi, Marathi, Gujarati, Telugu and more.
                </p>
              </div>
            </div>

            {/* Quick Impact Highlight */}
            <div className="flex items-center gap-4 pt-2 text-xs font-semibold text-emerald-800 dark:text-emerald-300">
              <span className="flex items-center gap-1.5">
                <HeartHandshake className="w-4 h-4 text-emerald-500" /> 100% Free & Open for Farmers
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-emerald-500" /> 30% Avg. Farm Yield Increase
              </span>
            </div>
          </div>

          {/* Right Column: Visual Photo Card with Real Indian Woman Farmer & Tech HUD */}
          <div className="lg:col-span-6">
            <div className="relative rounded-3xl overflow-hidden border-2 border-emerald-500/30 shadow-2xl shadow-emerald-950/40 group">
              {/* Photo of Empowered Farmer */}
              <div className="relative aspect-[4/3] sm:aspect-[16/11] overflow-hidden">
                <img
                  src="/assets/farmer_woman.jpg"
                  alt="Empowered Indian Woman Farmer using KisanAI Smart Agritech"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/90 via-emerald-950/20 to-transparent pointer-events-none" />

                {/* Top Badge */}
                <div className="absolute top-4 left-4 z-20 flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/85 backdrop-blur-md border border-emerald-500/40 text-emerald-200 text-xs font-bold shadow-lg">
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>Empowering 50,000+ Rural Kisans</span>
                </div>

                {/* Bottom Overlay Card */}
                <div className="absolute bottom-4 left-4 right-4 z-20 p-4 rounded-2xl bg-white/95 dark:bg-emerald-950/90 backdrop-blur-xl border border-emerald-500/30 shadow-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-500 flex items-center justify-center font-bold">
                        🌱
                      </div>
                      <div>
                        <h4 className="text-xs font-black text-emerald-950 dark:text-white">
                          Smart Agronomy in Action
                        </h4>
                        <p className="text-[10px] text-emerald-700 dark:text-emerald-400">
                          Wheat & Cotton Field Trial • Nashik, Maharashtra
                        </p>
                      </div>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                      +28% Net Profit
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-1 border-t border-emerald-500/15 text-center">
                    <div className="p-1.5 rounded-xl bg-emerald-500/10 dark:bg-emerald-900/30">
                      <div className="text-[10px] text-zinc-500 dark:text-emerald-400">Pest Reduction</div>
                      <div className="text-xs font-bold text-emerald-800 dark:text-emerald-200 font-mono">-45%</div>
                    </div>
                    <div className="p-1.5 rounded-xl bg-emerald-500/10 dark:bg-emerald-900/30">
                      <div className="text-[10px] text-zinc-500 dark:text-emerald-400">Water Saved</div>
                      <div className="text-xs font-bold text-emerald-800 dark:text-emerald-200 font-mono">3.2M L</div>
                    </div>
                    <div className="p-1.5 rounded-xl bg-emerald-500/10 dark:bg-emerald-900/30">
                      <div className="text-[10px] text-zinc-500 dark:text-emerald-400">Accuracy</div>
                      <div className="text-xs font-bold text-emerald-800 dark:text-emerald-200 font-mono">98.4%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
