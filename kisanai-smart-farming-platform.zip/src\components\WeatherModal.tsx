import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CloudSun,
  Sun,
  CloudRain,
  Wind,
  Droplets,
  Eye,
  CheckCircle,
  AlertTriangle,
  X,
  Sparkles,
  MapPin,
  Volume2,
  VolumeX,
  Gauge,
  Waves,
  Calendar,
  Layers,
  ThermometerSun,
  ShieldAlert,
  ArrowRight,
  Info,
  RefreshCw,
  Clock,
  Flame,
  CloudLightning,
  Navigation,
  ExternalLink,
  ShieldCheck,
  SprayCan as Spray,
  FlaskConical,
  Beaker,
  Compass,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { WeatherData, WeatherAlert, SmartIrrigationAdvisory, TreatmentWeatherAdvisory } from '../types';

export const WeatherModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    openModal,
    farmer,
    crops,
    language,
    speakText,
    isSpeaking,
    stopSpeaking,
    currentGps,
    openGoogleMaps,
  } = useApp();

  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [treatmentAdvisory, setTreatmentAdvisory] = useState<TreatmentWeatherAdvisory | null>(null);
  const [loading, setLoading] = useState(false);
  const [treatmentLoading, setTreatmentLoading] = useState(false);
  const [selectedCrop, setSelectedCrop] = useState(crops[0]?.name || 'कांदा (Onion)');
  const [selectedStage, setSelectedStage] = useState('शाकीय वाढ (Vegetative)');
  const [selectedSoil, setSelectedSoil] = useState(farmer.soilType || 'काळी कसदार (Black Cotton)');
  const [activeTab, setActiveTab] = useState<'treatment' | 'weather' | 'irrigation' | 'alerts'>('treatment');
  const [playingId, setPlayingId] = useState<string | null>(null);

  const lat = currentGps?.lat ?? farmer.latitude ?? 19.9975;
  const lng = currentGps?.lng ?? farmer.longitude ?? 73.7898;
  const locationLabel = currentGps?.village
    ? `${currentGps.village}, ${currentGps.district || 'नाशिक'}`
    : `${farmer.district || 'नाशिक'}, ${farmer.state || 'महाराष्ट्र'}`;

  const fetchWeather = async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/weather?lat=${lat}&lng=${lng}&location=${encodeURIComponent(locationLabel)}&crop=${encodeURIComponent(selectedCrop)}&soil=${encodeURIComponent(selectedSoil)}`
      );
      const data = await res.json();
      if (data.data) {
        setWeather(data.data);
      }
    } catch (err) {
      console.error('Failed to load weather:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchTreatmentAdvisory = async () => {
    setTreatmentLoading(true);
    try {
      const res = await fetch('/api/weather/treatment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cropName: selectedCrop,
          cropStage: selectedStage,
          targetPestOrDisease: 'Sucking Pests & Fungal Leaf Spot',
          lat,
          lng,
          temperature: weather?.currentTemp || 28,
          humidity: weather?.humidity || 52,
          windSpeedKmH: weather?.windSpeedKmH || 9,
          rainProbability: weather?.rainProbability || 10,
          language,
        }),
      });
      const data = await res.json();
      if (data.data) {
        setTreatmentAdvisory(data.data);
      }
    } catch (err) {
      console.error('Failed to load treatment advisory:', err);
    } finally {
      setTreatmentLoading(false);
    }
  };

  useEffect(() => {
    if (activeModal === 'weatherAdvisory' || activeModal === 'treatmentWeather') {
      if (activeModal === 'treatmentWeather') {
        setActiveTab('treatment');
      }
      fetchWeather();
    }
  }, [activeModal, selectedCrop, selectedSoil, lat, lng]);

  useEffect(() => {
    if (weather) {
      fetchTreatmentAdvisory();
    }
  }, [weather, selectedCrop, selectedStage]);

  // Recalculate smart irrigation on crop or stage change
  const handleRecalculateIrrigation = async (stage: string, cropName: string, soil: string) => {
    setSelectedStage(stage);
    setSelectedCrop(cropName);
    setSelectedSoil(soil);

    try {
      const res = await fetch('/api/smart-farming/irrigation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          crop: cropName,
          soil,
          stage,
          rainForecast: weather?.rainProbability || 10,
          temp: weather?.currentTemp || 28,
        }),
      });
      const data = await res.json();
      if (data.data && weather) {
        setWeather({
          ...weather,
          irrigationAdvisory: data.data,
        });
      }
    } catch (err) {
      console.error('Irrigation recalculation error:', err);
    }
  };

  const handleSpeak = (text: string, id: string) => {
    if (isSpeaking && playingId === id) {
      stopSpeaking();
      setPlayingId(null);
    } else {
      setPlayingId(id);
      speakText(text, language, () => {
        setPlayingId(null);
      });
    }
  };

  if (activeModal !== 'weatherAdvisory' && activeModal !== 'treatmentWeather') return null;

  return (
    <div
      id="weather-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-emerald-950/80 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-4xl max-h-[92vh] rounded-3xl bg-white dark:bg-[#072418] border border-emerald-500/30 shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-emerald-500/20 bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 dark:from-emerald-950/90 dark:to-[#041d13] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500 to-emerald-500 text-white flex items-center justify-center shadow-md">
              <CloudSun className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-white font-outfit">
                  {language === 'mr'
                    ? '🌿 अचूक हवामान व उपचार सल्लागार'
                    : language === 'hi'
                    ? '🌿 मौसम व सटीक उपचार सलाहकार'
                    : '🌿 Precision Weather & Treatment Advisory'}
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                  GPS Linked
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-emerald-700/80 dark:text-emerald-400/80">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-emerald-500" />
                  <span>{locationLabel}</span>
                </span>
                <span className="font-mono text-[11px] text-emerald-600 dark:text-emerald-300">
                  ({lat.toFixed(3)}°N, {lng.toFixed(3)}°E)
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => openModal('gpsTracker')}
              title="Open Google Maps GPS Tracker"
              className="p-2 rounded-xl bg-white dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 hover:bg-emerald-100 transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
            >
              <Navigation className="w-4 h-4 text-emerald-500" />
              <span className="hidden sm:inline">Google Map</span>
            </button>
            <button
              onClick={fetchWeather}
              title="Refresh Radar"
              className="p-2 rounded-xl bg-white dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 hover:bg-emerald-100 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={closeModal}
              className="p-2 rounded-xl bg-white dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-200 border border-emerald-500/20 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-600 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-3 pb-2 border-b border-emerald-500/15 bg-white/50 dark:bg-emerald-950/40 shrink-0 overflow-x-auto">
          {/* Treatment Advisory Tab */}
          <button
            onClick={() => setActiveTab('treatment')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              activeTab === 'treatment'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-600 dark:text-emerald-300 hover:bg-emerald-100/50 dark:hover:bg-white/5'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>{language === 'mr' ? '🌿 फवारणी व उपचार सल्ला' : language === 'hi' ? '🌿 छिड़काव व उपचार सलाह' : '🌿 Spray & Treatment'}</span>
          </button>

          <button
            onClick={() => setActiveTab('weather')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              activeTab === 'weather'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-600 dark:text-emerald-300 hover:bg-emerald-100/50 dark:hover:bg-white/5'
            }`}
          >
            <CloudSun className="w-3.5 h-3.5" />
            <span>{language === 'mr' ? 'हवामान व ७ दिवस अंदाज' : language === 'hi' ? 'मौसम व ७ दिन' : 'Weather & 7-Day'}</span>
          </button>

          <button
            onClick={() => setActiveTab('irrigation')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              activeTab === 'irrigation'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-600 dark:text-emerald-300 hover:bg-emerald-100/50 dark:hover:bg-white/5'
            }`}
          >
            <Droplets className="w-3.5 h-3.5" />
            <span>{language === 'mr' ? '💧 स्मार्ट सिंचन' : language === 'hi' ? '💧 स्मार्ट सिंचाई' : '💧 Smart Irrigation'}</span>
          </button>

          <button
            onClick={() => setActiveTab('alerts')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              activeTab === 'alerts'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-600 dark:text-emerald-300 hover:bg-emerald-100/50 dark:hover:bg-white/5'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>{language === 'mr' ? '⚠️ इशारे' : '⚠️ Alerts'}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-amber-400 text-emerald-950 font-black text-[10px]">
              {weather?.alerts?.length || 2}
            </span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* TAB 1: PRECISION TREATMENT & SPRAY DECISION ENGINE */}
          {activeTab === 'treatment' && (
            <div className="space-y-6">
              {/* Crop & Growth Stage Selector */}
              <div className="p-4 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/50 border border-emerald-500/20 flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-emerald-900 dark:text-emerald-200">
                      {language === 'mr' ? 'पीक निवडा:' : 'Select Crop:'}
                    </label>
                    <select
                      value={selectedCrop}
                      onChange={(e) => setSelectedCrop(e.target.value)}
                      className="px-3 py-1.5 rounded-xl bg-white dark:bg-emerald-900/50 border border-emerald-500/30 text-xs font-bold text-emerald-950 dark:text-white"
                    >
                      <option value="कांदा (Onion)">🧅 कांदा (Onion)</option>
                      <option value="कापूस (Cotton)">🌾 कापूस (Cotton)</option>
                      <option value="सोयाबीन (Soybean)">🌱 सोयाबीन (Soybean)</option>
                      <option value="टोमॅटो (Tomato)">🍅 टोमॅटो (Tomato)</option>
                      <option value="गहू (Wheat)">🌾 गहू (Wheat)</option>
                      <option value="मिरची (Chilli)">🌶️ मिरची (Chilli)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-emerald-900 dark:text-emerald-200">
                      {language === 'mr' ? 'पिकाची वाढ अवस्था:' : 'Crop Growth Stage:'}
                    </label>
                    <select
                      value={selectedStage}
                      onChange={(e) => setSelectedStage(e.target.value)}
                      className="px-3 py-1.5 rounded-xl bg-white dark:bg-emerald-900/50 border border-emerald-500/30 text-xs font-bold text-emerald-950 dark:text-white"
                    >
                      <option value="शाकीय वाढ (Vegetative)">🌿 शाकीय वाढ (Vegetative)</option>
                      <option value="फुलोरा अवस्था (Flowering)">🌸 फुलोरा अवस्था (Flowering)</option>
                      <option value="फळधारणा / बोंड भरणे (Fruiting/Boll)">🍅 फळधारणा / दाणे भरणे (Fruiting)</option>
                      <option value="काढणी टप्पा (Maturity)">🌾 काढणी टप्पा (Maturity)</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openGoogleMaps('view')}
                    className="px-3 py-1.5 rounded-xl bg-white dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1 cursor-pointer hover:bg-emerald-100"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Google Maps वर पहा</span>
                  </button>
                </div>
              </div>

              {/* 1. Main Spray Suitability & Decision Card */}
              <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-700 to-emerald-800 text-white shadow-xl relative overflow-hidden space-y-5">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-white/20 text-white border border-white/30">
                        {language === 'mr' ? 'हवामान-आधारित उपचार निर्णय' : 'Weather-Driven Spray Decision'}
                      </span>
                      <span className="text-xs font-mono text-emerald-200">
                        Safety: {treatmentAdvisory?.safetyScore || 92}/100
                      </span>
                    </div>

                    <h3 className="text-2xl sm:text-3xl font-black font-outfit mt-1.5 flex items-center gap-2">
                      {treatmentAdvisory?.sprayStatus === 'OPTIMAL' ? (
                        <>
                          <CheckCircle className="w-8 h-8 text-emerald-300" />
                          <span>{language === 'mr' ? 'फवारणीसाठी हवामान अत्यंत अनुकूल' : 'Optimal Spray Conditions'}</span>
                        </>
                      ) : treatmentAdvisory?.sprayStatus === 'CAUTION' ? (
                        <>
                          <AlertTriangle className="w-8 h-8 text-amber-300" />
                          <span>{language === 'mr' ? 'सावधगिरीने फवारणी करा' : 'Moderate Spray Window'}</span>
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="w-8 h-8 text-rose-300" />
                          <span>{language === 'mr' ? 'सध्या फवारणी टाळा (धोकादायक)' : 'Unfavorable Spray Conditions'}</span>
                        </>
                      )}
                    </h3>
                  </div>

                  <button
                    onClick={() =>
                      handleSpeak(
                        language === 'mr'
                          ? treatmentAdvisory?.audioNarrationMr || weather?.sprayAdviceMr || 'आज फवारणीसाठी हवामान अनुकूल आहे.'
                          : language === 'hi'
                          ? treatmentAdvisory?.audioNarrationHi || 'आज छिड़काव के लिए मौसम अनुकूल है।'
                          : treatmentAdvisory?.audioNarrationEn || 'Optimal weather for pesticide spray.',
                        'treatment-voice'
                      )
                    }
                    className="px-4 py-2.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black text-xs flex items-center gap-2 shadow-lg transition-all cursor-pointer shrink-0"
                  >
                    {isSpeaking && playingId === 'treatment-voice' ? (
                      <VolumeX className="w-4 h-4" />
                    ) : (
                      <Volume2 className="w-4 h-4 animate-bounce" />
                    )}
                    <span>🔊 {language === 'mr' ? 'उपचार सल्ला ऐका' : 'Listen Advice'}</span>
                  </button>
                </div>

                {/* 4 Core Treatment Weather Parameters */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-white/20">
                  {/* Morning Spray Window */}
                  <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15">
                    <span className="text-[10px] text-emerald-200 block font-medium">
                      {language === 'mr' ? '🌅 सकाळची सर्वोत्तम वेळ' : 'Morning Window'}
                    </span>
                    <span className="text-sm font-black text-white block mt-0.5">
                      {treatmentAdvisory?.bestMorningWindow || '6:30 AM - 9:30 AM'}
                    </span>
                    <span className="text-[10px] text-emerald-200/90 block mt-0.5">दव सुकल्यानंतर फवारा</span>
                  </div>

                  {/* Evening Spray Window */}
                  <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15">
                    <span className="text-[10px] text-emerald-200 block font-medium">
                      {language === 'mr' ? '🌇 संध्याकाळची वेळ' : 'Evening Window'}
                    </span>
                    <span className="text-sm font-black text-white block mt-0.5">
                      {treatmentAdvisory?.bestEveningWindow || '4:30 PM - 6:30 PM'}
                    </span>
                    <span className="text-[10px] text-emerald-200/90 block mt-0.5">कमी बाष्पीभवन</span>
                  </div>

                  {/* Wind Drift Risk */}
                  <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15">
                    <span className="text-[10px] text-emerald-200 block font-medium">
                      {language === 'mr' ? '💨 वारा व ड्रिफ्ट धोका' : 'Wind Drift Index'}
                    </span>
                    <span className="text-sm font-black text-white block mt-0.5">
                      {weather?.windSpeedKmH || 9} km/h (सुरक्षित)
                    </span>
                    <span className="text-[10px] text-emerald-200/90 block mt-0.5">&lt; 15 km/h अनुकूल</span>
                  </div>

                  {/* Rainfastness Required */}
                  <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15">
                    <span className="text-[10px] text-emerald-200 block font-medium">
                      {language === 'mr' ? '🌧️ रेनफास्टनेस (सुकण्याचा काळ)' : 'Rainfastness'}
                    </span>
                    <span className="text-sm font-black text-amber-300 block mt-0.5">
                      {treatmentAdvisory?.rainfastnessHours || 3.5} तास कोरडे
                    </span>
                    <span className="text-[10px] text-emerald-200/90 block mt-0.5">पावसाची शक्यता: {weather?.rainProbability || 10}%</span>
                  </div>
                </div>
              </div>

              {/* 2. Specific Chemical & Organic Dosage Treatment Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Chemical Treatment Dose */}
                <div className="p-5 rounded-3xl bg-slate-50 dark:bg-emerald-950/60 border-2 border-emerald-500/30 space-y-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                      🧪
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-slate-900 dark:text-white">
                        {language === 'mr' ? 'रासायनिक फवारणी मात्रा (Chemical Treatment)' : 'Recommended Chemical Spray'}
                      </h4>
                      <span className="text-[10px] text-slate-500 dark:text-zinc-400">
                        {selectedCrop} साठी प्रमाणित कृषी मात्रा
                      </span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white dark:bg-black/30 border border-slate-200 dark:border-emerald-500/20 space-y-2 text-xs">
                    <div>
                      <span className="text-slate-500 dark:text-zinc-400 block text-[10px] font-bold">औषधाचे नाव व घटक (Technical):</span>
                      <span className="font-extrabold text-slate-900 dark:text-emerald-300 text-xs sm:text-sm">
                        {treatmentAdvisory?.chemicalTreatment.primaryMolecule || 'Difenoconazole 25% EC (Score) + Acetamiprid'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100 dark:border-zinc-800">
                      <div>
                        <span className="text-slate-500 dark:text-zinc-400 block text-[10px]">१५L पंपासाठी डोस:</span>
                        <span className="font-black text-blue-600 dark:text-blue-400">
                          {treatmentAdvisory?.chemicalTreatment.dosagePerPump15L || '15 ml per 15L pump'}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 dark:text-zinc-400 block text-[10px]">प्रति एकर प्रमाण:</span>
                        <span className="font-black text-slate-800 dark:text-white">
                          {treatmentAdvisory?.chemicalTreatment.dosagePerAcre || '150 ml in 150L water'}
                        </span>
                      </div>
                    </div>

                    <div className="text-[11px] text-slate-600 dark:text-zinc-300 pt-1">
                      <strong>रोग / किड नियंत्रण: </strong>
                      <span>{treatmentAdvisory?.chemicalTreatment.targetPathogen || 'करपा, पानावरील ठिपके व रसशोषक किडी'}</span>
                    </div>
                  </div>
                </div>

                {/* Organic / Bio Treatment Dose */}
                <div className="p-5 rounded-3xl bg-slate-50 dark:bg-emerald-950/60 border-2 border-emerald-500/30 space-y-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                      🌿
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-slate-900 dark:text-white">
                        {language === 'mr' ? 'सेंद्रिय / जैविक उपचार (Organic Treatment)' : 'Organic & Bio Alternative'}
                      </h4>
                      <span className="text-[10px] text-slate-500 dark:text-zinc-400">
                        पर्यावरणपूरक व मित्रकिडींसाठी सुरक्षित
                      </span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-white dark:bg-black/30 border border-slate-200 dark:border-emerald-500/20 space-y-2 text-xs">
                    <div>
                      <span className="text-slate-500 dark:text-zinc-400 block text-[10px] font-bold">जैविक घटक:</span>
                      <span className="font-extrabold text-slate-900 dark:text-emerald-300 text-xs sm:text-sm">
                        {treatmentAdvisory?.organicTreatment.molecule || 'Neem Oil (10,000 PPM) + Trichoderma viride'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100 dark:border-zinc-800">
                      <div>
                        <span className="text-slate-500 dark:text-zinc-400 block text-[10px]">१५L पंपासाठी डोस:</span>
                        <span className="font-black text-emerald-600 dark:text-emerald-400">
                          {treatmentAdvisory?.organicTreatment.dosagePerPump15L || '45 ml Neem Oil per 15L'}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 dark:text-zinc-400 block text-[10px]">फायदा:</span>
                        <span className="font-bold text-slate-800 dark:text-white">
                          {treatmentAdvisory?.organicTreatment.benefits || 'रासायनिक अवशेषमुक्त'}
                        </span>
                      </div>
                    </div>

                    <div className="text-[11px] text-slate-600 dark:text-zinc-300 pt-1">
                      <strong>टीप: </strong>
                      <span>सेंद्रिय फवारणीसोबत स्टिकर (Spreader) मिसळल्यास पानांवर औषध उत्तम पसरते.</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. Spray Safety & Equipment Best Practices */}
              <div className="p-4 sm:p-5 rounded-3xl bg-amber-500/10 border border-amber-500/30 text-amber-950 dark:text-amber-100 text-xs space-y-2">
                <div className="flex items-center gap-2 font-black text-sm">
                  <ShieldCheck className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <span>
                    {language === 'mr' ? '🛡️ सुरक्षित फवारणी नियम व काळजी' : '🛡️ Safe Spray Application Protocol'}
                  </span>
                </div>
                <p className="leading-relaxed">
                  {language === 'mr'
                    ? treatmentAdvisory?.protectiveGearMandateMr || 'फवारणी करताना नेहमी मास्क, चष्मा व रबरी हातमोजे वापरा. वाऱ्याच्या विरुद्ध दिशेने फवारणी करू नका. रिकामे डबे जमिनीत गाडून नष्ट करा.'
                    : treatmentAdvisory?.protectiveGearMandate || 'Always wear protective gear and avoid spraying directly into the wind.'}
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: CURRENT WEATHER & 7-DAY FORECAST */}
          {activeTab === 'weather' && (
            <>
              {/* Main Weather Card */}
              <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-sky-500/15 via-emerald-500/10 to-teal-500/15 border border-sky-500/30 shadow-lg relative overflow-hidden">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
                  <div className="space-y-1.5">
                    <div className="flex items-baseline gap-3">
                      <span className="text-4xl sm:text-6xl font-black text-emerald-950 dark:text-white font-outfit tracking-tight">
                        {weather?.currentTemp || 28}°C
                      </span>
                      <span className="text-sm sm:text-base font-bold text-emerald-700 dark:text-emerald-300">
                        {language === 'mr'
                          ? weather?.conditionMr || 'अंशतः ढगाळ व कोरडे'
                          : weather?.condition || 'Partly Sunny & Dry'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-emerald-200/80">
                      High: 32°C • Low: 18°C • Humidity: {weather?.humidity || 48}% • Wind: {weather?.windSpeedKmH || 9} km/h
                    </p>
                  </div>

                  {/* Open in Google Maps Quick Action */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => openGoogleMaps('satellite')}
                      className="px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-md cursor-pointer"
                    >
                      <Navigation className="w-4 h-4" />
                      <span>{language === 'mr' ? 'Google Map वर लोकेशन पहा' : 'View on Google Maps'}</span>
                    </button>
                  </div>
                </div>

                {/* Weather Gauges Grid (6 Core Parameters) */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 sm:gap-3 mt-6 pt-5 border-t border-emerald-500/20 text-center">
                  <div className="p-3 rounded-2xl bg-white/80 dark:bg-emerald-950/70 border border-emerald-500/20 shadow-2xs">
                    <Droplets className="w-4 h-4 text-sky-500 mx-auto mb-1" />
                    <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-medium">
                      {language === 'mr' ? 'हवेतील आर्द्रता' : 'Humidity'}
                    </span>
                    <span className="text-sm font-black text-emerald-950 dark:text-emerald-100">
                      {weather?.humidity || 48}%
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-white/80 dark:bg-emerald-950/70 border border-emerald-500/20 shadow-2xs">
                    <CloudRain className="w-4 h-4 text-blue-500 mx-auto mb-1" />
                    <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-medium">
                      {language === 'mr' ? 'पावसाची शक्यता' : 'Rain Probability'}
                    </span>
                    <span className="text-sm font-black text-blue-600 dark:text-blue-400">
                      {weather?.rainProbability || 10}%
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-white/80 dark:bg-emerald-950/70 border border-emerald-500/20 shadow-2xs">
                    <Wind className="w-4 h-4 text-teal-500 mx-auto mb-1" />
                    <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-medium">
                      {language === 'mr' ? 'वाऱ्याचा वेग' : 'Wind Speed'}
                    </span>
                    <span className="text-sm font-black text-emerald-950 dark:text-emerald-100">
                      {weather?.windSpeedKmH || 9} km/h
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-white/80 dark:bg-emerald-950/70 border border-emerald-500/20 shadow-2xs">
                    <Sun className="w-4 h-4 text-amber-500 mx-auto mb-1" />
                    <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-medium">
                      {language === 'mr' ? 'अल्ट्राव्हायोलेट (UV)' : 'UV Index'}
                    </span>
                    <span className="text-sm font-black text-amber-600 dark:text-amber-400">
                      Index {weather?.uvIndex || 7}
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-white/80 dark:bg-emerald-950/70 border border-emerald-500/20 shadow-2xs">
                    <Gauge className="w-4 h-4 text-emerald-500 mx-auto mb-1" />
                    <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-medium">
                      {language === 'mr' ? 'हवेची गुणवत्ता (AQI)' : 'Air Quality'}
                    </span>
                    <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                      AQI {weather?.airQualityIndex || 42}
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-white/80 dark:bg-emerald-950/70 border border-emerald-500/20 shadow-2xs">
                    <Waves className="w-4 h-4 text-cyan-500 mx-auto mb-1" />
                    <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-medium">
                      {language === 'mr' ? 'जमिनीतील ओलावा' : 'Soil Moisture'}
                    </span>
                    <span className="text-sm font-black text-cyan-700 dark:text-cyan-300">
                      ४८% (मध्यम)
                    </span>
                  </div>
                </div>
              </div>

              {/* 7-Day Forecast Grid */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-emerald-900 dark:text-emerald-300 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-emerald-500" />
                    <span>
                      {language === 'mr' ? '७ दिवसांचा अचूक कृषी हवामान अंदाज' : '7-Day Precision Agro Forecast'}
                    </span>
                  </h4>
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
                    {language === 'mr' ? 'दर ३ तासांनी अपडेट' : 'Updated every 3 hrs'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
                  {(weather?.forecast || []).map((f, i) => (
                    <div
                      key={i}
                      className={`p-3 rounded-2xl border text-center space-y-1.5 transition-all ${
                        i === 0
                          ? 'bg-emerald-500/15 border-emerald-500/50 shadow-sm'
                          : 'bg-white dark:bg-emerald-950/60 border-emerald-500/20'
                      }`}
                    >
                      <span className="text-xs font-black text-emerald-950 dark:text-emerald-100 block">
                        {language === 'mr' ? f.dayMr || f.day : language === 'hi' ? f.dayHi || f.day : f.day}
                      </span>
                      <div className="my-1">
                        {f.rainChance > 20 ? (
                          <CloudRain className="w-6 h-6 text-blue-500 mx-auto animate-bounce" />
                        ) : f.condition.includes('Cloud') ? (
                          <CloudSun className="w-6 h-6 text-amber-500 mx-auto" />
                        ) : (
                          <Sun className="w-6 h-6 text-amber-400 mx-auto" />
                        )}
                      </div>
                      <div className="text-xs font-mono font-black text-emerald-900 dark:text-emerald-200">
                        {f.tempMax}° / {f.tempMin}°
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                        {language === 'mr' ? f.conditionMr || f.condition : f.condition}
                      </div>
                      <span className={`text-[10px] font-bold block ${f.rainChance > 20 ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'}`}>
                        {f.rainChance}% rain
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* TAB 3: SMART IRRIGATION */}
          {activeTab === 'irrigation' && (
            <div className="space-y-6">
              {weather?.irrigationAdvisory && (
                <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-xl space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-emerald-200 block">
                        {language === 'mr' ? 'स्मार्ट सिंचन शिफारस' : 'Smart Irrigation Recommendation'}
                      </span>
                      <h3 className="text-2xl sm:text-3xl font-black font-outfit mt-1">
                        {language === 'mr'
                          ? `पाणी देण्याची गरज: ${weather.irrigationAdvisory.needLevel}`
                          : `Irrigation Need: ${weather.irrigationAdvisory.needLevel}`}
                      </h3>
                      <p className="text-xs text-emerald-100/90 mt-1">
                        {language === 'mr'
                          ? weather.irrigationAdvisory.recommendationMr
                          : weather.irrigationAdvisory.recommendationEn}
                      </p>
                    </div>

                    <button
                      onClick={() =>
                        handleSpeak(
                          language === 'mr'
                            ? weather.irrigationAdvisory.recommendationMr + ' ' + weather.irrigationAdvisory.reasonMr
                            : weather.irrigationAdvisory.recommendationEn,
                          'irrigation-speak'
                        )
                      }
                      className="px-4 py-2 rounded-2xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black text-xs flex items-center gap-2 shadow-lg transition-all cursor-pointer shrink-0"
                    >
                      {isSpeaking && playingId === 'irrigation-speak' ? (
                        <VolumeX className="w-4 h-4" />
                      ) : (
                        <Volume2 className="w-4 h-4 animate-bounce" />
                      )}
                      <span>🔊 {language === 'mr' ? 'शिफारस ऐका' : 'Listen'}</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-white/20">
                    <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15">
                      <span className="text-[11px] text-emerald-200 block">
                        {language === 'mr' ? '💧 पाण्याचे प्रमाण:' : 'Water Quantity:'}
                      </span>
                      <span className="text-base font-black font-mono text-white block mt-0.5">
                        {weather.irrigationAdvisory.waterQuantity}
                      </span>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15">
                      <span className="text-[11px] text-emerald-200 block">
                        {language === 'mr' ? '⏰ सर्वोत्तम वेळ:' : 'Best Time Window:'}
                      </span>
                      <span className="text-base font-black text-white block mt-0.5">
                        {weather.irrigationAdvisory.bestTime}
                      </span>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15">
                      <span className="text-[11px] text-emerald-200 block">
                        {language === 'mr' ? '📊 आर्द्रता स्कोर:' : 'Need Score:'}
                      </span>
                      <span className="text-base font-black text-amber-300 block mt-0.5">
                        {weather.irrigationAdvisory.needScore} / 100
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ACTIVE ALERTS */}
          {activeTab === 'alerts' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-emerald-900 dark:text-emerald-300">
                  {language === 'mr' ? 'सक्रिय हवामान धोके व इशारे (Active Alerts)' : 'Active Weather & Extreme Events Radar'}
                </h4>
                <span className="text-xs text-zinc-500 dark:text-zinc-400">IMD & Krishi Radar</span>
              </div>

              <div className="space-y-3">
                {(weather?.alerts || []).map((alert, idx) => (
                  <div
                    key={alert.id || idx}
                    className={`p-4 sm:p-5 rounded-3xl border-2 transition-all ${
                      alert.type === 'heatwave'
                        ? 'bg-amber-500/10 border-amber-500/40 text-amber-950 dark:text-amber-100'
                        : alert.type === 'heavy-rain'
                        ? 'bg-blue-500/10 border-blue-500/40 text-blue-950 dark:text-blue-100'
                        : 'bg-emerald-500/10 border-emerald-500/40 text-emerald-950 dark:text-emerald-100'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-2xl bg-white dark:bg-black/30 flex items-center justify-center text-xl shadow-xs shrink-0">
                          {alert.type === 'heavy-rain' ? '🌧️' : alert.type === 'heatwave' ? '☀️' : alert.type === 'strong-wind' ? '💨' : '❄️'}
                        </div>
                        <div className="space-y-1">
                          <h5 className="text-sm sm:text-base font-extrabold font-outfit">
                            {language === 'mr' ? alert.titleMr : language === 'hi' ? alert.titleHi : alert.titleEn}
                          </h5>
                          <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                            {language === 'mr' ? alert.adviceMr : language === 'hi' ? alert.adviceHi : alert.adviceEn}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() =>
                          handleSpeak(
                            language === 'mr' ? alert.titleMr + '. ' + alert.adviceMr : alert.adviceEn,
                            `alert-${idx}`
                          )
                        }
                        className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-xs flex items-center gap-1 shadow-sm transition-all cursor-pointer shrink-0"
                      >
                        {isSpeaking && playingId === `alert-${idx}` ? (
                          <VolumeX className="w-3.5 h-3.5" />
                        ) : (
                          <Volume2 className="w-3.5 h-3.5" />
                        )}
                        <span>🔊 {language === 'mr' ? 'ऐका' : 'Listen'}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
