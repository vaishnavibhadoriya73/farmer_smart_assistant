import { useState, useEffect, useCallback } from 'react';
import { mandiPriceService, MandiRateRecord, MandiPriceFilterOptions, CropPriceAnalytics } from '../services/mandiPriceService';

export function useMandiPrices(initialFilters?: MandiPriceFilterOptions) {
  const [rates, setRates] = useState<MandiRateRecord[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [isLiveApi, setIsLiveApi] = useState<boolean>(true);
  const [source, setSource] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<MandiPriceFilterOptions>(initialFilters || { sortBy: 'latestUpdate' });
  const [autoRefresh, setAutoRefresh] = useState<boolean>(true);

  const fetchRates = useCallback(async (currentFilters: MandiPriceFilterOptions) => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await mandiPriceService.getMandiRates(currentFilters);
      setRates(data.rates);
      setTotalCount(data.totalCount);
      setLastUpdated(data.lastUpdated);
      setIsLiveApi(data.isLiveApi);
      setSource(data.source);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch Mandi price rates');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRates(filters);
  }, [filters, fetchRates]);

  // Auto-refresh interval (10 seconds)
  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      fetchRates(filters);
    }, 10000);
    return () => clearInterval(interval);
  }, [autoRefresh, filters, fetchRates]);

  const updateFilters = (newFilters: Partial<MandiPriceFilterOptions>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  const retryFetch = () => {
    fetchRates(filters);
  };

  const getCropAnalytics = (cropName: string): CropPriceAnalytics => {
    return mandiPriceService.getCropPriceAnalytics(cropName);
  };

  return {
    rates,
    totalCount,
    lastUpdated,
    isLiveApi,
    source,
    isLoading,
    error,
    filters,
    autoRefresh,
    setAutoRefresh,
    updateFilters,
    retryFetch,
    getCropAnalytics
  };
}
