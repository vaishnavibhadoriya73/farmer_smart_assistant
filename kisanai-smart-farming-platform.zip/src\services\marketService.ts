export interface MandiComparisonResult {
  mandiName: string;
  district: string;
  state: string;
  modalPricePerQuintal: number;
  distanceKm: number;
  quantityQuintals: number;
  grossRevenue: number;
  estimatedFreightCost: number;
  estimatedStorageCost: number;
  netExpectedRevenue: number;
  priceTrend: 'up' | 'down' | 'stable';
  isRecommended: boolean;
  recommendationReasonEn: string;
  recommendationReasonHi: string;
  recommendationReasonMr: string;
}

export interface BestMarketCalculatorInput {
  cropName: string;
  quantityQuintals: number;
  farmerDistrict: string;
  farmerState: string;
  requiresStorageDays?: number;
  transportVehicleType?: 'Mini Truck' | 'Truck' | 'Tractor';
}

export class MarketService {
  /**
   * Calculate Net Expected Revenue across nearby APMC Mandis:
   * Formula: Net Revenue = (Quantity * Modal Price) - Transportation Cost - Storage Cost
   */
  public calculateBestMandi(input: BestMarketCalculatorInput): MandiComparisonResult[] {
    const qty = Math.max(input.quantityQuintals, 1);
    const storageDays = input.requiresStorageDays || 2;
    const vehicleRatePerKm = input.transportVehicleType === 'Mini Truck' ? 18 : input.transportVehicleType === 'Truck' ? 32 : 15;

    // Generate candidates for comparison based on user crop
    const candidates = [
      {
        mandiName: `${input.farmerDistrict} Central APMC`,
        district: input.farmerDistrict,
        state: input.farmerState,
        modalPrice: 2850,
        distanceKm: 18,
        trend: 'up' as const
      },
      {
        mandiName: 'Nagpur Kalamna APMC',
        district: 'Nagpur',
        state: 'Maharashtra',
        modalPrice: 3200,
        distanceKm: 75,
        trend: 'up' as const
      },
      {
        mandiName: 'Lasalgaon Main APMC',
        district: 'Nashik',
        state: 'Maharashtra',
        modalPrice: 3450,
        distanceKm: 140,
        trend: 'up' as const
      },
      {
        mandiName: 'Indore Grain & Veg Mandi',
        district: 'Indore',
        state: 'Madhya Pradesh',
        modalPrice: 3100,
        distanceKm: 210,
        trend: 'stable' as const
      }
    ];

    const processed: MandiComparisonResult[] = candidates.map(c => {
      const grossRevenue = qty * c.modalPrice;
      const freightCost = Math.round(c.distanceKm * vehicleRatePerKm * (1 + (qty / 100)));
      const storageCostPerQuintalPerDay = 12; // ₹12 / quintal / day in cold/dry warehouse
      const storageCost = Math.round(qty * storageDays * storageCostPerQuintalPerDay);
      
      const netExpectedRevenue = grossRevenue - freightCost - storageCost;

      return {
        mandiName: c.mandiName,
        district: c.district,
        state: c.state,
        modalPricePerQuintal: c.modalPrice,
        distanceKm: c.distanceKm,
        quantityQuintals: qty,
        grossRevenue,
        estimatedFreightCost: freightCost,
        estimatedStorageCost: storageCost,
        netExpectedRevenue,
        priceTrend: c.trend,
        isRecommended: false,
        recommendationReasonEn: '',
        recommendationReasonHi: '',
        recommendationReasonMr: ''
      };
    });

    // Sort by Net Revenue descending
    processed.sort((a, b) => b.netExpectedRevenue - a.netExpectedRevenue);

    // Highlight top mandi as recommended
    if (processed.length > 0) {
      const best = processed[0];
      best.isRecommended = true;
      const extraProfit = processed.length > 1 ? best.netExpectedRevenue - processed[1].netExpectedRevenue : 2500;
      
      best.recommendationReasonEn = `Highest net profit! Yields ₹${extraProfit.toLocaleString('en-IN')} extra revenue after deducting ₹${best.estimatedFreightCost.toLocaleString('en-IN')} transport & storage costs.`;
      best.recommendationReasonHi = `सर्वोच्च शुद्ध लाभ! ₹${best.estimatedFreightCost.toLocaleString('en-IN')} परिवहन व भंडारण खर्च घटाने के बाद ₹${extraProfit.toLocaleString('en-IN')} अतिरिक्त आय।`;
      best.recommendationReasonMr = `सर्वात जास्त नि्व्वळ नफा! वाहतूक व साठवणूक खर्च वजा करून ₹${extraProfit.toLocaleString('en-IN')} अतिरिक्त नफा मिळतो.`;
    }

    return processed;
  }
}

export const marketService = new MarketService();
