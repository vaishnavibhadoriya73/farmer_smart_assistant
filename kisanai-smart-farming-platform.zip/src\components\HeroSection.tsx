import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Mic,
  Scan,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
  TrendingUp,
  CloudSun,
  Sprout,
  CheckCircle,
  Activity,
  Layers,
  Camera,
  MapPin,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { InteractiveFarmIllustrator } from './InteractiveFarmIllustrator';

export const HeroSection: React.FC = () => {
  const { openModal, t } = useApp();
  const [visualMode, setVisualMode] = useState<'photo' | 'interactive'>('photo');

  const quickPrompts = [
    { label: '🍃 Leaf yellowing remedy', query: 'My wheat leaves are turning yellow with brown spots, what should I spray?' },
    { label: '💧 Next irrigation timing', query: 'What is the optimal irrigation schedule for onion in black soil?' },
    { label: '📈 Today’s Soybean Mandi rate', query: 'Show today’s soybean modal prices in Maharashtra mandis' },
    { label: '🏛️ PM-KISAN subsidy check', query: 'How to check PM-KISAN installment status and Aadhaar eKYC?' },
  ];

  return (
    <section id="hero-section" className="relative pt-6 sm:pt-10 pb-16 sm:pb-24 overflow-hidden">
      {/* Cinematic Agriculture Background Image Layer */}
      <div className="absolute inset-0 -z-20 overflow-hidden pointer-events-none">
        <img
          src="/assets/farmer_bg_panoramic.jpg"
          alt="Indian Farmlands Panorama"
          className="w-full h-full object-cover object-center opacity-25 dark:opacity-20 filter blur-[1px] scale-105 transform transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-white/90 via-emerald-50/80 to-white dark:from-[#031b11]/95 dark:via-[#031b11]/90 dark:to-[#031b11]" />
      </div>

      {/* Background Subtle Ambient Glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-emerald-500/15 via-teal-500/10 to-transparent blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Tagline Badge */}
        <div className="flex justify-center mb-6">
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/15 dark:bg-emerald-500/20 border border-emerald-500/40 text-emerald-900 dark:text-emerald-300 text-xs sm:text-sm font-bold shadow-lg shadow-emerald-950/5 backdrop-blur-md"
          >
            <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400 animate-spin" style={{ animationDuration: '8s' }} />
            <span>Next-Gen Agricultural Intelligence for Indian Farmers</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span className="text-[11px] font-mono text-emerald-700 dark:text-emerald-400">98% Accuracy</span>
          </motion.div>
        </div>

        {/* Main Grid: Left Headline & CTAs, Right Visual Illustration / Real Farmer Visual */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          {/* Left Column (Headline & CTAs) */}
          <motion.div
            initial={{ opacity: 0, x: -25 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="lg:col-span-6 space-y-6 sm:space-y-8 text-center lg:text-left"
          >
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-emerald-950 dark:text-white tracking-tight leading-[1.12] font-outfit">
                AI That Makes <br className="hidden sm:inline" />
                <span className="bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-400 bg-clip-text text-transparent">
                  Farming Smarter
                </span>
              </h1>

              <p className="text-base sm:text-lg text-emerald-900/85 dark:text-emerald-100/85 max-w-xl mx-auto lg:mx-0 font-medium leading-relaxed">
                {t('heroSubtitle')}
              </p>
            </div>

            {/* CTAs: Primary & Secondary */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 sm:gap-4 pt-1">
              {/* Primary CTA */}
              <button
                id="hero-primary-cta"
                onClick={() => openModal('askAi')}
                className="w-full sm:w-auto px-7 py-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-base shadow-xl shadow-emerald-600/30 hover:shadow-emerald-600/50 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Mic className="w-4 h-4 text-white animate-pulse" />
                </div>
                <span>{t('primaryCta')}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              {/* Secondary CTA */}
              <button
                id="hero-secondary-cta"
                onClick={() => openModal('diagnose')}
                className="w-full sm:w-auto px-7 py-4 rounded-2xl bg-white/90 dark:bg-emerald-950/80 backdrop-blur-md text-emerald-950 dark:text-emerald-100 font-bold text-base border-2 border-emerald-500/30 hover:border-emerald-500/70 hover:bg-emerald-50 dark:hover:bg-emerald-900/60 shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Scan className="w-4 h-4" />
                </div>
                <span>{t('secondaryCta')}</span>
              </button>
            </div>

            {/* Quick Agro Question Chips */}
            <div className="pt-2">
              <p className="text-xs font-bold text-emerald-900/80 dark:text-emerald-300/80 mb-2.5 flex items-center justify-center lg:justify-start gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span>Try Instant Farm Voice Prompts:</span>
              </p>
              <div className="flex flex-wrap gap-2 justify-center lg:justify-start">
                {quickPrompts.map((item, idx) => (
                  <button
                    key={idx}
                    id={`quick-prompt-${idx}`}
                    onClick={() => openModal('askAi')}
                    className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-white/90 dark:bg-emerald-950/80 text-emerald-950 dark:text-emerald-200 border border-emerald-500/25 hover:border-emerald-500/60 hover:bg-emerald-50 dark:hover:bg-emerald-900/50 transition-all shadow-sm text-left cursor-pointer"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Trust Badges */}
            <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-4 sm:gap-6 text-xs text-emerald-900/90 dark:text-emerald-300/90 font-semibold">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>ICAR & KVK Validated</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span>9+ Regional Languages</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span>50,000+ Happy Kisans</span>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Dynamic Visual Showcase with Toggle */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-6 relative"
          >
            {/* Visual View Switcher (Real Photo AI vs Vector Illustrator) */}
            <div className="flex items-center justify-end gap-2 mb-3">
              <div className="inline-flex p-1 rounded-2xl bg-white/80 dark:bg-emerald-950/80 backdrop-blur-md border border-emerald-500/30 shadow-md">
                <button
                  onClick={() => setVisualMode('photo')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    visualMode === 'photo'
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'text-slate-600 dark:text-emerald-300 hover:text-emerald-900 dark:hover:text-white'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Real Farmer AI</span>
                </button>
                <button
                  onClick={() => setVisualMode('interactive')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    visualMode === 'interactive'
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'text-slate-600 dark:text-emerald-300 hover:text-emerald-900 dark:hover:text-white'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Interactive Map</span>
                </button>
              </div>
            </div>

            <AnimatePresence mode="wait">
              {visualMode === 'photo' ? (
                /* Photorealistic Farmer Showcase with Live AI HUD */
                <motion.div
                  key="farmer-photo-showcase"
                  initial={{ opacity: 0, scale: 0.97 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.97 }}
                  transition={{ duration: 0.3 }}
                  className="relative w-full aspect-[4/3] sm:aspect-[16/11] rounded-3xl overflow-hidden border-2 border-emerald-500/30 shadow-2xl shadow-emerald-950/40 group select-none"
                >
                  {/* Real Farmer Hero Image */}
                  <img
                    src="/assets/farmer_hero.jpg"
                    alt="Indian Farmer using KisanAI Smart Platform"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                  />

                  {/* Gradient Lighting & Scrim */}
                  <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/90 via-emerald-950/20 to-transparent pointer-events-none" />

                  {/* Top Header Badge */}
                  <div className="absolute top-4 left-4 z-20 flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/85 backdrop-blur-md border border-emerald-500/40 text-emerald-200 text-xs font-bold shadow-lg">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                    <span>Live Kisan Field Diagnostics</span>
                  </div>

                  {/* Top Right Weather Telemetry Card */}
                  <motion.div
                    animate={{ y: [0, -5, 0] }}
                    transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                    onClick={() => openModal('weatherAdvisory')}
                    className="absolute top-4 right-4 z-20 p-2.5 rounded-2xl bg-emerald-950/85 backdrop-blur-md border border-emerald-500/40 text-white shadow-xl cursor-pointer hover:scale-105 transition-transform flex items-center gap-2"
                  >
                    <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center">
                      <CloudSun className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                      <div className="text-[11px] font-bold text-sky-200">28°C • Safe Spray</div>
                      <div className="text-[9px] text-emerald-300/80 font-mono">Nashik Microclimate</div>
                    </div>
                  </motion.div>

                  {/* Bottom AI Diagnostic HUD Overlay */}
                  <div className="absolute bottom-4 left-4 right-4 z-20 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-white/95 dark:bg-emerald-950/90 backdrop-blur-xl border border-emerald-500/40 shadow-2xl">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-black shadow-md shadow-emerald-500/30">
                        <Scan className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-emerald-950 dark:text-white">
                            Wheat & Cotton Scan
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-700 dark:text-emerald-300">
                            98.4% Health
                          </span>
                        </div>
                        <p className="text-[11px] font-medium text-emerald-700 dark:text-emerald-300/90">
                          Flag leaf healthy • Zero pest detected
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => openModal('diagnose')}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/30 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <span>Scan Your Crop</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </motion.div>
              ) : (
                /* Interactive Farm Illustrator */
                <motion.div
                  key="farm-vector-illustrator"
                  initial={{ opacity: 0, scale: 0.97 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.97 }}
                  transition={{ duration: 0.3 }}
                >
                  <InteractiveFarmIllustrator />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
