import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Truck,
  Sprout,
  Warehouse,
  ShoppingBag,
  CheckCircle2,
  Clock,
  ArrowRight,
  Plus,
  Search,
  Filter,
  TrendingUp,
  AlertTriangle,
  MapPin,
  DollarSign,
  ShieldCheck,
  Zap,
  Volume2,
  VolumeX,
  Navigation,
  Sparkles,
  BarChart3,
  Calendar,
  Layers,
  ChevronRight,
  PackageCheck,
  Thermometer,
  Droplets,
  Award,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { useApp } from '../context/AppContext';
import { SupplyChainShipment, SupplyChainStage, SupplyChainStatus } from '../types';

const STAGE_STEPS: { stage: SupplyChainStage; labelMr: string; labelHi: string; labelEn: string; icon: string }[] = [
  { stage: 'farm', labelMr: 'माझे शेत', labelHi: 'खेत', labelEn: 'Farm', icon: '🌾' },
  { stage: 'collection', labelMr: 'संकलन केंद्र', labelHi: 'कलेक्शन सेंटर', labelEn: 'Collection', icon: '🏬' },
  { stage: 'storage', labelMr: 'साठवणूक / चाळ', labelHi: 'भंडारण', labelEn: 'Storage', icon: '❄️' },
  { stage: 'transport', labelMr: 'वाहतूक', labelHi: 'परिवहन', labelEn: 'Transport', icon: '🚚' },
  { stage: 'mandi', labelMr: 'बाजार समिती', labelHi: 'मंडी / बाज़ार', labelEn: 'Mandi', icon: '🏛️' },
  { stage: 'buyer', labelMr: 'खरेदीदार', labelHi: 'खरीददार', labelEn: 'Buyer', icon: '💰' },
];

export const FarmerSupplyChainModal: React.FC = () => {
  const { activeModal, closeModal, language, speakText, isSpeaking, stopSpeaking } = useApp();

  const [shipments, setShipments] = useState<SupplyChainShipment[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedShipmentId, setSelectedShipmentId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showRouteModal, setShowRouteModal] = useState(false);

  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState('All');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('All');

  // New Shipment Form State
  const [farmerName, setFarmerName] = useState('ज्ञानेश्वर पाटील');
  const [cropName, setCropName] = useState('टोमॅटो (Tomato)');
  const [cropVariety, setCropVariety] = useState('हायब्रिड अ-दर्जा Grade A');
  const [quantityQuintals, setQuantityQuintals] = useState(60);
  const [harvestDate, setHarvestDate] = useState('Today');
  const [farmLocation, setFarmLocation] = useState('निफाड, नाशिक (Niphad, Nashik)');
  const [destinationMandi, setDestinationMandi] = useState('वाशी एपीएमसी, मुंबई (Vashi APMC)');
  const [expectedSellingDate, setExpectedSellingDate] = useState('08 Sep 2026');
  const [storageReq, setStorageReq] = useState('Cold Storage (शीतगृह)');
  const [transportType, setTransportType] = useState<'Mini Truck' | 'Truck' | 'Tractor' | 'Other'>('Mini Truck');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchShipments = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/supply-chain/shipments');
      const data = await res.json();
      if (data.data && Array.isArray(data.data)) {
        setShipments(data.data);
        if (data.data.length > 0 && !selectedShipmentId) {
          setSelectedShipmentId(data.data[0].id);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (activeModal === 'supplyChain') {
      fetchShipments();
    }
  }, [activeModal]);

  if (activeModal !== 'supplyChain') return null;

  const handleCreateShipment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const payload = {
        farmerName,
        cropName,
        cropVariety,
        quantityQuintals: Number(quantityQuintals),
        harvestDate,
        farmLocation,
        destinationMandi,
        expectedSellingDate,
        storageRequirement: storageReq,
        transportType,
      };

      const res = await fetch('/api/supply-chain/create-shipment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success && data.data) {
        setShipments((prev) => [data.data, ...prev]);
        setSelectedShipmentId(data.data.id);
        setShowAddForm(false);
      }
    } catch (err) {
      console.error('Failed to create shipment:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAdvanceStatus = async (shipment: SupplyChainShipment) => {
    let nextStatus: SupplyChainStatus = 'Collected';
    if (shipment.status === 'Harvested') nextStatus = 'Collected';
    else if (shipment.status === 'Collected') nextStatus = 'Stored';
    else if (shipment.status === 'Stored') nextStatus = 'In Transit';
    else if (shipment.status === 'In Transit') nextStatus = 'Reached Mandi';
    else if (shipment.status === 'Reached Mandi') nextStatus = 'Sold';
    else return;

    try {
      const res = await fetch('/api/supply-chain/update-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: shipment.id, nextStatus }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setShipments((prev) => prev.map((s) => (s.id === shipment.id ? data.data : s)));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const selectedShipment = shipments.find((s) => s.id === selectedShipmentId) || shipments[0];

  const filteredShipments = shipments.filter((item) => {
    const matchesSearch =
      item.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.cropName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.destinationMandi.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatusFilter === 'All' || item.status === selectedStatusFilter;
    return matchesSearch && matchesStatus;
  });

  // Analytics Metrics
  const totalQuantity = shipments.reduce((sum, s) => sum + s.quantityQuintals, 0);
  const activeCount = shipments.filter((s) => s.status !== 'Sold').length;
  const deliveredCount = shipments.filter((s) => s.status === 'Sold').length;
  const totalRevenueEst = shipments.reduce((sum, s) => {
    const best = s.marketAnalysis?.find((m) => m.isBestOption) || s.marketAnalysis?.[0];
    return sum + (best?.netEarning || s.quantityQuintals * 2500);
  }, 0);

  // Chart Datasets
  const stageChartData = STAGE_STEPS.map((step) => ({
    name: step.labelEn,
    count: shipments.filter((s) => s.currentStage === step.stage).length,
  }));

  const COLORS = ['#10b981', '#f59e0b', '#3b82f6', '#8b5cf6', '#ec4899', '#06b6d4'];

  return (
    <div
      id="farmer-supply-chain-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-emerald-950/85 backdrop-blur-md overflow-y-auto"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        className="relative w-full max-w-6xl max-h-[92vh] rounded-3xl bg-white dark:bg-[#051c13] border border-emerald-500/30 shadow-2xl flex flex-col overflow-hidden text-slate-900 dark:text-emerald-50 my-auto"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-emerald-500/20 bg-gradient-to-r from-emerald-900 via-[#072c1e] to-emerald-950 text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-emerald-500 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/30">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-xl font-black font-outfit text-white">
                  {language === 'mr'
                    ? '🚚 बळीराजा स्मार्ट सप्लाय चेन (Farmer Supply Chain)'
                    : language === 'hi'
                    ? '🚚 किसान स्मार्ट सप्लाई चेन (Smart Supply Chain)'
                    : '🚚 KisanAI Smart Supply Chain Portal'}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 animate-pulse">
                  REAL-TIME TIMELINE
                </span>
              </div>
              <p className="text-xs text-emerald-200/80">
                {language === 'mr'
                  ? 'शेतातून थेट बाजार समितीपर्यंत साठवणूक, वाहतूक व सर्वाधिक नफा देणारे मार्केट'
                  : 'Farm-to-Market Logistics, Safe Storage & AI Selling Optimizer'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddForm(true)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-emerald-500 hover:from-amber-400 hover:to-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{language === 'mr' ? 'नवीन पिक पाठवा (Add Shipment)' : 'Add New Shipment'}</span>
            </button>

            <button
              onClick={closeModal}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Section 1: Supply Chain Analytics Stat Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            <div className="p-3.5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-center space-y-1">
              <span className="text-[10px] font-bold text-zinc-500 dark:text-emerald-300">एकूण शेतमाल (Total Crops)</span>
              <div className="text-xl font-black text-emerald-950 dark:text-white font-mono">{totalQuantity} Qtl</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-500/20 text-center space-y-1">
              <span className="text-[10px] font-bold text-amber-700 dark:text-amber-300">मार्गस्थ शिपमेंट (Active)</span>
              <div className="text-xl font-black text-amber-600 dark:text-amber-400 font-mono">{activeCount} Active</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-teal-50/60 dark:bg-teal-950/30 border border-teal-500/20 text-center space-y-1">
              <span className="text-[10px] font-bold text-teal-700 dark:text-teal-300">विक्री पूर्ण (Delivered)</span>
              <div className="text-xl font-black text-teal-600 dark:text-teal-400 font-mono">{deliveredCount} Sold</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-center space-y-1">
              <span className="text-[10px] font-bold text-zinc-500 dark:text-emerald-300">अंदाजीत उत्पन्न (Net Revenue)</span>
              <div className="text-xl font-black text-emerald-600 dark:text-emerald-400 font-mono">₹{(totalRevenueEst / 100000).toFixed(1)}L</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-purple-50/60 dark:bg-purple-950/30 border border-purple-500/20 text-center space-y-1">
              <span className="text-[10px] font-bold text-purple-700 dark:text-purple-300">सरासरी भाडे (Freight/Qtl)</span>
              <div className="text-xl font-black text-purple-600 dark:text-purple-400 font-mono">₹42 / Q</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-rose-50/60 dark:bg-rose-950/30 border border-rose-500/20 text-center space-y-1">
              <span className="text-[10px] font-bold text-rose-700 dark:text-rose-300">खराबी बचत (Wastage Saved)</span>
              <div className="text-xl font-black text-rose-600 dark:text-rose-400 font-mono">94% Safe</div>
            </div>
          </div>

          {/* Section 2: Visual Supply Chain Timeline Overview */}
          <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-900/40 via-[#072418] to-emerald-950/80 border border-emerald-500/30 shadow-md space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-black text-white uppercase tracking-wider font-outfit flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>1. पिक प्रवास टाइमलाईन (Farm-to-Market Journey Timeline)</span>
              </h4>
              {selectedShipment && (
                <span className="text-xs font-mono font-bold text-amber-300 bg-amber-400/10 px-3 py-1 rounded-full border border-amber-500/30">
                  {selectedShipment.id} • {selectedShipment.cropName} ({selectedShipment.quantityQuintals} Qtl)
                </span>
              )}
            </div>

            {/* Connecting Timeline Steps */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 pt-2">
              {STAGE_STEPS.map((step, idx) => {
                const isCurrent = selectedShipment?.currentStage === step.stage;
                const isCompleted =
                  selectedShipment &&
                  STAGE_STEPS.findIndex((s) => s.stage === selectedShipment.currentStage) > idx;

                return (
                  <div
                    key={step.stage}
                    className={`relative p-3.5 rounded-2xl border text-center transition-all flex flex-col items-center gap-2 ${
                      isCurrent
                        ? 'bg-amber-400/20 border-amber-400 text-amber-200 ring-2 ring-amber-400/50 shadow-lg'
                        : isCompleted
                        ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                        : 'bg-white/5 border-white/10 text-zinc-400'
                    }`}
                  >
                    <div className="text-2xl">{step.icon}</div>
                    <div className="text-xs font-black font-outfit">
                      {language === 'mr' ? step.labelMr : language === 'hi' ? step.labelHi : step.labelEn}
                    </div>
                    <span
                      className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                        isCurrent
                          ? 'bg-amber-400 text-slate-950 font-black animate-pulse'
                          : isCompleted
                          ? 'bg-emerald-500/30 text-emerald-300'
                          : 'bg-white/10 text-zinc-400'
                      }`}
                    >
                      {isCurrent ? 'In Progress' : isCompleted ? 'Completed' : 'Pending'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 3: Active Shipments & Details Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column: Shipment List with Search & Filters */}
            <div className="space-y-3 lg:col-span-1">
              <div className="flex items-center justify-between pb-1">
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-emerald-950 dark:text-white font-outfit">
                  2. माझी पिके व शिपमेंट्स (Shipment List)
                </h4>
                <span className="text-[11px] font-bold text-zinc-500">{filteredShipments.length} Total</span>
              </div>

              {/* Search & Filter Controls */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-emerald-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search crop or APMC..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-100 dark:bg-emerald-900/30 border border-emerald-500/20 text-xs text-slate-900 dark:text-emerald-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Shipment Cards */}
              <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
                {filteredShipments.map((shipment) => {
                  const isSelected = shipment.id === selectedShipmentId;
                  return (
                    <div
                      key={shipment.id}
                      onClick={() => setSelectedShipmentId(shipment.id)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer text-left space-y-2 ${
                        isSelected
                          ? 'bg-emerald-600 text-white border-emerald-400 shadow-md scale-[1.01]'
                          : 'bg-white dark:bg-emerald-950/50 border-emerald-500/20 hover:border-emerald-500/50 text-slate-900 dark:text-emerald-100'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-black/10 dark:bg-white/10">
                          {shipment.id}
                        </span>
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            shipment.status === 'Sold'
                              ? 'bg-teal-400/20 text-teal-300'
                              : shipment.status === 'In Transit'
                              ? 'bg-amber-400/20 text-amber-300'
                              : 'bg-emerald-400/20 text-emerald-300'
                          }`}
                        >
                          {shipment.status}
                        </span>
                      </div>

                      <div>
                        <h5 className="text-sm font-black font-outfit">{shipment.cropName}</h5>
                        <p className="text-[11px] opacity-80">{shipment.quantityQuintals} Quintals • {shipment.destinationMandi}</p>
                      </div>

                      {/* Progress Bar */}
                      <div className="w-full bg-black/20 dark:bg-white/10 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-amber-400 h-full transition-all duration-500"
                          style={{ width: `${shipment.progressPercentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right Column: Detailed Tracking, Storage, Transport & AI Selling Recommendation */}
            {selectedShipment && (
              <div className="space-y-5 lg:col-span-2">
                {/* 3. Live Shipment Tracker Card */}
                <div className="p-5 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/30 shadow-md space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-emerald-500/15">
                    <div>
                      <span className="text-[10px] font-mono font-bold text-amber-500 uppercase">
                        Active Tracker • {selectedShipment.id}
                      </span>
                      <h4 className="text-lg font-black text-emerald-950 dark:text-white font-outfit">
                        {selectedShipment.cropName} ({selectedShipment.quantityQuintals} Quintals)
                      </h4>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">
                        📍 {selectedShipment.currentLocation}
                      </p>
                    </div>

                    <button
                      onClick={() => handleAdvanceStatus(selectedShipment)}
                      className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5 text-amber-300" />
                      <span>{language === 'mr' ? 'स्थिती पुढे सरकवा (Advance Stage)' : 'Advance Status'}</span>
                    </button>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-bold text-zinc-600 dark:text-emerald-200">
                      <span>Progress: {selectedShipment.progressPercentage}%</span>
                      <span>ETA: {selectedShipment.estimatedArrival}</span>
                    </div>
                    <div className="w-full bg-emerald-100 dark:bg-emerald-900/50 h-3 rounded-full overflow-hidden p-0.5 border border-emerald-500/30">
                      <div
                        className="bg-gradient-to-r from-emerald-500 to-amber-400 h-full rounded-full transition-all duration-700"
                        style={{ width: `${selectedShipment.progressPercentage}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* 4. AI Selling & Market Destination Recommendation */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* AI Selling Recommendation */}
                  <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-emerald-900/60 to-emerald-950 border border-emerald-500/30 text-white space-y-3">
                    <div className="flex items-center justify-between">
                      <h5 className="text-xs font-black uppercase text-amber-300 font-outfit flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span>AI Selling Advisory (विक्री सल्ला)</span>
                      </h5>
                      <span
                        className={`text-xs font-black px-2.5 py-1 rounded-full ${
                          selectedShipment.aiSellingAdvice.decision === 'SELL URGENTLY'
                            ? 'bg-rose-500 text-white animate-pulse'
                            : selectedShipment.aiSellingAdvice.decision === 'SELL NOW'
                            ? 'bg-emerald-500 text-slate-950 font-black'
                            : 'bg-amber-400 text-slate-950 font-black'
                        }`}
                      >
                        {selectedShipment.aiSellingAdvice.decision}
                      </span>
                    </div>

                    <div className="space-y-1">
                      <div className="text-2xl font-black font-mono text-white">
                        ₹{selectedShipment.aiSellingAdvice.currentPrice.toLocaleString('en-IN')}{' '}
                        <span className="text-xs font-normal text-emerald-300">/ Quintal</span>
                      </div>
                      <p className="text-xs text-emerald-200/90 leading-relaxed">
                        {language === 'mr'
                          ? selectedShipment.aiSellingAdvice.reasonMr
                          : language === 'hi'
                          ? selectedShipment.aiSellingAdvice.reasonHi
                          : selectedShipment.aiSellingAdvice.reasonEn}
                      </p>
                    </div>
                  </div>

                  {/* Smart Storage Recommendation */}
                  <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 space-y-3">
                    <h5 className="text-xs font-black uppercase text-emerald-950 dark:text-emerald-300 font-outfit flex items-center gap-1.5">
                      <Warehouse className="w-4 h-4 text-emerald-500" />
                      <span>Smart Storage (साठवणूक शिफारस)</span>
                    </h5>

                    <div className="space-y-2 text-xs text-zinc-700 dark:text-emerald-100 font-medium">
                      <div className="flex justify-between border-b border-emerald-500/10 pb-1">
                        <span>Recommended Storage:</span>
                        <span className="font-bold text-emerald-600 dark:text-emerald-300">
                          {selectedShipment.storageDetails.recommendedType}
                        </span>
                      </div>
                      <div className="flex justify-between border-b border-emerald-500/10 pb-1">
                        <span>Safe Storage Window:</span>
                        <span className="font-bold">{selectedShipment.storageDetails.safeDurationDays} Days</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Spoilage Risk:</span>
                        <span
                          className={`font-bold px-2 py-0.5 rounded-md ${
                            selectedShipment.storageDetails.spoilageRisk === 'High'
                              ? 'bg-rose-500/20 text-rose-500'
                              : 'bg-emerald-500/20 text-emerald-500'
                          }`}
                        >
                          {selectedShipment.storageDetails.spoilageRisk} Risk
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 5. Transportation & Market Comparison Table */}
                <div className="p-5 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 space-y-3">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-black uppercase text-emerald-950 dark:text-emerald-300 font-outfit flex items-center gap-1.5">
                      <DollarSign className="w-4 h-4 text-emerald-500" />
                      <span>Best Market Net Margin Calculator (सर्वाधिक नफा देणारी मंडी)</span>
                    </h5>

                    <button
                      onClick={() => setShowRouteModal(true)}
                      className="text-xs font-bold text-emerald-600 dark:text-emerald-300 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>{language === 'mr' ? 'वाहतूक मार्ग पहा (Find Route)' : 'Find Best Route'}</span>
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-emerald-500/20 text-zinc-400">
                          <th className="py-2">Mandi Market</th>
                          <th className="py-2">Distance</th>
                          <th className="py-2">Price / Qtl</th>
                          <th className="py-2">Freight Cost</th>
                          <th className="py-2 text-right">Net Earning</th>
                        </tr>
                      </thead>
                      <tbody>
                        {selectedShipment.marketAnalysis?.map((mandi, idx) => (
                          <tr
                            key={idx}
                            className={`border-b border-emerald-500/10 ${
                              mandi.isBestOption ? 'bg-emerald-500/10 font-bold' : ''
                            }`}
                          >
                            <td className="py-2.5 flex items-center gap-1.5">
                              <span>{mandi.bestMandiName}</span>
                              {mandi.isBestOption && (
                                <span className="text-[9px] bg-emerald-500 text-slate-950 font-black px-1.5 py-0.5 rounded-full">
                                  Best Option
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 font-mono">{mandi.distanceKm} km</td>
                            <td className="py-2.5 font-mono font-bold text-amber-500">₹{mandi.marketPrice}</td>
                            <td className="py-2.5 font-mono">₹{mandi.transportCost}</td>
                            <td className="py-2.5 text-right font-mono font-black text-emerald-600 dark:text-emerald-300">
                              ₹{mandi.netEarning.toLocaleString('en-IN')}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </motion.div>

      {/* Add New Shipment Modal Drawer */}
      <AnimatePresence>
        {showAddForm && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-lg rounded-3xl bg-white dark:bg-[#07281c] border border-emerald-500/30 p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-emerald-500/20 pb-3">
                <h4 className="text-lg font-black text-emerald-950 dark:text-white font-outfit">
                  {language === 'mr' ? 'नवीन पिक सप्लाय नोंदणी (Add Shipment)' : 'Add New Crop Shipment'}
                </h4>
                <button onClick={() => setShowAddForm(false)} className="p-1.5 text-zinc-400 hover:text-white cursor-pointer">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateShipment} className="space-y-3.5 text-xs">
                <div>
                  <label className="block font-bold text-emerald-950 dark:text-emerald-200 mb-1">Farmer Name</label>
                  <input
                    type="text"
                    required
                    value={farmerName}
                    onChange={(e) => setFarmerName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-slate-900 dark:text-emerald-100"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-emerald-950 dark:text-emerald-200 mb-1">Crop Name</label>
                    <input
                      type="text"
                      required
                      value={cropName}
                      onChange={(e) => setCropName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-slate-900 dark:text-emerald-100"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-emerald-950 dark:text-emerald-200 mb-1">Quantity (Quintals)</label>
                    <input
                      type="number"
                      required
                      value={quantityQuintals}
                      onChange={(e) => setQuantityQuintals(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-slate-900 dark:text-emerald-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-emerald-950 dark:text-emerald-200 mb-1">Farm Location</label>
                    <input
                      type="text"
                      required
                      value={farmLocation}
                      onChange={(e) => setFarmLocation(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-slate-900 dark:text-emerald-100"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-emerald-950 dark:text-emerald-200 mb-1">Destination Mandi</label>
                    <input
                      type="text"
                      required
                      value={destinationMandi}
                      onChange={(e) => setDestinationMandi(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-slate-900 dark:text-emerald-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-emerald-950 dark:text-emerald-200 mb-1">Transportation Type</label>
                  <select
                    value={transportType}
                    onChange={(e) => setTransportType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-slate-900 dark:text-emerald-100"
                  >
                    <option value="Mini Truck">Mini Truck (उदा. पिक-अप / आयशर)</option>
                    <option value="Tractor">Tractor Trolley (ट्रॅक्टर ट्रॉली)</option>
                    <option value="Truck">Heavy 10-Ton Truck (आयशर / ट्रक)</option>
                    <option value="Other">Other Local Transport</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? 'Creating Shipment...' : 'Submit & Add to Supply Chain'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Find Best Route Simulation Drawer */}
      <AnimatePresence>
        {showRouteModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-md rounded-3xl bg-white dark:bg-[#07281c] border border-emerald-500/30 p-6 shadow-2xl space-y-4 text-center"
            >
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
                <Navigation className="w-6 h-6" />
              </div>

              <h4 className="text-lg font-black text-emerald-950 dark:text-white font-outfit">
                Smart Transport Route Optimizer
              </h4>

              <div className="p-3.5 rounded-2xl bg-emerald-900/40 border border-emerald-500/20 text-left text-xs space-y-2 text-emerald-100">
                <p className="font-bold text-amber-300">Optimal Route Identified:</p>
                <p>📍 Niphad Farm Gate → NH-160 Kasara Ghat Bypass → Vashi APMC Terminal</p>
                <div className="flex justify-between font-mono pt-1 text-zinc-300">
                  <span>Dist: 185 Km</span>
                  <span>Est Freight: ₹4,200</span>
                  <span>Fuel Saved: 12%</span>
                </div>
              </div>

              <button
                onClick={() => setShowRouteModal(false)}
                className="w-full py-3 rounded-2xl bg-emerald-600 text-white font-bold text-xs cursor-pointer"
              >
                Close Route Preview
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
