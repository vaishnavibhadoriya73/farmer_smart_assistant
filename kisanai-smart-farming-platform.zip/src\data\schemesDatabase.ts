export interface DetailedGovtSchemeRecord {
  id: string;
  schemeNameEn: string;
  schemeNameHi: string;
  schemeNameMr: string;
  departmentEn: string;
  departmentHi: string;
  departmentMr: string;
  schemeType: 'Central' | 'State';
  state: string; // 'All India' or State Name e.g. 'Maharashtra'
  category: 
    | 'Farmer Income Support'
    | 'Crop Insurance'
    | 'Agriculture Subsidy'
    | 'Irrigation'
    | 'Seeds'
    | 'Fertilizers'
    | 'Organic Farming'
    | 'Soil Health'
    | 'Farm Machinery'
    | 'Women Farmers'
    | 'Fisheries'
    | 'Dairy & Livestock'
    | 'Horticulture'
    | 'Storage'
    | 'Agricultural Infrastructure'
    | 'Market Access'
    | 'Farmer Loans/Credit'
    | 'Skill Development'
    | 'Digital Agriculture';
  benefitType: 'Financial Transfer' | 'Subsidy' | 'Insurance Cover' | 'Credit Facility' | 'Input Support' | 'Infrastructure Support';
  shortDescEn: string;
  shortDescHi: string;
  shortDescMr: string;
  eligibilityEn: string[];
  eligibilityHi: string[];
  eligibilityMr: string[];
  benefitsEn: string[];
  benefitsHi: string[];
  benefitsMr: string[];
  applicationProcessEn: string[];
  applicationProcessHi: string[];
  applicationProcessMr: string[];
  requiredDocuments: string[];
  officialWebsiteUrl: string;
  lastUpdated: string;
  sourceAttribution: string;
}

export const SCHEMES_DATABASE: DetailedGovtSchemeRecord[] = [
  // 1. PM-KISAN
  {
    id: 'pm-kisan',
    schemeNameEn: 'PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)',
    schemeNameHi: 'प्रधानमंत्री किसान सम्मान निधि (पीएम-किसान)',
    schemeNameMr: 'पंतप्रधान किसान सन्मान निधी (पीएम-किसान)',
    departmentEn: 'Ministry of Agriculture & Farmers Welfare, Govt. of India',
    departmentHi: 'कृषि एवं किसान कल्याण मंत्रालय, भारत सरकार',
    departmentMr: 'कृषी व शेतकरी कल्याण मंत्रालय, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Farmer Income Support',
    benefitType: 'Financial Transfer',
    shortDescEn: 'Direct income support of ₹6,000 per year in three equal installments of ₹2,000 directly into the bank accounts of all landholding farmer families across India.',
    shortDescHi: 'भारत के सभी भूमिधारक किसान परिवारों के बैंक खातों में सीधे ₹2,000 की तीन समान किस्तों में प्रति वर्ष ₹6,000 की प्रत्यक्ष आय सहायता।',
    shortDescMr: 'भारतातील सर्व जमीनधारक शेतकरी कुटुंबांच्या बँक खात्यात थेट ₹२,००० च्या तीन समान हप्त्यांमध्ये वर्षाला ₹६,००० चे थेट उत्पन्न सहाय्य.',
    eligibilityEn: [
      'Small, marginal and all landholding farmer families having cultivable land in their names.',
      'Must have e-KYC completed on PM-KISAN portal.',
      'Aadhaar card linked with bank account and active NPCI DBT mapping.',
      'Excludes institutional landholders, high-income taxpayers, and government employees.'
    ],
    eligibilityHi: [
      'जिनके नाम कृषि योग्य भूमि दर्ज है, वे सभी छोटे, सीमांत व भूमिधारक किसान परिवार।',
      'पीएम-किसान पोर्टल पर ई-केवाईसी पूर्ण होना अनिवार्य है।',
      'बैंक खाते से आधार लिंक और एनपीसीआई डीबीटी मैपिंग सक्रिय होनी चाहिए।',
      'संस्थागत भूमिधारक, आयकर दाता और सरकारी कर्मचारी इसके पात्र नहीं हैं।'
    ],
    eligibilityMr: [
      'ज्यांच्या नावावर लागवडीयोग्य जमीन नोंदवलेली आहे अशी सर्व लहान व जमीनधारक शेतकरी कुटुंबे.',
      'पीएम-किसान पोर्टलवर ई-केवायसी पूर्ण असणे आवश्यक आहे.',
      'बँक खात्याशी आधार लिंक व डीबीटी मॅपिंग सक्रिय असावे.',
      'करदाते व सरकारी कर्मचारी या योजनेसाठी पात्र नाहीत.'
    ],
    benefitsEn: [
      'Direct benefit transfer (DBT) of ₹6,000 per year.',
      'Paid as ₹2,000 every 4 months (April-July, Aug-Nov, Dec-March).',
      'Zero intermediaries - direct credit into bank account.'
    ],
    benefitsHi: [
      'प्रति वर्ष ₹6,000 का सीधा डीबीटी लाभ।',
      'हर 4 महीने में ₹2,000 की तीन किस्तें।',
      'बिना किसी मध्यस्थ के सीधे बैंक खाते में राशि ट्रांसफर।'
    ],
    benefitsMr: [
      'दरवर्षी ₹६,००० ची थेट डीबीटी मदत.',
      'प्रत्येक ४ महिन्यांनी ₹२,००० चा हप्ता.',
      'कोणत्याही मध्यस्थाशिवाय थेट बँक खात्यात पैसे जमा.'
    ],
    applicationProcessEn: [
      'Visit the official PM-KISAN portal (pmkisan.gov.in) or your local Common Service Centre (CSC).',
      'Click on "Farmers Corner" -> "New Farmer Registration".',
      'Enter Aadhaar number, Mobile number, and select state.',
      'Fill land detail registration number (Khata / Khasra number) and upload land record (7/12 or Khatauni).',
      'Submit the form and complete e-KYC via OTP or biometric scan.'
    ],
    applicationProcessHi: [
      'आधिकारिक पीएम-किसान पोर्टल (pmkisan.gov.in) या नजदीकी सीएससी केंद्र पर जाएं।',
      '"Farmers Corner" -> "New Farmer Registration" पर क्लिक करें।',
      'आधार नंबर, मोबाइल नंबर दर्ज करें और अपना राज्य चुनें।',
      'जमीन का खसरा/खाता संख्या भरें और खतौनी/7/12 का विवरण अपलोड करें।',
      'फॉर्म सबमिट करें और ओटीपी अथवा बायोमेट्रिक से ई-केवाईसी पूरा करें।'
    ],
    applicationProcessMr: [
      'अधिकृत पीएम-किसान पोर्टल (pmkisan.gov.in) किंवा जवळच्या CSC केंद्राला भेट द्या.',
      '"Farmers Corner" -> "New Farmer Registration" वर क्लिक करा.',
      'आधार क्रमांक, मोबाईल नंबर टाका आणि राज्य निवडा.',
      'जमिनीचा ७/१२ किंवा ७/१२ उतारा तपशील भरा.',
      'फॉर्म सबमिट करून ओटीपी द्वारे ई-केवायसी पूर्ण करा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Land Ownership Record (7/12 Extract / Khatauni / Jamabandi)',
      'Bank Account Passbook with IFSC Code',
      'Active Mobile Number linked to Aadhaar'
    ],
    officialWebsiteUrl: 'https://pmkisan.gov.in',
    lastUpdated: '2026-09-01',
    sourceAttribution: 'Ministry of Agriculture & Farmers Welfare, Govt. of India (myScheme.gov.in)'
  },

  // 2. PMFBY
  {
    id: 'pmfby',
    schemeNameEn: 'PMFBY (Pradhan Mantri Fasal Bima Yojana)',
    schemeNameHi: 'प्रधानमंत्री फसल बीमा योजना (पीएमएफबीवाई)',
    schemeNameMr: 'पंतप्रधान पीक विमा योजना (पीएमएफबीवाई)',
    departmentEn: 'Department of Agriculture & Farmers Welfare, Govt. of India',
    departmentHi: 'कृषि एवं किसान कल्याण विभाग, भारत सरकार',
    departmentMr: 'कृषी व शेतकरी कल्याण विभाग, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Crop Insurance',
    benefitType: 'Insurance Cover',
    shortDescEn: 'Comprehensive insurance cover against crop loss due to non-preventable natural risks from pre-sowing to post-harvest at extremely nominal premium rates (1.5% - 2%).',
    shortDescHi: 'अत्यंत मामूली प्रीमियम दरों (1.5% - 2%) पर बुआई से पहले से लेकर कटाई के बाद तक गैर-निवार्य प्राकृतिक जोखिमों के कारण फसल क्षति पर व्यापक बीमा सुरक्षा।',
    shortDescMr: 'अतिशय नाममात्र प्रीमियम दरात (१.५% - २%) पेरणीपूर्व ते काढणीनंतरच्या नैसर्गिक आपत्तींमुळे होणाऱ्या पीक नुकसानीसाठी सर्वसमावेशक विमा संरक्षण.',
    eligibilityEn: [
      'All farmers including sharecroppers and tenant farmers growing notified crops in notified areas.',
      'Voluntary for non-loanee farmers, optional for loanee farmers as per revised guidelines.',
      'Sowing/planting certificate from Revenue Department or Village Officer.'
    ],
    eligibilityHi: [
      'अधिसूचित क्षेत्रों में अधिसूचित फसल उगाने वाले बटाईदार और पट्टेदार किसानों सहित सभी किसान।',
      'गैर-ऋणी किसानों के लिए स्वैच्छिक और ऋणी किसानों के लिए भी आसान प्रक्रिया।',
      'राजस्व विभाग या पटवारी से बुआई प्रमाण पत्र।'
    ],
    eligibilityMr: [
      'अधिसूचित क्षेत्रात अधिसूचित पिके घेणारे कुळ व भाडेकरू शेतकऱ्यांसह सर्व शेतकरी.',
      'बिगर कर्जदार शेतकऱ्यांसाठी ऐच्छिक.',
      'तलाठ्याकडून पीक पाहणी ७/१२ उतारा नोंद.'
    ],
    benefitsEn: [
      'Kharif crops premium: only 2.0% of Sum Insured.',
      'Rabi crops premium: only 1.5% of Sum Insured.',
      'Commercial / Horticultural crops: 5.0% premium.',
      '100% claim payout directly to bank account for localized calamities, prevented sowing & post-harvest loss.'
    ],
    benefitsHi: [
      'खरीफ फसलों के लिए प्रीमियम केवल 2.0%।',
      'रबी फसलों के लिए प्रीमियम केवल 1.5%।',
      'व्यावसायिक/बागवानी फसलों के लिए 5.0%।',
      'प्राकृतिक आपदा, बेमौसम बारिश व जलभराव पर बैंक खाते में 100% क्लेम का भुगतान।'
    ],
    benefitsMr: [
      'खरीप पिकांसाठी प्रीमियम फक्त २.०%.',
      'रब्बी पिकांसाठी प्रीमियम फक्त १.५%.',
      'नुकसानभरपाई थेट बँक खात्यात जमा.'
    ],
    applicationProcessEn: [
      'Log on to the PMFBY portal (pmfby.gov.in) or visit nearest bank / CSC.',
      'Select State, Bank, and Crop details.',
      'Upload Aadhaar, Land documents (7/12), and Sowing declaration.',
      'Pay nominal premium online using UPI/Debit Card or at CSC counter.',
      'Receive instant Insurance Policy Certificate with Policy ID.'
    ],
    applicationProcessHi: [
      'PMFBY पोर्टल (pmfby.gov.in) पर जाएं या बैंक/सीएससी सेंटर जाएं।',
      'राज्य, बैंक और फसल का चुनाव करें।',
      'आधार, जमीन रिकॉर्ड और बुआई घोषणा पत्र अपलोड करें।',
      'ऑनलाइन प्रीमियम भुगतान करें और पॉलिसी रसीद प्राप्त करें।'
    ],
    applicationProcessMr: [
      'PMFBY पोर्टल (pmfby.gov.in) वर जा अथवा जवळच्या बँका/CSC केंद्रावर जा.',
      'राज्य आणि पीक निवडा.',
      'आधार, ७/१२ आणि पीक पाहणी फॉर्म अपलोड करा.',
      'प्रीमियम भरा आणि पीक विमा पावती मिळवा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Land Possession Document / 7/12 / Khasra-Khatauni',
      'Sowing Certificate signed by Patwari/Talathi',
      'Cancelled Cheque / Bank Passbook'
    ],
    officialWebsiteUrl: 'https://pmfby.gov.in',
    lastUpdated: '2026-08-28',
    sourceAttribution: 'Ministry of Agriculture & Farmers Welfare, Govt. of India'
  },

  // 3. Namo Shetkari Maha Samman Nidhi (Maharashtra)
  {
    id: 'namo-shetkari-mh',
    schemeNameEn: 'Namo Shetkari Maha Samman Nidhi Yojana (Maharashtra)',
    schemeNameHi: 'नमो शेतकारी महा सम्मान निधि योजना (महाराष्ट्र)',
    schemeNameMr: 'नमो शेतकरी महासन्मान निधी योजना (महाराष्ट्र)',
    departmentEn: 'Department of Agriculture, Govt. of Maharashtra',
    departmentHi: 'कृषि विभाग, महाराष्ट्र सरकार',
    departmentMr: 'कृषी विभाग, महाराष्ट्र शासन',
    schemeType: 'State',
    state: 'Maharashtra',
    category: 'Farmer Income Support',
    benefitType: 'Financial Transfer',
    shortDescEn: 'Maharashtra Government top-up financial assistance of ₹6,000 per year (giving total ₹12,000 per year along with PM-KISAN) to 1.5 crore beneficiary farmers in Maharashtra.',
    shortDescHi: 'महाराष्ट्र सरकार द्वारा राज्य के 1.5 करोड़ किसान लाभार्थियों को प्रति वर्ष ₹6,000 (पीएम-किसान मिलाकर कुल ₹12,000 प्रति वर्ष) की अतिरिक्त वित्तीय सहायता।',
    shortDescMr: 'महाराष्ट्र शासनाकडून राज्यातील १.५ कोटी पात्र शेतकऱ्यांना दरवर्षी ₹६,००० (पीएम-किसानसह एकूण ₹१२,००० प्रतिवर्ष) अतिरिक्त थेट आर्थिक मदत.',
    eligibilityEn: [
      'Resident farmer of Maharashtra state.',
      'Must be an active beneficiary registered under PM-KISAN scheme.',
      'Land record (7/12 extract) registered in Maharashtra land repository.',
      'e-KYC and Bank Aadhaar seeding completed.'
    ],
    eligibilityHi: [
      'महाराष्ट्र राज्य का निवासी किसान।',
      'पीएम-किसान योजना के तहत सक्रिय लाभार्थी होना अनिवार्य है।',
      'महाराष्ट्र भूमि रिकॉर्ड में 7/12 दर्ज होना चाहिए।',
      'ई-केवाईसी और बैंक आधार सीडिंग पूर्ण।'
    ],
    eligibilityMr: [
      'महाराष्ट्र राज्याचा रहिवासी शेतकरी.',
      'पीएम-किसान योजनेचा सक्रिय लाभार्थी असणे आवश्यक.',
      'महाराष्ट्रातील ७/१२ उतारा नाव नोंद.',
      'आधार बँक सीडींग पूर्ण.'
    ],
    benefitsEn: [
      'Additional financial bonus of ₹6,000 per annum.',
      'Combined with PM-KISAN, Maharashtra farmers receive ₹12,000 annually.',
      'Paid in 3 equal installments of ₹2,000.'
    ],
    benefitsHi: [
      'प्रति वर्ष ₹6,000 की अतिरिक्त वित्तीय सहायता।',
      'पीएम-किसान मिलाकर कुल ₹12,000 सालाना आय।',
      '₹2,000 की 3 समान किस्तों में भुगतान।'
    ],
    benefitsMr: [
      'वार्षिक ₹६,००० ची अतिरिक्त आर्थिक मदत.',
      'पीएम-किसान मिळून एकूण ₹१२,००० निधी.',
      '३ हप्त्यांमध्ये थेट बँक खात्यात जमा.'
    ],
    applicationProcessEn: [
      'Automatic qualification for all approved PM-KISAN beneficiaries in Maharashtra.',
      'Check status on MahaDBT portal (mahadbt.maharashtra.gov.in) or Krishi Maharashtra site.',
      'If not receiving, update Aadhaar-DBT linking at your bank branch.'
    ],
    applicationProcessHi: [
      'महाराष्ट्र के सभी पीएम-किसान पात्र लाभार्थियों के लिए स्वचालित स्वीकृति।',
      'महाडीबीटी पोर्टल पर अपना स्टेटस चेक करें।',
      'यदि लाभ न मिले तो बैंक शाखा में डीबीटी एक्टिव कराएं।'
    ],
    applicationProcessMr: [
      'महाराष्ट्रातील सर्व पात्र पीएम-किसान लाभार्थ्यांचा आपोआप समावेश.',
      'MahaDBT पोर्टलवर किंवा कृषी महाराष्ट्र संकेतस्थळावर स्टेटस तपासा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      '7/12 & 8A Land Extract (Maharashtra)',
      'Aadhaar Linked Bank Passbook',
      'PM-KISAN Registration Number'
    ],
    officialWebsiteUrl: 'https://krishi.maharashtra.gov.in',
    lastUpdated: '2026-08-25',
    sourceAttribution: 'Department of Agriculture, Govt. of Maharashtra (MahaDBT Portal)'
  },

  // 4. PM-KUSUM
  {
    id: 'pm-kusum',
    schemeNameEn: 'PM-KUSUM (Pradhan Mantri Kisan Urja Suraksha evam Utthan Mahabhiyan)',
    schemeNameHi: 'प्रधानमंत्री किसान ऊर्जा सुरक्षा एवं उत्थान महाभियान (पीएम-कुसुम)',
    schemeNameMr: 'पंतप्रधान शेतकरी ऊर्जा सुरक्षा व उत्थान अभियान (पीएम-कुसुम)',
    departmentEn: 'Ministry of New and Renewable Energy (MNRE), Govt. of India',
    departmentHi: 'नवीन और नवीकरणीय ऊर्जा मंत्रालय, भारत सरकार',
    departmentMr: 'नवीन व नवीकरणीय ऊर्जा मंत्रालय, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Agriculture Subsidy',
    benefitType: 'Subsidy',
    shortDescEn: 'Up to 60% to 90% capital subsidy for installing stand-alone off-grid solar agriculture pumps (3 HP to 10 HP) and solarization of existing grid-connected agriculture pumps.',
    shortDescHi: 'स्टैंड-अलोन सौर कृषि पंपों (3 एचपी से 10 एचपी) की स्थापना और मौजूदा ग्रिड-कनेक्टेड कृषि पंपों के सौरकरण पर 60% से 90% तक की भारी सब्सिडी।',
    shortDescMr: 'स्वतंत्र सौर कृषी पंप (३ HP ते १० HP) बसवण्यासाठी आणि ग्रीड पंपांचे सौर ऊर्जेत रूपांतर करण्यासाठी ६०% ते ९०% पर्यंत भरीव सबसिडी.',
    eligibilityEn: [
      'Individual farmers, Water User Associations, Panchayats, Farmer Producer Organizations (FPOs).',
      'Must have valid agricultural land ownership and a reliable water source (borewell/well/farm pond).',
      'Farmers without existing electricity connection get high priority for Component-B.'
    ],
    eligibilityHi: [
      'व्यक्तिगत किसान, जल उपभोक्ता संघ, पंचायतें, किसान उत्पादक संगठन (एफपीओ)।',
      'वैध कृषि भूमि और जल स्रोत (बोरवेल/कुआं/शेततळे) होना आवश्यक।',
      'बिजली कनेक्शन रहित किसानों को प्राथमिकता।'
    ],
    eligibilityMr: [
      'वैयक्तिक शेतकरी, पाणी वापर संस्था, एफपीओ (FPO).',
      'स्वतःच्या नावावर जमीन आणि पाण्याचा स्रोत (विहीर/बोअरवेल/शेततळे) असावा.'
    ],
    benefitsEn: [
      '30% Central Financial Assistance (CFA) + 30% State Govt Subsidy = 60% Total Subsidy (up to 90% in SC/ST/hilly regions).',
      'Farmer pays only 10% to 40% of pump cost.',
      '25 years guaranteed free daytime solar electricity for irrigation.',
      'Earn additional income by selling surplus solar power back to DISCOM.'
    ],
    benefitsHi: [
      '30% केंद्र सब्सिडी + 30% राज्य सब्सिडी = 60% कुल सब्सिडी (अनुसूचित जाति/जनजाति के लिए 90% तक)।',
      'किसान को केवल 10% से 40% लागत देनी होती है।',
      '25 वर्षों तक सिंचाई के लिए मुफ्त सौर बिजली।',
      'अतिरिक्त सौर बिजली ग्रिड को बेचकर अतिरिक्त कमाई।'
    ],
    benefitsMr: [
      '६०% ते ९०% पर्यंत थेट अनुदान.',
      'शेतकऱ्याला फक्त १०% ते ४०% रक्कम भरावी लागते.',
      '२५ वर्षे मोफत सौर वीज.'
    ],
    applicationProcessEn: [
      'Apply online via your respective State Renewable Energy Agency portal (e.g. MahaUrja / RajKisan / UP Solar).',
      'Submit Land ownership documents, Water source proof, and Bank details.',
      'Pay beneficiary contribution share (10%-40%) online.',
      'Empaneled solar vendor inspects site and installs solar pump within 30-45 days.'
    ],
    applicationProcessHi: [
      'अपनी राज्य अक्षय ऊर्जा एजेंसी (जैसे महाऊर्जा/राजकिसान) के पोर्टल पर ऑनलाइन आवेदन करें।',
      'जमीन का नक्शा, जल स्रोत प्रमाण और बैंक विवरण जमा करें।',
      'अपना किसान अंशदान (10%-40%) ऑनलाइन जमा करें।',
      '30-45 दिनों में आपके खेत पर सोलर पंप स्थापित कर दिया जाएगा।'
    ],
    applicationProcessMr: [
      'राज्याच्या महाऊर्जा / महाकृषी पोर्टलवर ऑनलाईन अर्ज करा.',
      'जमिनीचा उतारा व पाण्याचा पुरावा अपलोड करा.',
      'शेतकरी हिस्सा भरल्यानंतर ३०-४५ दिवसात सोलर पंप बसवून मिळतो.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Land Record (7/12 Extract / Khasra-Khatauni)',
      'Water Source Affidavit / Borewell Certificate',
      'Bank Account Details',
      'Passport size Photograph'
    ],
    officialWebsiteUrl: 'https://pmkusum.mnre.gov.in',
    lastUpdated: '2026-08-30',
    sourceAttribution: 'Ministry of New and Renewable Energy, Govt. of India'
  },

  // 5. Agriculture Infrastructure Fund (AIF)
  {
    id: 'aif-scheme',
    schemeNameEn: 'Agriculture Infrastructure Fund (AIF)',
    schemeNameHi: 'कृषि अवसंरचना कोष (एआईएफ)',
    schemeNameMr: 'कृषी पायाभूत सुविधा निधी (एआईएफ)',
    departmentEn: 'Ministry of Agriculture & Farmers Welfare, Govt. of India',
    departmentHi: 'कृषि एवं किसान कल्याण मंत्रालय, भारत सरकार',
    departmentMr: 'कृषी व शेतकरी कल्याण मंत्रालय, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Agricultural Infrastructure',
    benefitType: 'Credit Facility',
    shortDescEn: 'Medium-long term debt financing facility for investment in viable post-harvest management infrastructure and community farming assets with 3% interest subvention up to ₹2 Crore loan.',
    shortDescHi: 'कटाई के बाद प्रबंधन अवसंरचना और सामुदायिक कृषि संपत्तियों (जैसे कोल्ड स्टोरेज, गोदाम, ग्रेडिंग यूनिट) में निवेश के लिए ₹2 करोड़ तक के ऋण पर 3% ब्याज छूट।',
    shortDescMr: 'काढणीनंतरचे व्यवस्थापन, शीतगृह, गोदामे आणि प्रक्रिया केंद्रांसाठी ₹२ कोटींपर्यंतच्या कर्जावर ३% व्याज सवलत.',
    eligibilityEn: [
      'Farmers, Agri-Entrepreneurs, Startups, Primary Agricultural Credit Societies (PACS), FPOs, SHGs.',
      'Projects related to Warehouses, Cold Storage, Sorting & Grading units, Assaying units, Custom Hiring Centres.'
    ],
    eligibilityHi: [
      'किसान, कृषि-उद्यमी, स्टार्ट-अप, प्राथमिक कृषि साख समितियां (पैक्स), एफपीओ, स्वयं सहायता समूह।',
      'गोदाम, कोल्ड स्टोरेज, सॉर्टिंग, पैक हाउस और कस्टम हायरिंग सेंटर प्रोजेक्ट।'
    ],
    eligibilityMr: [
      'शेतकरी, कृषी व्यावसायिक, स्टार्टअप्स, पीएसीएस (PACS), एफपीओ (FPO), महिला बचत गट.'
    ],
    benefitsEn: [
      '3% per annum interest subvention up to loan of ₹2 Crore for max 7 years.',
      'Credit guarantee coverage under CGTMSE for loans up to ₹2 Crore.',
      'Moratorium for repayment up to 2 years.'
    ],
    benefitsHi: [
      '₹2 करोड़ तक के ऋण पर 3% प्रति वर्ष ब्याज सब्सिडी (7 वर्षों के लिए)।',
      'CGTMSE के तहत बिना किसी बैंक गारंटी के ₹2 करोड़ तक क्रेडिट गारंटी।',
      '2 साल तक की ऋण पुनर्भुगतान छूट (मोरेटोरियम)।'
    ],
    benefitsMr: [
      '₹२ कोटींपर्यंतच्या कर्जावर ३% वार्षिक व्याज सवलत.',
      'CGTMSE द्वारे गॅरंटी.',
      '२ वर्षांपर्यंत हप्ता माफी कालावधी.'
    ],
    applicationProcessEn: [
      'Register on the official AIF Portal (agriinfra.dac.gov.in).',
      'Create project proposal detailing post-harvest asset, estimated cost, and location.',
      'Select lending bank / financial institution for DPR submission.',
      'Bank evaluates and sanctions loan with interest subvention automatically applied.'
    ],
    applicationProcessHi: [
      'AIF पोर्टल (agriinfra.dac.gov.in) पर रजिस्टर करें।',
      'कोल्ड स्टोरेज या गोदाम प्रोजेक्ट प्रस्ताव और लागत अपलोड करें।',
      'बैंक चुनें और प्रोजेक्ट डीपीआर सबमिट करें।'
    ],
    applicationProcessMr: [
      'AIF पोर्टल (agriinfra.dac.gov.in) वर नोंदणी करा.',
      'प्रकल्प अहवाल (DPR) अपलोड करून बँकेकडे अर्ज पाठवा.'
    ],
    requiredDocuments: [
      'Applicant ID & Aadhaar Card',
      'Detailed Project Report (DPR)',
      'Land Ownership / Lease Agreement (minimum 10 years)',
      'Bank Statement & GST / PAN if applicable'
    ],
    officialWebsiteUrl: 'https://agriinfra.dac.gov.in',
    lastUpdated: '2026-08-15',
    sourceAttribution: 'Ministry of Agriculture & Farmers Welfare, Govt. of India'
  },

  // 6. Sub-Mission on Agricultural Mechanization (SMAM)
  {
    id: 'smam-machinery',
    schemeNameEn: 'Sub-Mission on Agricultural Mechanization (SMAM)',
    schemeNameHi: 'कृषि यांत्रीकरण पर उप-मिशन (एसएमएएम)',
    schemeNameMr: 'कृषी यांत्रिकीकरण उप-अभियान (एसएमएएम)',
    departmentEn: 'Department of Agriculture & Farmers Welfare, Govt. of India',
    departmentHi: 'कृषि एवं किसान कल्याण विभाग, भारत सरकार',
    departmentMr: 'कृषी व शेतकरी कल्याण विभाग, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Farm Machinery',
    benefitType: 'Subsidy',
    shortDescEn: '40% to 80% subsidy on purchase of modern farm machinery (Tractors, Rotavators, Power Tillers, Combined Harvesters, Agriculture Drones) and setting up Custom Hiring Centres (CHC).',
    shortDescHi: 'आधुनिक कृषि उपकरणों (ट्रैक्टर, रोटावेटर, पावर टिलर, ड्रोन, हार्वेस्टर) की खरीद और कस्टम हायरिंग सेंटर्स (CHC) की स्थापना पर 40% से 80% की भारी सब्सिडी।',
    shortDescMr: 'आधुनिक कृषी अवजारे (ट्रॅक्टर, रोटाव्हेटर, ड्रोन, पॉवर टेलर) खरेदीसाठी आणि कस्टम हायरिंग सेंटरसाठी ४०% ते ८०% अनुदान.',
    eligibilityEn: [
      'Small and marginal farmers, SC/ST, Women farmers get up to 50% - 80% subsidy.',
      'General category farmers get up to 40% subsidy.',
      'FPOs, Panchayats, Cooperative societies eligible for establishing Custom Hiring Centres (CHC).'
    ],
    eligibilityHi: [
      'छोटे व सीमांत किसान, अनुसूचित जाति/जनजाति व महिला किसानों को 50% से 80% तक सब्सिडी।',
      'सामान्य श्रेणी के किसानों को 40% सब्सिडी।',
      'कस्टम हायरिंग सेंटर (CHC) के लिए एफपीओ और पंचायतें पात्र।'
    ],
    eligibilityMr: [
      'लहान व अल्पभूधारक, महिला व अनुसूचित जाती/जमाती शेतकऱ्यांना ५०% ते ८०% अनुदान.'
    ],
    benefitsEn: [
      'Financial assistance of 40% to 50% for individual machinery purchase.',
      'Up to 80% subsidy (max ₹10 Lakh) for establishing Custom Hiring Centres (CHC).',
      'Special 50% to 75% subsidy on Kisan Agricultural Drones for spraying.'
    ],
    benefitsHi: [
      'व्यक्तिगत मशीनरी खरीद पर 40% से 50% की छूट।',
      'कस्टम हायरिंग सेंटर स्थापना पर 80% (अधिकतम ₹10 लाख) की सब्सिडी।',
      'कृषि स्प्रे ड्रोन पर 50% से 75% तक विशेष सब्सिडी।'
    ],
    benefitsMr: [
      'वैयक्तिक अवजारे खरेदीवर ४०% ते ५०% सवलत.',
      'कस्टम हायरिंग सेंटरसाठी ८०% पर्यंत अनुदान.',
      'किसान ड्रोनसाठी विशेष अनुदान.'
    ],
    applicationProcessEn: [
      'Register on the official Farmech Portal (agrimachinery.nic.in) or state portal (e.g. MahaDBT / UP Krishi / RajKisan).',
      'Choose the machinery model and approved dealer.',
      'Upload Aadhaar, Land record (7/12), and quotation.',
      'Upon pre-sanction letter, purchase tractor/implements and upload invoice & photo with GPS location.'
    ],
    applicationProcessHi: [
      'पोर्टल (agrimachinery.nic.in) या राज्य कृषि पोर्टल पर रजिस्ट्रेशन करें।',
      'कृषि उपकरण व अनुमोदित डीलर का चुनाव करें।',
      '7/12 और कोटेशन अपलोड करें।',
      'स्वीकृति पत्र मिलने के बाद उपकरण खरीदें और बिल अपलोड करें।'
    ],
    applicationProcessMr: [
      'agrimachinery.nic.in किंवा राज्याच्या कृषी पोर्टलवर नोंदणी करा.',
      'अवजार व डीलर निवडून कोटेशन अपलोड करा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Land Records (7/12 Extract / Khasra-Khatauni)',
      'Quotation from Authorized Dealer',
      'Bank Account Details',
      'Caste Certificate (if applying under SC/ST quota)'
    ],
    officialWebsiteUrl: 'https://agrimachinery.nic.in',
    lastUpdated: '2026-08-20',
    sourceAttribution: 'Ministry of Agriculture & Farmers Welfare, Govt. of India'
  },

  // 7. Soil Health Card Scheme
  {
    id: 'soil-health-card',
    schemeNameEn: 'Soil Health Card Scheme',
    schemeNameHi: 'मृदा स्वास्थ्य कार्ड योजना',
    schemeNameMr: 'मृदा आरोग्य पत्रक योजना',
    departmentEn: 'Ministry of Agriculture & Farmers Welfare, Govt. of India',
    departmentHi: 'कृषि एवं किसान कल्याण मंत्रालय, भारत सरकार',
    departmentMr: 'कृषी व शेतकरी कल्याण मंत्रालय, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Soil Health',
    benefitType: 'Input Support',
    shortDescEn: 'Free soil testing and customized crop-wise fertilizer dosage advice issued every 2-3 years to optimize soil nutrients (NPK + Micro-nutrients) and reduce cultivation costs.',
    shortDescHi: 'मिट्टी के पोषक तत्वों (एनपीके + सूक्ष्म पोषक तत्व) के सुधार और उर्वरक लागत घटाने के लिए हर 2-3 साल में मुफ्त मिट्टी जांच और फसलवार उर्वरक सिफारिश कार्ड।',
    shortDescMr: 'जमिनीची सुपीकता वाढवण्यासाठी आणि खतांचा खर्च कमी करण्यासाठी दर २-३ वर्षांनी मोफत माती परीक्षण व पीकनिहाय खत वापराचे मार्गदर्शन पत्रक.',
    eligibilityEn: [
      'All farmers owning cultivable land across all states and Union Territories.',
      'Zero application fee - fully funded by Central and State Governments.'
    ],
    eligibilityHi: [
      'सभी राज्यों और केंद्र शासित प्रदेशों के कृषि भूमि वाले सभी किसान।',
      'शून्य आवेदन शुल्क - पूर्णतः सरकारी वित्त पोषित।'
    ],
    eligibilityMr: [
      'भारतातील सर्व शेतकरी. शून्य फी.'
    ],
    benefitsEn: [
      'Detailed report on 12 soil health parameters (N, P, K, S, Zn, Fe, Cu, Mn, Bo, pH, EC, OC).',
      'Customized dosage recommendation for chemical and organic fertilizers.',
      'Saves 10-20% on fertilizer expenses while increasing crop yields by 8-15%.'
    ],
    benefitsHi: [
      '12 मिट्टी मानकों (नाइट्रोजन, फास्फोरस, पोटाश, जिंक, आयरन, पीएच मान आदि) की विस्तृत रिपोर्ट।',
      'रासायनिक व जैविक खाद की सटीक खुराक सिफारिश।',
      'उर्वरक खर्च में 10-20% बचत और पैदावार में 8-15% वृद्धि।'
    ],
    benefitsMr: [
      '१२ माती घटकांचे विश्लेषण.',
      'खातांचा खर्च १०-२०% कमी होतो.'
    ],
    applicationProcessEn: [
      'Visit your Block Agriculture Office or Village Agriculture Extension Officer.',
      'Request soil sample collection from your farm plot.',
      'Track testing status and download Soil Health Card online from soilhealth.dac.gov.in.'
    ],
    applicationProcessHi: [
      'अपने ब्लॉक कृषि अधिकारी या ग्राम कृषि सहायक से संपर्क करें।',
      'अपने खेत की मिट्टी के नमूने की जांच का अनुरोध करें।',
      'soilhealth.dac.gov.in पर ऑनलाइन अपना मृदा स्वास्थ्य कार्ड डाउनलोड करें।'
    ],
    applicationProcessMr: [
      'तालुका कृषी अधिकारी किंवा कृषी सहाय्यकांशी संपर्क साधा.',
      'soilhealth.dac.gov.in वरून सॉईल कार्ड डाउनलोड करा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Survey / Khata / Khasra Number of the Farm Plot',
      'Mobile Number'
    ],
    officialWebsiteUrl: 'https://soilhealth.dac.gov.in',
    lastUpdated: '2026-08-10',
    sourceAttribution: 'Department of Agriculture & Farmers Welfare (soilhealth.dac.gov.in)'
  },

  // 8. PMksy (Pradhan Mantri Krishi Sinchayee Yojana - Per Drop More Crop)
  {
    id: 'pmksy-drip-irrigation',
    schemeNameEn: 'PMKSY - Per Drop More Crop (Drip & Sprinkler Subsidy)',
    schemeNameHi: 'प्रधानमंत्री कृषि सिंचाई योजना - प्रति बूंद अधिक फसल (ड्रिप एवं स्प्रिंकलर सब्सिडी)',
    schemeNameMr: 'पंतप्रधान कृषी सिंचन योजना - प्रति थेंब जास्त पीक (ठिबक व तुषार अनुदान)',
    departmentEn: 'Ministry of Agriculture & Farmers Welfare, Govt. of India',
    departmentHi: 'कृषि एवं किसान कल्याण मंत्रालय, भारत सरकार',
    departmentMr: 'कृषी व शेतकरी कल्याण मंत्रालय, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Irrigation',
    benefitType: 'Subsidy',
    shortDescEn: '55% to 80% subsidy on installation of micro-irrigation systems (Drip Irrigation and Sprinkler Sets) to maximize water use efficiency and crop productivity.',
    shortDescHi: 'जल उपयोग दक्षता और फसल उत्पादकता बढ़ाने के लिए सूक्ष्म सिंचाई प्रणालियों (ड्रिप सिंचाई और स्प्रिंकलर) की स्थापना पर 55% से 80% तक की भारी सब्सिडी।',
    shortDescMr: 'पाण्याची बचत व उत्पादन वाढवण्यासाठी ठिबक सिंचन आणि तुषार सिंचन संच बसवण्यासाठी ५५% ते ८०% पर्यंत अनुदान.',
    eligibilityEn: [
      'All farmers having valid land ownership and an assured water source.',
      'Small and marginal farmers receive 55% Central/State subsidy + State top-up (up to 80% in MH, GJ, AP, TN).',
      'Group of farmers / Cooperatives eligible for community micro-irrigation.'
    ],
    eligibilityHi: [
      'वैध भूमि स्वामित्व और सुनिश्चित जल स्रोत वाले सभी किसान।',
      'छोटे व सीमांत किसानों को 55% से 80% तक की भारी सब्सिडी।'
    ],
    eligibilityMr: [
      'सर्व जमीनधारक शेतकरी. लहान व अल्पभूधारक शेतकऱ्यांना ८०% पर्यंत अनुदान.'
    ],
    benefitsEn: [
      'Saves 40% to 50% irrigation water.',
      'Saves 30% to 40% fertilizer cost via fertigation.',
      'Increase in crop yield by 20% to 30%.'
    ],
    benefitsHi: [
      '40% से 50% सिंचाई पानी की बचत।',
      'फर्टिगेशन के जरिए 30% से 40% खाद खर्च में कमी।',
      'फसल पैदावार में 20% से 30% की वृद्धि।'
    ],
    benefitsMr: [
      '४०-५०% पाण्याची बचत, ३०% खत बचत आणि उत्पादनात २०-३०% वाढ.'
    ],
    applicationProcessEn: [
      'Apply online on your state micro-irrigation portal (e.g. MahaDBT / GGRC Gujarat / RajKisan / TN-AGRISNET).',
      'Select micro-irrigation company approved vendor and obtain field layout quotation.',
      'Upload 7/12 extract and water source availability proof.',
      'Vendor installs drip system after field inspection and subsidy is credited via DBT.'
    ],
    applicationProcessHi: [
      'राज्य कृषि/सूक्ष्म सिंचाई पोर्टल पर ऑनलाइन आवेदन करें।',
      'अनुमोदित कंपनी और कोटेशन का चुनाव करें।',
      '7/12 और पानी का प्रमाण पत्र अपलोड करें।'
    ],
    applicationProcessMr: [
      'MahaDBT / राज्य पोर्टलवर ऑनलाईन अर्ज करा आणि कोटेशन अपलोड करा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Land Record (7/12 Extract / Khasra-Khatauni)',
      'Water Source Proof (Well/Borewell Electricity Bill / NOC)',
      'Quotation & Drip System Design Blueprint',
      'Bank Account Passbook'
    ],
    officialWebsiteUrl: 'https://pmksy.gov.in',
    lastUpdated: '2026-08-18',
    sourceAttribution: 'Ministry of Agriculture & Farmers Welfare (pmksy.gov.in)'
  },

  // 9. Rythu Bandhu / Rythu Bima (Telangana)
  {
    id: 'rythu-bandhu-ts',
    schemeNameEn: 'Rythu Bandhu Investment Support Scheme (Telangana)',
    schemeNameHi: 'रयतू बंधु निवेश सहायता योजना (तेलंगाना)',
    schemeNameMr: 'रयतू बंधू गुंतवणूक सहाय्य योजना (तेलंगणा)',
    departmentEn: 'Department of Agriculture, Govt. of Telangana',
    departmentHi: 'कृषि विभाग, तेलंगाना सरकार',
    departmentMr: 'कृषी विभाग, तेलंगणा शासन',
    schemeType: 'State',
    state: 'Telangana',
    category: 'Farmer Income Support',
    benefitType: 'Financial Transfer',
    shortDescEn: 'Financial assistance of ₹10,000 per acre per year (₹5,000 per acre for Kharif and ₹5,000 per acre for Rabi) for purchasing seeds, fertilizers, and pesticides.',
    shortDescHi: 'बीज, उर्वरक और कीटनाशक खरीदने के लिए प्रति वर्ष ₹10,000 प्रति एकड़ (खरीफ के लिए ₹5,000 और रबी के लिए ₹5,000) की वित्तीय सहायता।',
    shortDescMr: 'बियाणे, खते व औषधे खरेदीसाठी प्रतिवर्षी ₹१०,००० प्रति एकर (खरीप ₹५,००० + रब्बी ₹५,०००) थेट आर्थिक मदत.',
    eligibilityEn: [
      'Pattadar farmer family owning agriculture land in Telangana.',
      'Possesses valid digital Pattadar Passbook (Pahani).'
    ],
    eligibilityHi: [
      'तेलंगाना में कृषि भूमि के स्वामी पट्टादार किसान परिवार।',
      'वैध डिजिटल पट्टादार पासबुक (पहानी) होना आवश्यक।'
    ],
    eligibilityMr: [
      'तेलंगणातील सर्व पट्टादार शेतकरी कुटुंब.'
    ],
    benefitsEn: [
      '₹10,000 per acre direct cash transfer annually.',
      'Covers both Kharif and Rabi seasons.',
      'No upper ceiling on acreage.'
    ],
    benefitsHi: [
      '₹10,000 प्रति एकड़ सालाना सीधा नकद ट्रांसफर।',
      'खरीफ और रबी दोनों मौसमों के लिए कवर।'
    ],
    benefitsMr: [
      'वार्षिक ₹१०,००० प्रति एकर मदत.'
    ],
    applicationProcessEn: [
      'Automatic transfer based on Dharani portal land registration records.',
      'New land buyers submit Pattadar passbook details to AEO.'
    ],
    applicationProcessHi: [
      'धरणी पोर्टल भूमि रिकॉर्ड के आधार पर स्वतः स्थानांतरण।'
    ],
    applicationProcessMr: [
      'धराणी पोर्टल ७/१२ नोंदीनुसार खात्यावर रक्कम जमा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Pattadar Passbook / Dharani Land Record',
      'Bank Account Passbook'
    ],
    officialWebsiteUrl: 'https://rythubandhu.telangana.gov.in',
    lastUpdated: '2026-08-12',
    sourceAttribution: 'Department of Agriculture, Govt. of Telangana'
  },

  // 10. Krishak Bandhu (West Bengal)
  {
    id: 'krishak-bandhu-wb',
    schemeNameEn: 'Krishak Bandhu (West Bengal)',
    schemeNameHi: 'कृषक बंधु योजना (पश्चिम बंगाल)',
    schemeNameMr: 'कृषक बंधू योजना (पश्चिम बंगाल)',
    departmentEn: 'Department of Agriculture, Govt. of West Bengal',
    departmentHi: 'कृषि विभाग, पश्चिम बंगाल सरकार',
    departmentMr: 'कृषी विभाग, पश्चिम बंगाल शासन',
    schemeType: 'State',
    state: 'West Bengal',
    category: 'Farmer Income Support',
    benefitType: 'Financial Transfer',
    shortDescEn: 'Financial assistance of up to ₹10,000 per year (minimum ₹4,000 for small landholders) plus ₹2 Lakh life insurance cover upon natural or accidental death of a farmer.',
    shortDescHi: 'प्रति वर्ष ₹10,000 तक की वित्तीय सहायता (छोटे भूमिधारकों के लिए न्यूनतम ₹4,000) और किसान की मृत्यु पर ₹2 लाख का जीवन बीमा कवर।',
    shortDescMr: 'दरवर्षी ₹१०,००० पर्यंत आर्थिक मदत (किमान ₹४,०००) अधिक शेतकऱ्याच्या मृत्यूनंतर ₹२ लाख आयुष्य विमा.',
    eligibilityEn: [
      'All landholding farmers and recorded bargadars (sharecroppers) in West Bengal aged 18 to 60 years.'
    ],
    eligibilityHi: [
      'पश्चिम बंगाल के सभी भूमिधारक किसान और दर्ज बोरगादार (18 से 60 वर्ष)।'
    ],
    eligibilityMr: [
      'पश्चिम बंगालमधील सर्व शेतकरी व वर्गदार.'
    ],
    benefitsEn: [
      '₹10,000 per year for 1 acre or more land in two installments.',
      'Pro-rata basis assistance (minimum ₹4,000/yr) for land less than 1 acre.',
      '₹2,000,000 death benefit paid to nominee in case of farmer death.'
    ],
    benefitsHi: [
      '1 एकड़ या अधिक भूमि के लिए ₹10,000 प्रति वर्ष दो किस्तों में।',
      'किसान की मृत्यु पर नामांकित व्यक्ति को ₹2 लाख की बीमा सहायता।'
    ],
    benefitsMr: [
      'वार्षिक ₹१०,००० आर्थिक मदत व ₹२ लाख विमा.'
    ],
    applicationProcessEn: [
      'Submit physical application form at Duare Sarkar camps or Block Development Office (BDO).',
      'Check status on matirkatha.gov.in.'
    ],
    applicationProcessHi: [
      'द्वारे सरकार शिविर या बीडीओ कार्यालय में आवेदन जमा करें।'
    ],
    applicationProcessMr: [
      'दुआरे सरकार कॅम्प किंवा BDO कार्यालयात अर्ज जमा करा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Voter Card',
      'RoR / Land Khatian Copy',
      'Bank Account Passbook'
    ],
    officialWebsiteUrl: 'https://matirkatha.gov.in',
    lastUpdated: '2026-08-14',
    sourceAttribution: 'Department of Agriculture, Govt. of West Bengal (Matir Katha)'
  },

  // 11. Kisan Credit Card (KCC)
  {
    id: 'kisan-credit-card',
    schemeNameEn: 'Kisan Credit Card (KCC) & Interest Subvention',
    schemeNameHi: 'किसान क्रेडिट कार्ड (केसीसी) एवं ब्याज छूट योजना',
    schemeNameMr: 'किसान क्रेडिट कार्ड (केसीसी) योजना',
    departmentEn: 'Department of Agriculture & Farmers Welfare / NABARD / RBI',
    departmentHi: 'कृषि एवं किसान कल्याण विभाग / नाबार्ड / आरबीआई',
    departmentMr: 'कृषी विभाग / नाबार्ड / रिझर्व्ह बँक ऑफ इंडिया',
    schemeType: 'Central',
    state: 'All India',
    category: 'Farmer Loans/Credit',
    benefitType: 'Credit Facility',
    shortDescEn: 'Concessional short-term crop loans up to ₹3 Lakh at an effective low interest rate of only 4% per annum with prompt repayment incentive.',
    shortDescHi: 'समय पर भुगतान प्रोत्साहन के साथ केवल 4% प्रति वर्ष की प्रभावी कम ब्याज दर पर ₹3 लाख तक का रियायती अल्पकालिक फसल ऋण।',
    shortDescMr: 'वेळेवर परतफेड करणाऱ्या शेतकऱ्यांना अवघ्या ४% सवलतीच्या व्याजदराने ₹३ लाखांपर्यंतचे अल्पमुदतीचे पीक कर्ज.',
    eligibilityEn: [
      'All farmers - individuals/joint borrowers, tenant farmers, sharecroppers, self-help groups (SHGs).',
      'Includes farmers involved in Animal Husbandry, Poultry, and Fisheries.'
    ],
    eligibilityHi: [
      'सभी किसान - व्यक्तिगत/संयुक्त उधारकर्ता, पट्टेदार किसान, बटाईदार, स्वयं सहायता समूह (एसएचजी)।',
      'पशुपालन, मुर्गी पालन और मत्स्य पालन में लगे किसान भी शामिल।'
    ],
    eligibilityMr: [
      'सर्व शेतकरी, कुळ शेतकरी, पशुपालक व मच्छीमार.'
    ],
    benefitsEn: [
      'Base interest rate 7% - 2% Central Interest Subvention - 3% Prompt Repayment Incentive = 4% Effective Interest.',
      'Collateral-free loan limit up to ₹1.60 Lakh.',
      'Flexible revolving credit facility for 5 years.'
    ],
    benefitsHi: [
      'समय पर पुनर्भुगतान करने पर प्रभावी ब्याज दर केवल 4%।',
      '₹1.60 लाख तक के ऋण के लिए किसी गारंटी (कोलैटरल) की आवश्यकता नहीं।',
      '5 साल के लिए क्रेडिट कार्ड सुविधा।'
    ],
    benefitsMr: [
      'वेळेवर भरल्यास अवघा ४% व्याजदर.',
      '₹१.६० लाखापर्यंत तारणमुक्त कर्ज.'
    ],
    applicationProcessEn: [
      'Download KCC application form from pmkisan.gov.in or any commercial bank website.',
      'Fill crop details, land survey number, and submit to nearest Commercial Bank / RRB / Cooperative Bank.',
      'Bank issues KCC card within 14 working days.'
    ],
    applicationProcessHi: [
      'pmkisan.gov.in या बैंक वेबसाइट से केसीसी फॉर्म डाउनलोड करें।',
      'फसल विवरण भरें और नजदीकी बैंक शाखा में जमा करें।',
      '14 दिनों में केसीसी कार्ड जारी किया जाएगा।'
    ],
    applicationProcessMr: [
      'केसीसी फॉर्म भरून जवळच्या सहकारी अथवा राष्ट्रीयकृत बँकेत सादर करा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'PAN Card / Voter ID',
      'Land Records (7/12 Extract / Khasra-Khatauni)',
      'Crop Sowing Affidavit',
      'Passport Photograph'
    ],
    officialWebsiteUrl: 'https://pmkisan.gov.in/KCC.aspx',
    lastUpdated: '2026-08-22',
    sourceAttribution: 'Reserve Bank of India & NABARD (myScheme.gov.in)'
  },

  // 12. Paramparagat Krishi Vikas Yojana (PKVY) - Organic Farming
  {
    id: 'pkvy-organic-farming',
    schemeNameEn: 'Paramparagat Krishi Vikas Yojana (PKVY) - Organic Farming',
    schemeNameHi: 'परंपरागत कृषि विकास योजना (पीकेवीवाई) - जैविक खेती',
    schemeNameMr: 'परंपरागत कृषी विकास योजना (पीकेवीवाई) - सेंद्रिय शेती',
    departmentEn: 'Department of Agriculture & Farmers Welfare, Govt. of India',
    departmentHi: 'कृषि एवं किसान कल्याण विभाग, भारत सरकार',
    departmentMr: 'कृषी व शेतकरी कल्याण विभाग, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Organic Farming',
    benefitType: 'Input Support',
    shortDescEn: 'Financial assistance of ₹50,000 per hectare over 3 years for organic inputs, PGS organic certification, quality packaging, and direct organic market link creation.',
    shortDescHi: 'जैविक इनपुट, पीजीएस जैविक प्रमाणीकरण, गुणवत्ता पैकेजिंग और प्रत्यक्ष जैविक बाजार लिंक के लिए 3 वर्षों में ₹50,000 प्रति हेक्टेयर की सहायता।',
    shortDescMr: 'सेंद्रिय शेती, पीजीएस सेंद्रिय प्रमाणपत्र, पॅकेजिंग आणि थेट विक्रीसाठी ३ वर्षात ₹५०,००० प्रति हेक्टर आर्थिक मदत.',
    eligibilityEn: [
      'Farmers forming organic clusters of minimum 20 hectares (around 50 farmers).',
      'Individual farmers adopting certified organic farming.'
    ],
    eligibilityHi: [
      'न्यूनतम 20 हेक्टेयर (लगभग 50 किसान) के जैविक क्लस्टर बनाने वाले किसान।'
    ],
    eligibilityMr: [
      'किमान २० हेक्टरचा सेंद्रिय शेती गट (क्लस्टर) तयार करणारे शेतकरी.'
    ],
    benefitsEn: [
      '₹31,000 per ha directly transferred via DBT for organic seeds, bio-fertilizers, neem cake & vermicompost.',
      'Free PGS-India Organic Certification.',
      '₹8,800 per ha for packaging, branding, and organic fair market access.'
    ],
    benefitsHi: [
      'जैविक खाद, वर्मीकंपोस्ट व बायो-फर्टिलाइजर के लिए ₹31,000 प्रति हेक्टेयर डीबीटी।',
      'मुफ्त जैविक प्रमाणन।'
    ],
    benefitsMr: [
      'खाते डीबीटी द्वारे ₹३१,००० थेट मदत व सेंद्रिय प्रमाणपत्र.'
    ],
    applicationProcessEn: [
      'Form an organic cluster group with local Regional Council / District Agriculture Officer.',
      'Register cluster on Jaivik Kheti Portal (jaivikkheti.in).'
    ],
    applicationProcessHi: [
      'जैविक खेती पोर्टल (jaivikkheti.in) पर क्लस्टर पंजीकृत करें।'
    ],
    applicationProcessMr: [
      'jaivikkheti.in पोर्टलवर नोंदणी करा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Land Records',
      'Bank Account Passbook',
      'Group Resolution Letter'
    ],
    officialWebsiteUrl: 'https://jaivikkheti.in',
    lastUpdated: '2026-08-16',
    sourceAttribution: 'Ministry of Agriculture & Farmers Welfare (jaivikkheti.in)'
  },

  // 13. PM Matsya Sampada Yojana (PMMSY) - Fisheries
  {
    id: 'pmmsy-fisheries',
    schemeNameEn: 'Pradhan Mantri Matsya Sampada Yojana (PMMSY)',
    schemeNameHi: 'प्रधानमंत्री मत्स्य संपदा योजना (पीएमएमएसवाई)',
    schemeNameMr: 'पंतप्रधान मत्स्य संपदा योजना (पीएमएमएसवाई)',
    departmentEn: 'Department of Fisheries, Govt. of India',
    departmentHi: 'मत्स्य पालन विभाग, भारत सरकार',
    departmentMr: 'मत्स्य व्यवसाय विभाग, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Fisheries',
    benefitType: 'Subsidy',
    shortDescEn: '40% to 60% financial subsidy for fish farming, construction of new ponds, biofloc units, RAS system, refrigerated vehicles, and fish feed mills.',
    shortDescHi: 'मछली पालन, नए तालाब निर्माण, बायोफ्लोक यूनिट, आरएएस सिस्टम, रीफर्ड वाहनों और मछली चारा मिलों के लिए 40% से 60% की वित्तीय सब्सिडी।',
    shortDescMr: 'मत्स्यपालन, नवीन तलाव निर्मिती, बायोफ्लॉक, आरएएस यंत्रणा व मत्स्य खाद्य निर्मितीसाठी ४०% ते ६०% अनुदान.',
    eligibilityEn: [
      'Fishers, Fish Farmers, Fish Workers, Fish Vendors, SC/ST/Women entrepreneurs, SHGs, Fisheries Cooperatives.'
    ],
    eligibilityHi: [
      'मछुआरे, मछली पालक, अनुसूचित जाति/जनजाति/महिला उद्यमी, स्वयं सहायता समूह।'
    ],
    eligibilityMr: [
      'मच्छीमार, मत्स्यपालक, महिला व अनुसूचित जाती/जमाती उद्योजक.'
    ],
    benefitsEn: [
      '60% subsidy for SC, ST, and Women beneficiaries.',
      '40% subsidy for General category beneficiaries.',
      'Projects covered from ₹50,000 up to ₹50 Lakh infrastructure.'
    ],
    benefitsHi: [
      'महिला, एससी और एसटी लाभार्थियों के लिए 60% सब्सिडी।',
      'सामान्य श्रेणी के लिए 40% सब्सिडी।'
    ],
    benefitsMr: [
      'महिला व एससी/एसटी साठी ६०% व इतरांसाठी ४०% अनुदान.'
    ],
    applicationProcessEn: [
      'Apply online on pmmsy.dof.gov.in or contact District Fisheries Development Officer (DFDO).',
      'Submit Detailed Project Report (DPR) and land/water body lease documents.'
    ],
    applicationProcessHi: [
      'pmmsy.dof.gov.in पर ऑनलाइन आवेदन करें।'
    ],
    applicationProcessMr: [
      'pmmsy.dof.gov.in वर ऑनलाईन अर्ज सादर करा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Land / Water Body Ownership or Lease Agreement',
      'Detailed Project Report (DPR)',
      'Bank Account Passbook'
    ],
    officialWebsiteUrl: 'https://pmmsy.dof.gov.in',
    lastUpdated: '2026-08-19',
    sourceAttribution: 'Department of Fisheries, Govt. of India (pmmsy.dof.gov.in)'
  },

  // 14. National Livestock Mission (NLM) - Dairy & Livestock
  {
    id: 'nlm-livestock',
    schemeNameEn: 'National Livestock Mission (NLM) - Goat, Sheep, Poultry & Dairy',
    schemeNameHi: 'राष्ट्रीय पशुधन मिशन (एनएलएम) - बकरी, भेड़, मुर्गी एवं डेयरी',
    schemeNameMr: 'राष्ट्रीय पशुधन अभियान (एनएलएम) - शेळी, मेंढी, कुक्कुटपालन व दुग्धव्यवसाय',
    departmentEn: 'Department of Animal Husbandry & Dairying, Govt. of India',
    departmentHi: 'पशुपालन और डेयरी विभाग, भारत सरकार',
    departmentMr: 'पशुसंवर्धन व दुग्धव्यवसाय विभाग, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Dairy & Livestock',
    benefitType: 'Subsidy',
    shortDescEn: '50% capital subsidy up to ₹50 Lakh for establishing goat/sheep breeding farms, commercial poultry units, piggery farms, and silage/fodder processing units.',
    shortDescHi: 'बकरी/भेड़ प्रजनन फार्म, व्यावसायिक पोल्ट्री यूनिट, सूअर पालन फार्म और हरा चारा/साइलेज प्रोसेसिंग प्लांट लगाने पर 50% कैपिटल सब्सिडी (अधिकतम ₹50 लाख)।',
    shortDescMr: 'शेळी-मेंढी पैदास केंद्र, पोल्ट्री फॉर्म, व चारा प्रक्रिया केंद्रासाठी ५०% पर्यंत (जास्तीत जास्त ₹५० लाख) कॅपिटल सबसिडी.',
    eligibilityEn: [
      'Individual Farmers, Entrepreneurs, FPOs, SHGs, Section 8 companies, Cooperatives.'
    ],
    eligibilityHi: [
      'व्यक्तिगत किसान, उद्यमी, एफपीओ, स्वयं सहायता समूह, सहकारी समितियां।'
    ],
    eligibilityMr: [
      'वैयक्तिक शेतकरी, एफपीओ, बचत गट व पशुपालक.'
    ],
    benefitsEn: [
      '50% capital subsidy directly released in 2 installments.',
      'Goat/Sheep breeding farm (100 females + 5 males): subsidy up to ₹10 Lakh.',
      'Poultry parent farm (1000 birds): subsidy up to ₹25 Lakh.',
      'Feed & Fodder manufacturing unit: subsidy up to ₹50 Lakh.'
    ],
    benefitsHi: [
      '50% की सीधी कैपिटल सब्सिडी।',
      'बकरी/भेड़ फार्म के लिए ₹10 लाख तक सब्सिडी।',
      'पोल्ट्री यूनिट के लिए ₹25 लाख तक सब्सिडी।'
    ],
    benefitsMr: [
      '५०% थेट कॅपिटल सबसिडी. शेळीपालनासाठी ₹१० लाख, पोल्ट्रीसाठी ₹२५ लाख अनुदान.'
    ],
    applicationProcessEn: [
      'Apply online on the NLM Portal (nlm.udyamimitra.in).',
      'Upload Detailed Project Report (DPR), land lease/ownership, bank loan sanction letter.',
      'State Level Executive Committee approves and releases subsidy via SIDBI.'
    ],
    applicationProcessHi: [
      'NLM पोर्टल (nlm.udyamimitra.in) पर ऑनलाइन आवेदन करें।'
    ],
    applicationProcessMr: [
      'nlm.udyamimitra.in पोर्टलवर प्रकल्प अहवालासह ऑनलाईन अर्ज करा.'
    ],
    requiredDocuments: [
      'Aadhaar Card & PAN Card',
      'Detailed Project Report (DPR) signed by Chartered Accountant / Vet Doctor',
      'Land Ownership / Lease Document (min 10-15 years)',
      'Bank Loan In-principle Sanction Letter',
      'Training Certificate in Livestock Management'
    ],
    officialWebsiteUrl: 'https://nlm.udyamimitra.in',
    lastUpdated: '2026-08-21',
    sourceAttribution: 'Department of Animal Husbandry & Dairying (nlm.udyamimitra.in)'
  },

  // 15. e-NAM (National Agriculture Market)
  {
    id: 'enam-market-access',
    schemeNameEn: 'e-NAM (National Agriculture Market) Platform',
    schemeNameHi: 'राष्ट्रीय कृषि बाजार (ई-नाम) पोर्टल',
    schemeNameMr: 'राष्ट्रीय कृषी बाजार (ई-नाम) व्यासपीठ',
    departmentEn: 'SFAC / Ministry of Agriculture & Farmers Welfare, Govt. of India',
    departmentHi: 'एसएफएसी / कृषि एवं किसान कल्याण मंत्रालय, भारत सरकार',
    departmentMr: 'कृषी व शेतकरी कल्याण मंत्रालय, भारत सरकार',
    schemeType: 'Central',
    state: 'All India',
    category: 'Market Access',
    benefitType: 'Input Support',
    shortDescEn: 'Pan-India electronic trading portal integrating 1,400+ APMC mandis allowing farmers to sell crops online across India to get transparent competitive bidding and highest price.',
    shortDescHi: '1,400+ एपीएमसी मंडियों को जोड़ने वाला अखिल भारतीय इलेक्ट्रॉनिक ट्रेडिंग पोर्टल जो किसानों को उच्चतम मूल्य प्राप्त करने के लिए ऑनलाइन पूरे भारत में अपनी उपज बेचने की अनुमति देता है।',
    shortDescMr: '१,४०० हून अधिक APMC बाजारांना जोडणारे ऑनलाईन व्यासपीठ, जिथे शेतकरी संपूर्ण भारतातील व्यापाऱ्यांना थेट माल विकून उत्तम भाव मिळवू शकतात.',
    eligibilityEn: [
      'All farmers producing agricultural produce in India.',
      'Zero registration charge for farmers.'
    ],
    eligibilityHi: [
      'भारत में कृषि उपज पैदा करने वाले सभी किसान। निशुल्क पंजीकरण।'
    ],
    eligibilityMr: [
      'भारतातील सर्व शेतकरी. मोफत ऑनलाईन नोंदणी.'
    ],
    benefitsEn: [
      'Transparent online bidding across 1,400+ wholesale mandis.',
      'Assaying and quality testing facility inside APMC campus.',
      'Direct payment into farmer bank account within 24 hours of bidding.',
      'Saves middleman commission and transport cost.'
    ],
    benefitsHi: [
      '1,400+ मंडियों में पारदर्शी ऑनलाइन बोली।',
      '24 घंटे के भीतर बैंक खाते में सीधा भुगतान।'
    ],
    benefitsMr: [
      'पारदर्शक ई-लिलाव व २४ तासात खात्यात पैसे जमा.'
    ],
    applicationProcessEn: [
      'Register on enam.gov.in or download e-NAM Mobile App.',
      'Select nearest e-NAM integrated APMC Mandi.',
      'Generate Gate Entry slip, test crop quality at assaying lab, and participate in online auction.'
    ],
    applicationProcessHi: [
      'enam.gov.in या e-NAM मोबाइल ऐप पर रजिस्टर करें।'
    ],
    applicationProcessMr: [
      'enam.gov.in किंवा e-NAM अॅपवर नोंदणी करा.'
    ],
    requiredDocuments: [
      'Aadhaar Card',
      'Bank Account Passbook',
      'Mobile Number'
    ],
    officialWebsiteUrl: 'https://enam.gov.in',
    lastUpdated: '2026-08-27',
    sourceAttribution: 'Small Farmers Agri-Business Consortium (SFAC) & Ministry of Agriculture'
  }
];
