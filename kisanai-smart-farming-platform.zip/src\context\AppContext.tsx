import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { 
  LanguageCode, 
  FarmerProfile, 
  CropItem, 
  ActiveModalType, 
  AppMode, 
  DiseaseDiagnosis, 
  YieldPredictionData, 
  ProfitPredictionData,
  GpsLocationState 
} from '../types';
import { INITIAL_CROPS, UI_TRANSLATIONS, SAMPLE_DIAGNOSES } from '../data/mockAgriData';
import { 
  auth, 
  signInWithGoogle, 
  signInFarmerSession, 
  logOutUser,
  getFarmerProfileFromDb,
  saveFarmerProfileToDb,
  getFarmerCropsFromDb,
  saveCropToDb,
  deleteCropFromDb,
  saveDiagnosisToDb,
  getFarmerDiagnosesFromDb,
  savePredictionToDb,
  getFarmerPredictionsFromDb
} from '../lib/firebase';

interface AppContextType {
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  appMode: AppMode;
  setAppMode: (mode: AppMode) => void;
  activeTab: 'home' | 'mycrop' | 'diagnose' | 'askai' | 'profile' | 'features' | 'about' | 'support';
  setActiveTab: (tab: 'home' | 'mycrop' | 'diagnose' | 'askai' | 'profile' | 'features' | 'about' | 'support') => void;
  activeModal: ActiveModalType;
  openModal: (modal: ActiveModalType) => void;
  closeModal: () => void;
  farmer: FarmerProfile;
  updateFarmer: (updated: Partial<FarmerProfile>) => Promise<void>;
  crops: CropItem[];
  addCrop: (crop: Omit<CropItem, 'id'>) => Promise<void>;
  deleteCrop: (cropId: string) => Promise<void>;
  selectedCrop: CropItem | null;
  setSelectedCrop: (crop: CropItem | null) => void;
  t: (key: string) => string;
  isLoggedIn: boolean;
  setIsLoggedIn: (logged: boolean) => void;
  isAuthChecking: boolean;
  firebaseUser: User | null;
  isDbLoading: boolean;
  diagnosesHistory: DiseaseDiagnosis[];
  predictionsHistory: any[];
  saveDiagnosisRecord: (diagnosis: DiseaseDiagnosis) => Promise<string>;
  savePredictionRecord: (typeOrRecord: any, data?: any) => Promise<string>;
  completeFarmerRegistration: (data: {
    name: string;
    phone: string;
    location: string;
    mainCrop: string;
    landAcres?: number;
    language?: LanguageCode;
  }) => Promise<void>;
  loginFarmerWithMobile: (phone: string) => Promise<void>;
  sendMobileOtp: (phone: string) => Promise<{ success: boolean; message: string; otpCode?: string; smsText?: string; error?: string }>;
  verifyMobileOtp: (phone: string, otp: string) => Promise<{ success: boolean; message: string; error?: string }>;
  loginWithCustomGoogleProfile: (email: string, fullName: string, avatarUrl?: string) => Promise<void>;
  loginWithGoogle: () => Promise<{ success: boolean; isPopupBlocked?: boolean; error?: string }>;
  logoutFarmer: () => Promise<void>;
  completeOnboarding: (data: any) => void;
  
  // Real-time GPS Location Tracking & Google Maps Integration
  currentGps: GpsLocationState | null;
  isGpsTracking: boolean;
  gpsError: string | null;
  startGpsTracking: () => void;
  stopGpsTracking: () => void;
  refreshGpsLocation: () => Promise<GpsLocationState | null>;
  openGoogleMaps: (mode?: 'view' | 'directions' | 'satellite') => void;
  saveFarmGpsCoordinates: (lat: number, lng: number, address?: string) => Promise<void>;

  // Audio & Text-to-Speech Engine
  speakText: (text: string, lang?: LanguageCode, onEnd?: () => void) => void;
  stopSpeaking: () => void;
  pauseSpeaking: () => void;
  resumeSpeaking: () => void;
  isSpeaking: boolean;
  isPaused: boolean;
  speechRate: number;
  setSpeechRate: (rate: number) => void;
  restartOnboarding: () => void;
}

const EMPTY_FARMER_PROFILE: FarmerProfile = {
  id: '',
  fullName: '',
  name: '',
  phone: '',
  kisanId: '',
  language: 'mr',
  state: 'Maharashtra',
  district: 'नाशिक',
  village: 'पिंपळगाव बसवंत',
  location: 'पिंपळगाव, नाशिक',
  landArea: 3.5,
  mainCrop: 'कांदा (Onion)',
  totalLandAcres: 3.5,
  soilType: 'Medium Black Clayey Loam',
  irrigationSource: 'Drip Irrigation',
  registeredCropsCount: 1,
  soilHealthStatus: 'Optimal',
  activeAlertsCount: 0,
  isRegistered: false,
  latitude: 20.1662,
  longitude: 73.9856,
  farmGpsAddress: 'Pimpalgaon Baswant, Niphad, Nashik, Maharashtra - 422209',
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [language, setLanguage] = useState<LanguageCode>('mr'); // Default to Marathi for Indian farmers
  const [appMode, setAppMode] = useState<AppMode>('farmer'); // Default to Farmer Mode
  const [activeTab, setActiveTab] = useState<'home' | 'mycrop' | 'diagnose' | 'askai' | 'profile' | 'features' | 'about' | 'support'>('home');
  const [activeModal, setActiveModal] = useState<ActiveModalType>(null);
  
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [isDbLoading, setIsDbLoading] = useState<boolean>(false);
  const [isAuthChecking, setIsAuthChecking] = useState<boolean>(true);
  const [diagnosesHistory, setDiagnosesHistory] = useState<DiseaseDiagnosis[]>([]);
  const [predictionsHistory, setPredictionsHistory] = useState<any[]>([]);

  const [farmer, setFarmer] = useState<FarmerProfile>(EMPTY_FARMER_PROFILE);
  const [crops, setCrops] = useState<CropItem[]>([]);
  const [selectedCrop, setSelectedCrop] = useState<CropItem | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);

  // GPS Location Tracking State
  const [currentGps, setCurrentGps] = useState<GpsLocationState | null>({
    lat: 20.1662,
    lng: 73.9856,
    accuracy: 8,
    altitude: 584,
    speed: 0,
    heading: 45,
    timestamp: Date.now(),
    village: 'पिंपळगाव बसवंत',
    taluka: 'निफाड',
    district: 'नाशिक',
    state: 'Maharashtra',
    postcode: '422209',
    formattedAddress: 'Pimpalgaon Baswant, Niphad, Nashik, Maharashtra 422209',
    isLiveTracking: false,
  });
  const [isGpsTracking, setIsGpsTracking] = useState<boolean>(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const watchIdRef = useRef<number | null>(null);

  // Synchronize with Firebase Auth & Cloud Firestore + LocalStorage Persistent Session
  useEffect(() => {
    // 1. Instant hydration from LocalStorage (Farmers NEVER have to re-login repeatedly!)
    if (typeof window !== 'undefined') {
      const savedProfileStr = localStorage.getItem('kisanai_farmer_profile');
      const isReg = localStorage.getItem('kisanai_farmer_registered') === 'true';
      if (savedProfileStr && isReg) {
        try {
          const parsed = JSON.parse(savedProfileStr);
          if (parsed && (parsed.fullName || parsed.name)) {
            setFarmer(parsed);
            setIsLoggedIn(true);
            if (parsed.language) setLanguage(parsed.language);
          }
        } catch (e) {
          console.warn('LocalStorage profile hydration error:', e);
        }
      }
    }

    // 2. Real-time Firebase Auth listener
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user) {
        setIsDbLoading(true);
        try {
          // Fetch farmer profile from Firestore using Firebase Auth UID
          const profile = await getFarmerProfileFromDb(user.uid);
          const realName = user.displayName || profile?.fullName || profile?.name || (user.email ? user.email.split('@')[0] : 'शेतकरी मित्र');

          if (profile) {
            const enrichedProfile: FarmerProfile = {
              ...profile,
              id: user.uid,
              userId: user.uid,
              fullName: profile.fullName || realName,
              name: profile.name || realName,
              email: user.email || profile.email || '',
              avatarUrl: user.photoURL || profile.avatarUrl,
              isRegistered: true,
            };
            setFarmer(enrichedProfile);
            if (enrichedProfile.language) setLanguage(enrichedProfile.language);
            setIsLoggedIn(true);
            if (typeof window !== 'undefined') {
              localStorage.setItem('kisanai_farmer_registered', 'true');
              localStorage.setItem('kisanai_farmer_profile', JSON.stringify(enrichedProfile));
            }
          } else {
            // New authenticated user, persist profile to Firestore with user's real auth details
            const newProfile: FarmerProfile = {
              ...EMPTY_FARMER_PROFILE,
              id: user.uid,
              userId: user.uid,
              fullName: realName,
              name: realName,
              phone: user.phoneNumber || '',
              email: user.email || '',
              avatarUrl: user.photoURL || undefined,
              location: 'महाराष्ट्र',
              landArea: 3.5,
              mainCrop: 'कापूस (Cotton)',
              totalLandAcres: 3.5,
              isRegistered: true,
              language: language || 'mr',
            };
            setFarmer(newProfile);
            await saveFarmerProfileToDb(user.uid, newProfile);
            setIsLoggedIn(true);
            if (typeof window !== 'undefined') {
              localStorage.setItem('kisanai_farmer_registered', 'true');
              localStorage.setItem('kisanai_farmer_profile', JSON.stringify(newProfile));
            }
          }

          // Fetch crops from Firestore for this user
          const dbCrops = await getFarmerCropsFromDb(user.uid);
          if (dbCrops && dbCrops.length > 0) {
            setCrops(dbCrops);
            setSelectedCrop(dbCrops[0]);
          }

          // Fetch diagnoses and predictions history from Firestore
          const diags = await getFarmerDiagnosesFromDb(user.uid);
          setDiagnosesHistory(diags || []);

          const preds = await getFarmerPredictionsFromDb(user.uid);
          setPredictionsHistory(preds || []);
        } catch (err) {
          console.error('Error hydrating state from Firestore:', err);
        } finally {
          setIsDbLoading(false);
          setIsAuthChecking(false);
        }
      } else {
        // User unauthenticated in Firebase - check if local profile exists
        if (typeof window !== 'undefined') {
          const localStr = localStorage.getItem('kisanai_farmer_profile');
          if (!localStr) {
            setFirebaseUser(null);
            setIsLoggedIn(false);
          }
        }
        setIsDbLoading(false);
        setIsAuthChecking(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Speech Synthesis states
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const openModal = (modal: ActiveModalType) => {
    setActiveModal(modal);
  };

  const closeModal = () => {
    setActiveModal(null);
    stopSpeaking();
  };

  const updateFarmer = async (updated: Partial<FarmerProfile>) => {
    const next = { ...farmer, ...updated };
    setFarmer(next);
    if (typeof window !== 'undefined') {
      localStorage.setItem('kisanai_farmer_profile', JSON.stringify(next));
    }
    const currentUid = firebaseUser?.uid || auth.currentUser?.uid;
    if (currentUid) {
      try {
        await saveFarmerProfileToDb(currentUid, next);
      } catch (e) {
        console.warn('Failed to update farmer profile in Firestore:', e);
      }
    }
  };

  const addCrop = async (newCropData: Omit<CropItem, 'id'>) => {
    const newCropId = `crop_${Date.now()}`;
    const newCrop: CropItem = {
      ...newCropData,
      id: newCropId,
    };
    setCrops((prev) => [newCrop, ...prev]);
    setSelectedCrop(newCrop);

    const updatedFarmer = {
      ...farmer,
      registeredCropsCount: (farmer.registeredCropsCount || 0) + 1,
    };
    setFarmer(updatedFarmer);

    // Persist to Cloud Firestore
    let uid = firebaseUser?.uid || auth.currentUser?.uid;
    if (!uid) {
      try {
        const anonUser = await signInFarmerSession();
        uid = anonUser.uid;
      } catch (err) {
        console.warn('Auth fallback for addCrop:', err);
      }
    }

    if (uid) {
      try {
        await saveCropToDb(uid, newCrop);
        await saveFarmerProfileToDb(uid, updatedFarmer);
      } catch (e) {
        console.error('Failed to save crop to Firestore:', e);
      }
    }
  };

  const deleteCrop = async (cropId: string) => {
    setCrops((prev) => prev.filter((c) => c.id !== cropId));
    if (selectedCrop?.id === cropId) {
      const remaining = crops.filter((c) => c.id !== cropId);
      setSelectedCrop(remaining.length > 0 ? remaining[0] : null);
    }

    const updatedFarmer = {
      ...farmer,
      registeredCropsCount: Math.max(0, (farmer.registeredCropsCount || 1) - 1),
    };
    setFarmer(updatedFarmer);

    const uid = firebaseUser?.uid || auth.currentUser?.uid;
    if (uid) {
      try {
        await deleteCropFromDb(uid, cropId);
        await saveFarmerProfileToDb(uid, updatedFarmer);
      } catch (e) {
        console.error('Failed to delete crop from Firestore:', e);
      }
    }
  };

  const saveDiagnosisRecord = async (diagnosis: DiseaseDiagnosis): Promise<string> => {
    const diagId = diagnosis.id || `diag_${Date.now()}`;
    const fullDiag: DiseaseDiagnosis = { ...diagnosis, id: diagId };
    setDiagnosesHistory((prev) => [fullDiag, ...prev]);

    let uid = firebaseUser?.uid || auth.currentUser?.uid;
    if (!uid) {
      try {
        const u = await signInFarmerSession();
        uid = u.uid;
      } catch (err) {
        console.warn('Diagnosis auth fallback:', err);
      }
    }

    if (uid) {
      try {
        await saveDiagnosisToDb(uid, fullDiag);
      } catch (e) {
        console.error('Failed to persist diagnosis to Firestore:', e);
      }
    }
    return diagId;
  };

  const savePredictionRecord = async (
    typeOrRecord: any, 
    maybeData?: any
  ): Promise<string> => {
    const isObj = typeof typeOrRecord === 'object' && typeOrRecord !== null;
    const type = isObj ? (typeOrRecord.type || 'prediction') : typeOrRecord;
    const data = isObj ? typeOrRecord : maybeData;
    const id = (isObj && typeOrRecord.id) ? typeOrRecord.id : `pred_${type}_${Date.now()}`;
    const record = { ...data, id, type, createdAt: new Date().toISOString() };
    setPredictionsHistory((prev) => [record, ...prev]);

    let uid = firebaseUser?.uid || auth.currentUser?.uid;
    if (!uid) {
      try {
        const u = await signInFarmerSession();
        uid = u.uid;
      } catch (err) {
        console.warn('Prediction auth fallback:', err);
      }
    }

    if (uid) {
      try {
        return await savePredictionToDb(uid, typeOrRecord, maybeData);
      } catch (e) {
        console.error('Failed to persist prediction to Firestore:', e);
      }
    }
    return record.id;
  };

  const completeFarmerRegistration = async (data: {
    name: string;
    phone: string;
    location: string;
    mainCrop: string;
    landAcres?: number;
    language?: LanguageCode;
  }) => {
    const chosenLang = data.language || language;

    // 1. Authenticate with Firebase
    let user = auth.currentUser;
    if (!user) {
      try {
        user = await signInFarmerSession();
      } catch (err) {
        console.warn('Farmer auto-auth error:', err);
      }
    }

    const updatedProfile: FarmerProfile = {
      ...farmer,
      id: user?.uid || farmer.id,
      fullName: data.name,
      name: data.name,
      phone: data.phone.startsWith('+91') ? data.phone : `+91 ${data.phone}`,
      village: data.location.split(',')[0]?.trim() || data.location,
      district: data.location.split(',')[1]?.trim() || farmer.district || 'नाशिक',
      location: data.location,
      totalLandAcres: data.landAcres || 3.5,
      landArea: data.landAcres || 3.5,
      mainCrop: data.mainCrop,
      language: chosenLang,
      isRegistered: true,
    };

    setFarmer(updatedProfile);
    if (data.language) {
      setLanguage(data.language);
    }

    // Create main crop record
    let newCrop: CropItem | null = null;
    if (data.mainCrop) {
      newCrop = {
        id: `crop_main_${Date.now()}`,
        name: data.mainCrop,
        variety: 'High-Yield Hybrid',
        category: 'Cash Crop',
        sowingDate: '15 Nov 2025',
        harvestDate: '25 Mar 2026',
        plotSizeAcres: data.landAcres || 3.5,
        stage: 'Vegetative',
        progressPercentage: 60,
        healthStatus: 'Healthy',
        soilMoisture: 45,
        temperature: 27,
        nextAction: chosenLang === 'hi' 
          ? 'संतुलित सिंचाई और आवश्यक पोषण प्रबंधन करें' 
          : chosenLang === 'mr' 
          ? 'संतुलित खत व्यवस्थापन आणि हलके पाणी द्यावे' 
          : 'Apply recommended nutrition and schedule light drip irrigation',
        expectedYieldQuintals: 28,
        estimatedRevenue: 135000,
        image: 'https://images.unsplash.com/photo-1594488518063-9571ff215c2d?auto=format&fit=crop&w=400&q=80',
      };
      setCrops([newCrop, ...crops.filter((c) => c.id !== newCrop!.id)]);
      setSelectedCrop(newCrop);
    }

    setIsLoggedIn(true);
    setAppMode('farmer');
    setActiveTab('home');

    if (typeof window !== 'undefined') {
      localStorage.setItem('kisanai_farmer_registered', 'true');
      localStorage.setItem('kisanai_farmer_profile', JSON.stringify(updatedProfile));
    }

    // Persist profile & crop to Firestore
    if (user?.uid) {
      try {
        await saveFarmerProfileToDb(user.uid, updatedProfile);
        if (newCrop) {
          await saveCropToDb(user.uid, newCrop);
        }
      } catch (err) {
        console.error('Failed to sync registered farmer to Firestore:', err);
      }
    }
  };

  const loginFarmerWithMobile = async (phone: string) => {
    setIsDbLoading(true);
    try {
      let user = auth.currentUser;
      if (!user) {
        user = await signInFarmerSession();
      }
      if (user) {
        // 1. Try to fetch existing profile from server DB
        let loadedProfile: FarmerProfile | null = null;
        try {
          const dbRes = await fetch(`/api/user/profile?phone=${encodeURIComponent(phone)}`);
          const dbData = await dbRes.json();
          if (dbData.success && dbData.data) {
            loadedProfile = dbData.data;
          }
        } catch (e) {
          console.warn('Server profile fetch error:', e);
        }

        // 2. Fallback to Firestore
        if (!loadedProfile) {
          loadedProfile = await getFarmerProfileFromDb(user.uid);
        }

        if (loadedProfile) {
          setFarmer(loadedProfile);
          if (loadedProfile.language) setLanguage(loadedProfile.language);
        } else {
          // Initialize new profile with entered mobile
          const newProfile: FarmerProfile = {
            ...farmer,
            id: user.uid,
            phone: phone.startsWith('+91') ? phone : `+91 ${phone}`,
            isRegistered: true,
          };
          await saveFarmerProfileToDb(user.uid, newProfile);
          setFarmer(newProfile);

          // Save to backend DB endpoint
          fetch('/api/user/profile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone, profile: newProfile }),
          }).catch(() => {});
        }

        // Hydrate real crops, diagnoses, and predictions
        const dbCrops = await getFarmerCropsFromDb(user.uid);
        if (dbCrops.length > 0) {
          setCrops(dbCrops);
          setSelectedCrop(dbCrops[0]);
        }
        const diags = await getFarmerDiagnosesFromDb(user.uid);
        setDiagnosesHistory(diags || []);
        const preds = await getFarmerPredictionsFromDb(user.uid);
        setPredictionsHistory(preds || []);
      }
    } catch (err) {
      console.error('Mobile login error with Firebase:', err);
    } finally {
      setIsDbLoading(false);
      setIsLoggedIn(true);
      setAppMode('farmer');
      setActiveTab('home');
      if (typeof window !== 'undefined') {
        localStorage.setItem('kisanai_farmer_registered', 'true');
        localStorage.setItem('kisanai_farmer_profile', JSON.stringify(farmer));
      }
    }
  };

  const sendMobileOtp = async (phone: string): Promise<{ success: boolean; message: string; otpCode?: string; smsText?: string; error?: string }> => {
    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });
      const data = await res.json();
      if (data.success) {
        return {
          success: true,
          message: data.message,
          otpCode: data.otpCode,
          smsText: data.smsText,
        };
      }
      return { success: false, message: data.error || 'ओटीपी पाठवण्यात अपयश आले.' };
    } catch (err: any) {
      console.error('sendMobileOtp API error:', err);
      return { success: false, message: 'सर्व्हरशी संपर्क होऊ शकला नाही (Network error).' };
    }
  };

  const verifyMobileOtp = async (phone: string, otp: string): Promise<{ success: boolean; message: string; userProfile?: any; error?: string }> => {
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, otp }),
      });
      const data = await res.json();
      if (data.success) {
        if (data.userProfile) {
          setFarmer(data.userProfile);
          if (typeof window !== 'undefined') {
            localStorage.setItem('kisanai_farmer_profile', JSON.stringify(data.userProfile));
          }
        }
        return { success: true, message: data.message, userProfile: data.userProfile };
      }
      return { success: false, message: data.error || 'चुकीचा ओटीपी कोड!' };
    } catch (err: any) {
      console.error('verifyMobileOtp API error:', err);
      return { success: false, message: 'ओटीपी पडताळणीमध्ये नेटवर्क एरर आला.' };
    }
  };

  const loginWithCustomGoogleProfile = async (email: string, fullName: string, avatarUrl?: string) => {
    setIsDbLoading(true);
    let uid = firebaseUser?.uid || auth.currentUser?.uid;
    if (!uid) {
      try {
        const u = await signInFarmerSession();
        uid = u.uid;
      } catch (e) {
        uid = `google_${Date.now()}`;
      }
    }

    const cleanEmail = email.trim() || 'farmer.google@gmail.com';
    const cleanName = fullName.trim() || cleanEmail.split('@')[0] || 'Google Farmer';
    const avatar = avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(cleanName)}&background=059669&color=fff&bold=true`;

    const googleProfile: FarmerProfile = {
      ...farmer,
      id: uid,
      userId: uid,
      fullName: cleanName,
      name: cleanName,
      email: cleanEmail,
      avatarUrl: avatar,
      location: farmer.location || 'नाशिक, महाराष्ट्र',
      landArea: farmer.totalLandAcres || 3.5,
      mainCrop: farmer.mainCrop || 'कापूस (Cotton)',
      totalLandAcres: farmer.totalLandAcres || 3.5,
      isRegistered: true,
      language: language || 'mr',
    };

    setFarmer(googleProfile);
    setIsLoggedIn(true);
    setAppMode('farmer');
    setActiveTab('home');
    closeModal();

    if (typeof window !== 'undefined') {
      localStorage.setItem('kisanai_farmer_registered', 'true');
      localStorage.setItem('kisanai_farmer_profile', JSON.stringify(googleProfile));
    }

    try {
      await saveFarmerProfileToDb(uid, googleProfile);
    } catch (e) {
      console.warn('Firestore profile sync notice:', e);
    } finally {
      setIsDbLoading(false);
    }
  };

  const loginWithGoogle = async (): Promise<{ success: boolean; isPopupBlocked?: boolean; userProfile?: any; error?: string }> => {
    setIsDbLoading(true);
    let user: User | null = null;
    let popupBlocked = false;

    try {
      user = await signInWithGoogle();
    } catch (err: any) {
      const isBlocked = err?.code === 'auth/popup-blocked' || err?.message?.includes('popup-blocked');
      const isClosed = err?.code === 'auth/popup-closed-by-user' || err?.code === 'auth/cancelled-popup-request';

      if (isBlocked) {
        popupBlocked = true;
        console.warn('Google Sign-in popup was blocked by browser or iframe policy.');
      } else if (!isClosed) {
        console.warn('Google Sign-in popup notice:', err?.message || err);
      }

      if (!user) {
        setIsDbLoading(false);
        return {
          success: false,
          isPopupBlocked: isBlocked,
          error: isBlocked ? 'Google Sign-in popup was blocked by browser/iframe policy.' : err?.message || 'Google login cancelled',
        };
      }
    }

    try {
      const existingProfile = await getFarmerProfileFromDb(user.uid);
      const realName = user.displayName || (user.email ? user.email.split('@')[0] : 'शेतकरी मित्र');

      let activeProfile: FarmerProfile;
      if (existingProfile) {
        activeProfile = {
          ...existingProfile,
          id: user.uid,
          userId: user.uid,
          fullName: existingProfile.fullName || realName,
          name: existingProfile.name || realName,
          avatarUrl: user.photoURL || existingProfile.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
          email: user.email || existingProfile.email || '',
          isRegistered: true,
        };
      } else {
        activeProfile = {
          ...EMPTY_FARMER_PROFILE,
          id: user.uid,
          userId: user.uid,
          fullName: realName,
          name: realName,
          phone: user.phoneNumber || '',
          email: user.email || '',
          avatarUrl: user.photoURL || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
          location: 'नाशिक, महाराष्ट्र',
          landArea: 4.5,
          mainCrop: 'कापूस (Cotton)',
          totalLandAcres: 4.5,
          isRegistered: true,
          language: language || 'mr',
        };
        await saveFarmerProfileToDb(user.uid, activeProfile);
      }

      setFarmer(activeProfile);
      if (activeProfile.language) setLanguage(activeProfile.language);

      // Hydrate real crops, diagnoses, and predictions
      const dbCrops = await getFarmerCropsFromDb(user.uid);
      if (dbCrops.length > 0) {
        setCrops(dbCrops);
        setSelectedCrop(dbCrops[0]);
      }
      const diags = await getFarmerDiagnosesFromDb(user.uid);
      setDiagnosesHistory(diags || []);
      const preds = await getFarmerPredictionsFromDb(user.uid);
      setPredictionsHistory(preds || []);

      setIsLoggedIn(true);
      setAppMode('farmer');
      setActiveTab('home');
      closeModal();
      if (typeof window !== 'undefined') {
        localStorage.setItem('kisanai_farmer_registered', 'true');
        localStorage.setItem('kisanai_farmer_profile', JSON.stringify(activeProfile));
      }
      return { success: true, isPopupBlocked: popupBlocked };
    } catch (hydrateErr: any) {
      console.warn('Profile hydration notice:', hydrateErr);
      setIsLoggedIn(true);
      setAppMode('farmer');
      setActiveTab('home');
      closeModal();
      if (typeof window !== 'undefined') {
        localStorage.setItem('kisanai_farmer_registered', 'true');
        localStorage.setItem('kisanai_farmer_profile', JSON.stringify(farmer));
      }
      return { success: true, isPopupBlocked: popupBlocked };
    } finally {
      setIsDbLoading(false);
    }
  };

  const logoutFarmer = async () => {
    try {
      await logOutUser();
    } catch (err) {
      console.error('Logout error:', err);
    }
    setFirebaseUser(null);
    setFarmer(EMPTY_FARMER_PROFILE);
    setCrops([]);
    setSelectedCrop(null);
    setDiagnosesHistory([]);
    setPredictionsHistory([]);
    setIsLoggedIn(false);
    setActiveTab('home');
    setActiveModal(null);
    if (typeof window !== 'undefined') {
      localStorage.removeItem('kisanai_farmer_registered');
      localStorage.removeItem('kisanai_farmer_profile');
    }
  };

  const completeOnboarding = (data: any) => {
    completeFarmerRegistration({
      name: data.fullName || farmer.fullName,
      phone: farmer.phone,
      location: `${data.district || 'नाशिक'}, ${data.state || 'महाराष्ट्र'}`,
      mainCrop: data.selectedCrops?.[0] || 'कापूस',
      landAcres: data.totalLandAcres || 3.5,
      language: data.language || language,
    });
    closeModal();
  };

  const restartOnboarding = () => {
    setIsLoggedIn(false);
    setActiveModal(null);
  };

  // Text-To-Speech Clean Helper
  const cleanSpeechText = (raw: string): string => {
    return raw
      .replace(/[🌱🌾🌿🍅🌽🥔🌶️🍆🥒🐛💰🌦️🧪💧🏛️📊💡☑️⚠️🚫✅🔬]/g, '')
      .replace(/\*\*/g, '')
      .replace(/\*/g, '')
      .replace(/#{1,6}\s?/g, '')
      .replace(/`{1,3}/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  };

  // Speak Text Function
  const speakText = (text: string, lang = language, onEnd?: () => void) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      console.warn('SpeechSynthesis is not supported in this browser.');
      return;
    }

    const synth = window.speechSynthesis;
    synth.cancel();

    const cleaned = cleanSpeechText(text);
    if (!cleaned) return;

    const utterance = new SpeechSynthesisUtterance(cleaned);
    utterance.rate = speechRate;
    utterance.pitch = 1.0;

    const voices = synth.getVoices();
    if (lang === 'mr') {
      const mrVoice = voices.find((v) => v.lang.includes('mr') || v.lang.includes('marathi'));
      const hiVoice = voices.find((v) => v.lang.includes('hi') || v.lang.includes('hin') || v.lang.includes('hi-IN'));
      if (mrVoice) utterance.voice = mrVoice;
      else if (hiVoice) utterance.voice = hiVoice;
      utterance.lang = mrVoice ? 'mr-IN' : 'hi-IN';
    } else if (lang === 'hi') {
      const hiVoice = voices.find((v) => v.lang.includes('hi') || v.lang.includes('hin') || v.lang.includes('hi-IN'));
      if (hiVoice) utterance.voice = hiVoice;
      utterance.lang = 'hi-IN';
    } else {
      const enVoice = voices.find((v) => v.lang.includes('en-IN') || v.lang.includes('en-US') || v.lang.includes('en-GB'));
      if (enVoice) utterance.voice = enVoice;
      utterance.lang = 'en-IN';
    }

    utterance.onstart = () => {
      setIsSpeaking(true);
      setIsPaused(false);
    };

    utterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
      if (onEnd) onEnd();
    };

    utterance.onerror = (e) => {
      console.warn('Speech synthesis utterance error:', e);
      setIsSpeaking(false);
      setIsPaused(false);
    };

    synth.speak(utterance);
  };

  const stopSpeaking = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
    setIsPaused(false);
  };

  const pauseSpeaking = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
        window.speechSynthesis.pause();
        setIsPaused(true);
      }
    }
  };

  const resumeSpeaking = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
        setIsPaused(false);
      }
    }
  };

  // Helper to reverse geocode lat/lng
  const reverseGeocodeGps = async (lat: number, lng: number) => {
    try {
      const res = await fetch(`/api/gps/reverse-geocode?lat=${lat}&lng=${lng}`);
      const data = await res.json();
      if (data.success && data.data) {
        return data.data;
      }
    } catch (e) {
      console.warn('GPS reverse geocode error:', e);
    }
    return null;
  };

  // Start live GPS tracking
  const startGpsTracking = () => {
    if (typeof window === 'undefined' || !navigator.geolocation) {
      setGpsError('Geolocation is not supported by your browser.');
      return;
    }

    setGpsError(null);
    setIsGpsTracking(true);

    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
    }

    watchIdRef.current = navigator.geolocation.watchPosition(
      async (pos) => {
        const { latitude, longitude, accuracy, altitude, speed, heading } = pos.coords;
        const addrInfo = await reverseGeocodeGps(latitude, longitude);

        const newGps: GpsLocationState = {
          lat: latitude,
          lng: longitude,
          accuracy: Math.round(accuracy),
          altitude: altitude ? Math.round(altitude) : null,
          speed: speed ? Math.round(speed * 3.6) : 0, // km/h
          heading: heading || null,
          timestamp: pos.timestamp,
          village: addrInfo?.village || farmer.village || 'शेत परिसर',
          taluka: addrInfo?.taluka || 'निफाड',
          district: addrInfo?.district || farmer.district || 'नाशिक',
          state: addrInfo?.state || farmer.state || 'Maharashtra',
          postcode: addrInfo?.postcode || '',
          formattedAddress: addrInfo?.formattedAddress || `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`,
          isLiveTracking: true,
        };

        setCurrentGps(newGps);
      },
      (err) => {
        console.warn('Geolocation error:', err.message);
        setGpsError(err.message);
        setIsGpsTracking(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 5000,
      }
    );
  };

  const stopGpsTracking = () => {
    if (watchIdRef.current !== null && typeof window !== 'undefined' && navigator.geolocation) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setIsGpsTracking(false);
    if (currentGps) {
      setCurrentGps({ ...currentGps, isLiveTracking: false });
    }
  };

  const refreshGpsLocation = async (): Promise<GpsLocationState | null> => {
    if (typeof window === 'undefined' || !navigator.geolocation) {
      setGpsError('Geolocation is not supported by your browser.');
      return currentGps;
    }

    setGpsError(null);
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          const { latitude, longitude, accuracy, altitude, speed, heading } = pos.coords;
          const addrInfo = await reverseGeocodeGps(latitude, longitude);

          const newGps: GpsLocationState = {
            lat: latitude,
            lng: longitude,
            accuracy: Math.round(accuracy),
            altitude: altitude ? Math.round(altitude) : null,
            speed: speed ? Math.round(speed * 3.6) : 0,
            heading: heading || null,
            timestamp: pos.timestamp,
            village: addrInfo?.village || farmer.village || 'शेत परिसर',
            taluka: addrInfo?.taluka || 'निफाड',
            district: addrInfo?.district || farmer.district || 'नाशिक',
            state: addrInfo?.state || farmer.state || 'Maharashtra',
            postcode: addrInfo?.postcode || '',
            formattedAddress: addrInfo?.formattedAddress || `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`,
            isLiveTracking: isGpsTracking,
          };

          setCurrentGps(newGps);
          resolve(newGps);
        },
        (err) => {
          console.warn('Single GPS position error:', err.message);
          setGpsError(err.message);
          resolve(currentGps);
        },
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 0,
        }
      );
    });
  };

  // Open direct Google Maps URL
  const openGoogleMaps = (mode: 'view' | 'directions' | 'satellite' = 'view') => {
    const lat = currentGps?.lat || farmer.latitude || 20.1662;
    const lng = currentGps?.lng || farmer.longitude || 73.9856;
    let url = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;

    if (mode === 'satellite') {
      url = `https://www.google.com/maps/@${lat},${lng},18z/data=!3m1!1e3`;
    } else if (mode === 'directions') {
      url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
    }

    if (typeof window !== 'undefined') {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  const saveFarmGpsCoordinates = async (lat: number, lng: number, address?: string) => {
    const updated = {
      ...farmer,
      latitude: lat,
      longitude: lng,
      farmGpsAddress: address || farmer.farmGpsAddress,
      location: address ? address.split(',')[0] : farmer.location,
    };
    await updateFarmer(updated);
  };

  const t = (key: string): string => {
    const currentLangDict = UI_TRANSLATIONS[language] || UI_TRANSLATIONS['mr'] || UI_TRANSLATIONS['en'];
    return currentLangDict[key] || UI_TRANSLATIONS['mr'][key] || UI_TRANSLATIONS['en'][key] || key;
  };

  return (
    <AppContext.Provider
      value={{
        theme,
        toggleTheme,
        language,
        setLanguage,
        appMode,
        setAppMode,
        activeTab,
        setActiveTab,
        activeModal,
        openModal,
        closeModal,
        farmer,
        updateFarmer,
        crops,
        addCrop,
        deleteCrop,
        selectedCrop,
        setSelectedCrop,
        t,
        isLoggedIn,
        setIsLoggedIn,
        isAuthChecking,
        firebaseUser,
        isDbLoading,
        diagnosesHistory,
        predictionsHistory,
        saveDiagnosisRecord,
        savePredictionRecord,
        completeFarmerRegistration,
        loginFarmerWithMobile,
        sendMobileOtp,
        verifyMobileOtp,
        loginWithGoogle,
        loginWithCustomGoogleProfile,
        logoutFarmer,
        completeOnboarding,
        currentGps,
        isGpsTracking,
        gpsError,
        startGpsTracking,
        stopGpsTracking,
        refreshGpsLocation,
        openGoogleMaps,
        saveFarmGpsCoordinates,
        speakText,
        stopSpeaking,
        pauseSpeaking,
        resumeSpeaking,
        isSpeaking,
        isPaused,
        speechRate,
        setSpeechRate,
        restartOnboarding,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
