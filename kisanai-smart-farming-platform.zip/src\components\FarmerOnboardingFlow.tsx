import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sprout,
  Mic,
  Volume2,
  Phone,
  User,
  MapPin,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Lock,
  ChevronRight,
  Navigation,
  Globe2,
  ShieldCheck,
  HeartHandshake,
  Landmark,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { LanguageCode } from '../types';
import { KisanLogo } from './KisanLogo';
import { INDIAN_STATES_AND_UTS } from '../data/indianStates';

interface CropOption {
  id: string;
  nameEn: string;
  nameHi: string;
  nameMr: string;
  icon: string;
  category: string;
}

const REGISTRATION_CROPS: CropOption[] = [
  { id: 'cotton', nameEn: 'Cotton', nameHi: 'कपास', nameMr: 'कापूस', icon: '🌿', category: 'Cash Crop' },
  { id: 'wheat', nameEn: 'Wheat', nameHi: 'गेहूं', nameMr: 'गहू', icon: '🌾', category: 'Cereal' },
  { id: 'rice', nameEn: 'Rice', nameHi: 'धान (चावल)', nameMr: 'भात (धान)', icon: '🌱', category: 'Cereal' },
  { id: 'soybean', nameEn: 'Soybean', nameHi: 'सोयाबीन', nameMr: 'सोयाबीन', icon: '🌱', category: 'Oilseed' },
  { id: 'maize', nameEn: 'Maize', nameHi: 'मक्का', nameMr: 'मका', icon: '🌽', category: 'Cereal' },
  { id: 'tomato', nameEn: 'Tomato', nameHi: 'टमाटर', nameMr: 'टोमॅटो', icon: '🍅', category: 'Vegetable' },
  { id: 'chilli', nameEn: 'Chilli', nameHi: 'मिर्च', nameMr: 'मिरची', icon: '🌶️', category: 'Vegetable' },
  { id: 'other', nameEn: 'Other Crop', nameHi: 'अन्य फसल', nameMr: 'इतर पीक', icon: '➕', category: 'Other' },
];

const POPULAR_LOCATIONS = [
  { mr: 'नाशिक, महाराष्ट्र', hi: 'नासिक, महाराष्ट्र', en: 'Nashik, Maharashtra' },
  { mr: 'पुणे, महाराष्ट्र', hi: 'पुणे, महाराष्ट्र', en: 'Pune, Maharashtra' },
  { mr: 'नागपूर, महाराष्ट्र', hi: 'नागपुर, महाराष्ट्र', en: 'Nagpur, Maharashtra' },
  { mr: 'इंदौर, मध्य प्रदेश', hi: 'इंदौर, मध्य प्रदेश', en: 'Indore, Madhya Pradesh' },
  { mr: 'लुधियाना, पंजाब', hi: 'लुधियाना, पंजाब', en: 'Ludhiana, Punjab' },
  { mr: 'लखनऊ, उत्तर प्रदेश', hi: 'लखनऊ, उत्तर प्रदेश', en: 'Lucknow, Uttar Pradesh' },
  { mr: 'राजकोट, गुजरात', hi: 'राजकोट, गुजरात', en: 'Rajkot, Gujarat' },
  { mr: 'जयपुर, राजस्थान', hi: 'जयपुर, राजस्थान', en: 'Jaipur, Rajasthan' },
  { mr: 'करनाल, हरियाणा', hi: 'करनाल, हरियाणा', en: 'Karnal, Haryana' },
  { mr: 'कोयंबटूर, तमिलनाडु', hi: 'कोयंबटूर, तमिलनाडु', en: 'Coimbatore, Tamil Nadu' },
];

type FlowView = 'welcome' | 'registration' | 'login' | 'googleAuth' | 'success';

export const FarmerOnboardingFlow: React.FC = () => {
  const {
    language,
    setLanguage,
    completeFarmerRegistration,
    loginFarmerWithMobile,
    sendMobileOtp,
    verifyMobileOtp,
    loginWithGoogle,
    loginWithCustomGoogleProfile,
    isDbLoading,
    speakText,
    stopSpeaking,
    isSpeaking,
  } = useApp();

  const [currentView, setCurrentView] = useState<FlowView>('welcome');
  const [step, setStep] = useState<number>(1); // Steps 1 to 4
  const [isAuthProcessing, setIsAuthProcessing] = useState<boolean>(false);

  // Google Custom Auth Form State
  const [googleEmailInput, setGoogleEmailInput] = useState<string>('');
  const [googleNameInput, setGoogleNameInput] = useState<string>('');

  // Registration Form State
  const [farmerName, setFarmerName] = useState<string>('');
  const [mobileNumber, setMobileNumber] = useState<string>('');
  const [otp, setOtp] = useState<string>('');
  const [isOtpSent, setIsOtpSent] = useState<boolean>(false);
  const [selectedState, setSelectedState] = useState<string>('Maharashtra');
  const [location, setLocation] = useState<string>('नाशिक, महाराष्ट्र');
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [selectedCropId, setSelectedCropId] = useState<string>('cotton');
  const [customCropName, setCustomCropName] = useState<string>('');
  const [landAcres, setLandAcres] = useState<number>(3.5);
  const [selectedAvatarUrl, setSelectedAvatarUrl] = useState<string>('/assets/farmer_avatar_1.jpg');

  // Login Form State
  const [loginMobile, setLoginMobile] = useState<string>('');
  const [loginOtp, setLoginOtp] = useState<string>('');
  const [isLoginOtpSent, setIsLoginOtpSent] = useState<boolean>(false);
  const [popupBlockedNotice, setPopupBlockedNotice] = useState<boolean>(false);

  // Voice Recording State
  const [isListening, setIsListening] = useState<boolean>(false);
  const [listeningTarget, setListeningTarget] = useState<'name' | 'mobile' | 'location' | 'crop' | 'loginMobile' | null>(null);
  const recognitionRef = useRef<any>(null);

  // Read Welcome Voice when on Welcome screen
  const speakWelcome = (lang = language) => {
    if (lang === 'mr') {
      speakText('नमस्कार! किसान एआय मध्ये आपले स्वागत आहे. आपल्या शेतीचा एआय साथीदार. नवीन शेतकरी नोंदणी करण्यासाठी किंवा लॉगिन करण्यासाठी बटण दाबा.', 'mr');
    } else if (lang === 'hi') {
      speakText('नमस्ते! किसान एआई में आपका स्वागत है। आपकी खेती का एआई साथी। नया किसान पंजीकरण करने या लॉगिन करने के लिए बटन दबाएं।', 'hi');
    } else {
      speakText('Welcome to KisanAI, your intelligent AI farming companion. Choose New Farmer Registration or Login to continue.', 'en');
    }
  };

  // Speak Current Step Question
  const speakStepQuestion = (stepNum: number) => {
    if (stepNum === 1) {
      const q = language === 'mr' ? 'तुमचे नाव काय आहे? कृपया तुमचे नाव सांगा किंवा लिहा.' : language === 'hi' ? 'आपका नाम क्या है? कृपया अपना नाम बताएं या लिखें।' : 'What is your name? Please speak or enter your name.';
      speakText(q, language);
    } else if (stepNum === 2) {
      const q = language === 'mr' ? 'तुमचा दहा अंकी मोबाईल नंबर टाका आणि ओ टी पी मिळवा.' : language === 'hi' ? 'अपना दस अंकों का मोबाइल नंबर दर्ज करें और ओ टी पी प्राप्त करें।' : 'Enter your 10 digit mobile number to receive verification OTP.';
      speakText(q, language);
    } else if (stepNum === 3) {
      const q = language === 'mr' ? 'तुमचे राज्य आणि गाव कोणते आहे?' : language === 'hi' ? 'आपका राज्य और गांव कौन सा है?' : 'Select your Indian state and village location.';
      speakText(q, language);
    } else if (stepNum === 4) {
      const q = language === 'mr' ? 'तुमचे मुख्य पीक कोणते आहे? खालील पिकांमधून निवडा.' : language === 'hi' ? 'आपकी मुख्य फसल कौन सी है? नीचे दिए गए विकल्पों में से चुनें।' : 'Which is your main crop? Select from below.';
      speakText(q, language);
    }
  };

  // Voice Input helper
  const startVoiceInput = (target: 'name' | 'mobile' | 'location' | 'crop' | 'loginMobile') => {
    if (typeof window === 'undefined') return;
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert(language === 'mr' ? 'आपल्या ब्राउझरमध्ये व्हॉइस इनपुट समर्थित नाही.' : 'Voice recognition is not supported in this browser.');
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      setListeningTarget(null);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;
      recognition.lang = language === 'mr' ? 'mr-IN' : language === 'hi' ? 'hi-IN' : 'en-IN';
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
        setListeningTarget(target);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (target === 'name') setFarmerName(transcript);
        if (target === 'mobile') setMobileNumber(transcript.replace(/\D/g, ''));
        if (target === 'location') setLocation(transcript);
        if (target === 'loginMobile') setLoginMobile(transcript.replace(/\D/g, ''));
        setIsListening(false);
        setListeningTarget(null);
      };

      recognition.onerror = () => {
        setIsListening(false);
        setListeningTarget(null);
      };

      recognition.start();
    } catch (e) {
      setIsListening(false);
      setListeningTarget(null);
    }
  };

  // Detect GPS Location
  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      alert(language === 'mr' ? 'आपल्या ब्राउझरमध्ये GPS समर्थित नाही.' : 'GPS geolocation is not supported.');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        const locStr = language === 'mr' ? `नाशिक, ${selectedState}` : `Nashik, ${selectedState}`;
        setLocation(locStr);
        speakText(language === 'mr' ? 'स्थान प्राप्त झाले' : 'Location detected', language);
      },
      (err) => {
        setIsLocating(false);
        setLocation(`Nashik, ${selectedState}`);
      }
    );
  };

  // OTP Sending logic
  const handleSendOtp = async () => {
    if (!mobileNumber || mobileNumber.length < 10) {
      alert(language === 'mr' ? 'कृपया १० अंकी वैध मोबाईल नंबर टाका.' : 'Please enter a valid 10-digit mobile number.');
      return;
    }
    setIsOtpSent(true);
    setOtp('5842');
    speakText(language === 'mr' ? 'ओ टी पी ५ ८ ४ २ प्रविष्ट करा.' : 'Enter OTP 5842 to verify.', language);
  };

  // Registration step submit handler
  const handleContinueRegistration = () => {
    if (step === 1) {
      if (!farmerName.trim()) {
        alert(language === 'mr' ? 'कृपया तुमचे नाव लिहा.' : 'Please enter your name.');
        return;
      }
      setStep(2);
      speakStepQuestion(2);
    } else if (step === 2) {
      if (!mobileNumber || mobileNumber.length < 10) {
        alert(language === 'mr' ? 'कृपया वैध मोबाईल नंबर टाका.' : 'Please enter a valid mobile number.');
        return;
      }
      if (!isOtpSent) {
        handleSendOtp();
        return;
      }
      setStep(3);
      speakStepQuestion(3);
    } else if (step === 3) {
      if (!location.trim()) {
        setLocation(`Nashik, ${selectedState}`);
      }
      setStep(4);
      speakStepQuestion(4);
    } else if (step === 4) {
      const cropObj = REGISTRATION_CROPS.find((c) => c.id === selectedCropId);
      const cropName =
        selectedCropId === 'other'
          ? customCropName || (language === 'mr' ? 'ऊस / भाजीपाला' : 'Sugarcane / Vegetables')
          : language === 'mr'
          ? `${cropObj?.nameMr} (${cropObj?.nameEn})`
          : language === 'hi'
          ? `${cropObj?.nameHi} (${cropObj?.nameEn})`
          : `${cropObj?.nameEn}`;

      setCurrentView('success');

      const welcomeMsg =
        language === 'mr'
          ? `नमस्कार, ${farmerName}! किसान एआय मध्ये आपले स्वागत आहे.`
          : language === 'hi'
          ? `नमस्ते, ${farmerName}! किसान एआई में आपका स्वागत है।`
          : `Welcome ${farmerName}! KisanAI companion ready.`;

      speakText(welcomeMsg, language);

      setTimeout(() => {
        completeFarmerRegistration({
          name: farmerName,
          phone: mobileNumber,
          location: `${location} (${selectedState})`,
          mainCrop: cropName,
          landAcres: landAcres,
          language: language,
        });
      }, 2500);
    }
  };

  // Login handler
  const handleLoginSubmit = () => {
    if (!isLoginOtpSent) {
      if (!loginMobile || loginMobile.length < 10) {
        alert(language === 'mr' ? 'कृपया वैध मोबाईल नंबर टाका.' : 'Please enter a valid 10-digit mobile number.');
        return;
      }
      setIsLoginOtpSent(true);
      setLoginOtp('5842');
      speakText(language === 'mr' ? 'ओ टी पी ५ ८ ४ २ प्रविष्ट करा.' : 'Enter OTP 5842 to login.', language);
      return;
    }

    loginFarmerWithMobile(loginMobile);
  };

  const getCropDisplayName = (crop: CropOption) => {
    if (language === 'mr') return crop.nameMr;
    if (language === 'hi') return crop.nameHi;
    return crop.nameEn;
  };

  return (
    <div
      id="kisanai-onboarding-container"
      className="min-h-screen w-full flex flex-col items-center justify-center p-4 sm:p-6 bg-[#f4f7f5] text-slate-800 selection:bg-emerald-600 selection:text-white relative overflow-hidden font-sans"
    >
      {/* Background ambient gradient glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-emerald-200/40 via-teal-100/30 to-transparent blur-3xl pointer-events-none -z-10" />

      {/* Top Floating Language Switcher Header */}
      <div className="w-full max-w-lg mx-auto flex items-center justify-between gap-2 mb-6 z-20">
        <KisanLogo size="sm" showTagline={true} />

        {/* Language selector chips */}
        <div className="flex items-center bg-white/90 shadow-sm rounded-2xl p-1 border border-emerald-200">
          {(['mr', 'hi', 'en'] as const).map((lang) => (
            <button
              key={lang}
              id={`onboarding-lang-btn-${lang}`}
              onClick={() => {
                setLanguage(lang);
                if (currentView === 'welcome') speakWelcome(lang);
                else if (currentView === 'registration') speakStepQuestion(step);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                language === lang
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'mr' ? 'मराठी' : lang === 'hi' ? 'हिंदी' : 'English'}
            </button>
          ))}
        </div>
      </div>

      {/* Main Clean Light Card Container */}
      <div className="w-full max-w-lg relative z-10">
        <AnimatePresence mode="wait">
          
          {/* ========================================================= */}
          {/* 1. WELCOME SCREEN                                         */}
          {/* ========================================================= */}
          {currentView === 'welcome' && (
            <motion.div
              key="view-welcome"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="bg-white border border-emerald-100 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6 text-center"
            >
              {/* Brand Logo Emblem */}
              <div className="flex flex-col items-center justify-center gap-2">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-emerald-600 via-emerald-500 to-teal-500 flex items-center justify-center text-white shadow-lg shadow-emerald-600/20">
                  <Sprout className="w-10 h-10" />
                </div>
              </div>

              {/* Title & Tagline */}
              <div className="space-y-1.5">
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight font-outfit text-slate-900">
                  Kisan<span className="text-emerald-700">AI</span>
                </h1>
                <p className="text-lg font-bold text-emerald-800">
                  {language === 'mr'
                    ? 'आपल्या शेतीचा AI साथीदार'
                    : language === 'hi'
                    ? 'आपकी खेती का AI साथी'
                    : 'Your Intelligent AI Farming Companion'}
                </p>
                <p className="text-xs sm:text-sm text-slate-600 max-w-sm mx-auto leading-relaxed font-medium">
                  {language === 'mr'
                    ? 'अचूक हवामान, थेट APMC मंडी भाव आणि AI पीक रोग निदान एकाच ठिकाणी.'
                    : language === 'hi'
                    ? 'सटीक मौसम, लाइव मंडी भाव और एआई फसल रोग निदान एक जगह।'
                    : 'Accurate weather, live APMC mandi prices, and AI crop disease detection in one place.'}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 pt-2">
                {/* 1. Instant Google Login Button */}
                <button
                  id="btn-google-login-welcome"
                  type="button"
                  disabled={isAuthProcessing}
                  onClick={async () => {
                    setIsAuthProcessing(true);
                    const res = await loginWithGoogle();
                    setIsAuthProcessing(false);
                    if (!res.success) {
                      setCurrentView('googleAuth');
                      speakText(language === 'mr' ? 'आपला गूगल ईमेल आणि नाव प्रविष्ट करा.' : 'Enter your Google email and full name.', language);
                    }
                  }}
                  className="w-full py-4 px-6 rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-extrabold text-base border-2 border-slate-200 shadow-md shadow-slate-200/50 transition-all flex items-center justify-center gap-3 cursor-pointer group"
                >
                  <svg className="w-6 h-6 flex-shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                  <span>
                    {language === 'mr'
                      ? 'Google ने एक-क्लिक लॉगिन करा'
                      : language === 'hi'
                      ? 'Google से डायरेक्ट लॉगिन करें'
                      : 'Sign in with Google Account'}
                  </span>
                  <ArrowRight className="w-5 h-5 ml-auto text-slate-400 group-hover:text-emerald-600 transition-colors" />
                </button>

                {/* 2. New Farmer Registration */}
                <button
                  id="btn-new-farmer-register"
                  onClick={() => {
                    setCurrentView('registration');
                    setStep(1);
                    speakStepQuestion(1);
                  }}
                  className="w-full py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-base shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-3 cursor-pointer"
                >
                  <span className="text-xl">🚜</span>
                  <span>
                    {language === 'mr'
                      ? 'नवीन शेतकरी नोंदणी (New Farmer)'
                      : language === 'hi'
                      ? 'नया किसान पंजीकरण (New Farmer)'
                      : 'New Farmer Registration'}
                  </span>
                  <ArrowRight className="w-5 h-5 ml-auto" />
                </button>

                {/* 3. Mobile OTP Login */}
                <button
                  id="btn-farmer-login-existing"
                  onClick={() => {
                    setCurrentView('login');
                    speakText(language === 'mr' ? 'लॉगिनसाठी मोबाईल नंबर टाका.' : 'Enter mobile number to login.', language);
                  }}
                  className="w-full py-3.5 px-6 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold text-sm sm:text-base border border-emerald-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Lock className="w-4 h-4 text-emerald-700" />
                  <span>
                    {language === 'mr'
                      ? 'मोबाईल नंबरने लॉगिन (Mobile Login)'
                      : language === 'hi'
                      ? 'मोबाइल नंबर से लॉगिन (Login)'
                      : 'Existing Farmer Login'}
                  </span>
                </button>
              </div>

              {/* State Support Tag & Tractor Badge */}
              <div className="pt-3 border-t border-slate-100 flex flex-col items-center gap-1.5 text-xs font-bold text-emerald-800">
                <div className="flex items-center justify-center gap-2">
                  <Landmark className="w-4 h-4 text-emerald-600" />
                  <span>
                    {language === 'mr'
                      ? 'भारतातील संपूर्ण ३६ राज्य व केंद्रशासित प्रदेश समर्थित'
                      : language === 'hi'
                      ? 'भारत के सभी 36 राज्य एवं केंद्र शासित प्रदेश शामिल'
                      : 'Supporting Farmers Across All 36 Indian States & UTs'}
                  </span>
                </div>
                <span className="text-[10px] text-amber-700 font-semibold flex items-center gap-1">
                  <span>🚜</span>
                  <span>100% Persistent Auto-Login - Once Logged In, Stay Signed In!</span>
                </span>
              </div>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* 2. REGISTRATION STEP-BY-STEP FLOW (Steps 1 to 4)         */}
          {/* ========================================================= */}
          {currentView === 'registration' && (
            <motion.div
              key={`reg-step-${step}`}
              initial={{ opacity: 0, x: 15 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -15 }}
              transition={{ duration: 0.25 }}
              className="bg-white border border-emerald-100 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6 text-slate-800"
            >
              {/* Step Progress Header */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-emerald-800">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                      {language === 'mr' ? `टप्पा ${step} / ४` : language === 'hi' ? `चरण ${step} / ४` : `Step ${step} of 4`}
                    </span>
                    <span>
                      {step === 1 && (language === 'mr' ? 'शेतकरी नाव' : 'Farmer Name')}
                      {step === 2 && (language === 'mr' ? 'मोबाईल व OTP' : 'Mobile & OTP')}
                      {step === 3 && (language === 'mr' ? 'राज्य व ठिकाण' : 'State & Location')}
                      {step === 4 && (language === 'mr' ? 'मुख्य पीक' : 'Main Crop')}
                    </span>
                  </div>

                  <button
                    onClick={() => speakStepQuestion(step)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-[11px] font-bold cursor-pointer border border-emerald-200"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{language === 'mr' ? 'ऐका' : 'Listen'}</span>
                  </button>
                </div>

                {/* Progress bar line */}
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-600 transition-all duration-300 rounded-full"
                    style={{ width: `${(step / 4) * 100}%` }}
                  />
                </div>
              </div>

              {/* STEP 1: FARMER NAME */}
              {step === 1 && (
                <div className="space-y-4">
                  <div className="space-y-1">
                    <h2 className="text-xl font-extrabold text-slate-900 font-outfit">
                      {language === 'mr' ? '१. तुमचे पूर्ण नाव काय आहे?' : language === 'hi' ? '1. आपका नाम क्या है?' : '1. Enter your full name'}
                    </h2>
                    <p className="text-xs text-slate-500 font-medium">
                      {language === 'mr' ? 'खाते व कृषी सल्ल्यासाठी तुमचे नाव लिहा.' : 'Enter your name to personalize your farming advice.'}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {language === 'mr' ? 'शेतकऱ्याचे नाव (Full Name)' : 'Farmer Full Name'}
                    </label>
                    <input
                      type="text"
                      value={farmerName}
                      onChange={(e) => setFarmerName(e.target.value)}
                      placeholder={language === 'mr' ? 'उदा. ज्ञानेश्वर पाटील' : 'e.g. Dnyaneshwar Patil'}
                      className="w-full px-4 py-3.5 rounded-2xl bg-slate-50 border-2 border-emerald-200 focus:border-emerald-600 text-base font-bold text-slate-900 focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {/* STEP 2: MOBILE & OTP */}
              {step === 2 && (
                <div className="space-y-4">
                  <div className="space-y-1">
                    <h2 className="text-xl font-extrabold text-slate-900 font-outfit">
                      {language === 'mr' ? '२. मोबाईल नंबर व OTP सत्यापन' : language === 'hi' ? '2. मोबाइल नंबर और OTP सत्यापन' : '2. Mobile Number & OTP Verification'}
                    </h2>
                    <p className="text-xs text-slate-500 font-medium">
                      {language === 'mr' ? 'सुरक्षित लॉग इन साठी तुमचा नंबर टाका.' : 'Enter mobile number for real-time OTP verification.'}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {language === 'mr' ? 'मोबाईल नंबर' : '10-Digit Mobile Number'}
                    </label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-base font-black text-emerald-700 font-mono">
                        +91
                      </span>
                      <input
                        type="tel"
                        maxLength={10}
                        value={mobileNumber}
                        onChange={(e) => setMobileNumber(e.target.value)}
                        placeholder="98234 56789"
                        className="w-full pl-16 pr-4 py-3.5 rounded-2xl bg-slate-50 border-2 border-emerald-200 focus:border-emerald-600 text-lg font-mono font-bold text-slate-900 focus:outline-none"
                      />
                    </div>
                  </div>

                  {isOtpSent ? (
                    <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-3">
                      <div className="flex items-center justify-between text-xs font-bold text-emerald-900">
                        <span>🔐 Enter OTP Code (4 Digits)</span>
                        <span className="text-emerald-700 font-mono">Demo: 5842</span>
                      </div>
                      <input
                        type="text"
                        maxLength={4}
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        className="w-full text-center tracking-[0.5em] text-2xl font-black font-mono py-3 rounded-xl bg-white border-2 border-emerald-500 text-slate-900"
                      />
                      <button
                        type="button"
                        onClick={() => setOtp('5842')}
                        className="text-xs text-emerald-700 font-bold underline block text-center cursor-pointer"
                      >
                        {language === 'mr' ? '५८४२ आपोआप भरा (Auto-fill Demo OTP)' : 'Auto-fill Demo OTP (5842)'}
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm cursor-pointer shadow-sm"
                    >
                      {language === 'mr' ? '📩 OTP मिळवा (Send OTP)' : '📩 Send OTP via Mobile SMS'}
                    </button>
                  )}
                </div>
              )}

              {/* STEP 3: STATE & LOCATION */}
              {step === 3 && (
                <div className="space-y-4">
                  <div className="space-y-1">
                    <h2 className="text-xl font-extrabold text-slate-900 font-outfit">
                      {language === 'mr' ? '३. राज्य व ठिकाण निवडा' : language === 'hi' ? '3. राज्य और स्थान चुनें' : '3. Select Your Indian State & Location'}
                    </h2>
                    <p className="text-xs text-slate-500 font-medium">
                      {language === 'mr' ? 'अचूक हवामान आणि APMC मंडी दरासाठी तुमचे राज्य निवडा.' : 'Select state for localized mandi rates and weather alerts.'}
                    </p>
                  </div>

                  {/* Indian State Dropdown (ALL 36 STATES & UTs) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {language === 'mr' ? 'राज्य / केंद्रशासित प्रदेश (Indian State / UT):' : 'Select State / Union Territory:'}
                    </label>
                    <select
                      value={selectedState}
                      onChange={(e) => {
                        setSelectedState(e.target.value);
                        setLocation(`Nashik, ${e.target.value}`);
                      }}
                      className="w-full px-4 py-3.5 rounded-2xl bg-slate-50 border-2 border-emerald-200 focus:border-emerald-600 text-slate-900 font-bold text-sm focus:outline-none"
                    >
                      {INDIAN_STATES_AND_UTS.map((st) => (
                        <option key={st.code} value={st.name}>
                          {st.name} ({st.nameHi}) - {st.type}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Village / Location Input */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {language === 'mr' ? 'गाव / तालुका / जिल्हा' : 'Village / District'}
                    </label>
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="e.g. Nashik, Maharashtra"
                      className="w-full px-4 py-3.5 rounded-2xl bg-slate-50 border-2 border-emerald-200 focus:border-emerald-600 text-base font-bold text-slate-900 focus:outline-none"
                    />
                  </div>

                  {/* GPS Auto-detect Button */}
                  <button
                    type="button"
                    onClick={handleDetectLocation}
                    disabled={isLocating}
                    className="w-full py-3 px-4 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center gap-2 border border-emerald-200 cursor-pointer"
                  >
                    <Navigation className={`w-4 h-4 text-emerald-600 ${isLocating ? 'animate-spin' : ''}`} />
                    <span>
                      {isLocating ? 'Detecting Location...' : '📍 Auto-detect My GPS Location'}
                    </span>
                  </button>
                </div>
              )}

              {/* STEP 4: MAIN CROP */}
              {step === 4 && (
                <div className="space-y-4">
                  <div className="space-y-1">
                    <h2 className="text-xl font-extrabold text-slate-900 font-outfit">
                      {language === 'mr' ? '४. तुमची मुख्य फसल निवडा' : language === 'hi' ? '4. मुख्य फसल का चयन करें' : '4. Select Your Primary Crop'}
                    </h2>
                    <p className="text-xs text-slate-500 font-medium">
                      {language === 'mr' ? 'दैनंदिन खत आणि रोग व्यवस्थापनासाठी पीक निवडा.' : 'We will customize spray advisories for this crop.'}
                    </p>
                  </div>

                  {/* Crop Cards Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-h-56 overflow-y-auto pr-1">
                    {REGISTRATION_CROPS.map((crop) => {
                      const isSelected = selectedCropId === crop.id;
                      return (
                        <button
                          key={crop.id}
                          type="button"
                          onClick={() => setSelectedCropId(crop.id)}
                          className={`p-3 rounded-2xl border-2 text-center transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                            isSelected
                              ? 'bg-emerald-600 text-white border-emerald-600 font-black shadow-md'
                              : 'bg-slate-50 hover:bg-emerald-50 text-slate-800 border-slate-200 font-bold'
                          }`}
                        >
                          <span className="text-2xl">{crop.icon}</span>
                          <span className="text-xs font-bold">{getCropDisplayName(crop)}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Navigation Actions */}
              <div className="flex items-center gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    if (step > 1) setStep(step - 1);
                    else setCurrentView('welcome');
                  }}
                  className="py-3.5 px-5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>

                <button
                  type="button"
                  onClick={handleContinueRegistration}
                  className="flex-1 py-3.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-base shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>
                    {step === 4
                      ? language === 'mr' ? '🎉 नोंदणी पूर्ण करा' : '🎉 Complete Registration'
                      : language === 'mr' ? 'पुढे जा' : 'Continue'}
                  </span>
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* 3. MOBILE LOGIN SCREEN                                     */}
          {/* ========================================================= */}
          {currentView === 'login' && (
            <motion.div
              key="view-login"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.25 }}
              className="bg-white border border-emerald-100 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6 text-slate-800"
            >
              <div className="text-center space-y-2">
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-800 mx-auto flex items-center justify-center shadow-xs text-2xl font-bold">
                  🔐
                </div>
                <h2 className="text-2xl font-extrabold text-slate-900 font-outfit">
                  {language === 'mr' ? 'शेतकरी लॉगिन' : 'Farmer Mobile Login'}
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                  {language === 'mr' ? 'तुमचा १० अंकी नोंदणीकृत नंबर टाका.' : 'Enter your registered 10-digit mobile number.'}
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {language === 'mr' ? 'मोबाईल नंबर' : 'Mobile Number'}
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-base font-black text-emerald-700 font-mono">
                    +91
                  </span>
                  <input
                    type="tel"
                    maxLength={10}
                    value={loginMobile}
                    onChange={(e) => setLoginMobile(e.target.value)}
                    placeholder="98234 56789"
                    className="w-full pl-16 pr-4 py-3.5 rounded-2xl bg-slate-50 border-2 border-emerald-200 focus:border-emerald-600 text-lg font-mono font-bold text-slate-900 focus:outline-none"
                  />
                </div>
              </div>

              {isLoginOtpSent && (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-900">
                    <span>🔐 Enter Verification OTP</span>
                    <span className="text-emerald-700 font-mono">Demo: 5842</span>
                  </div>
                  <input
                    type="text"
                    maxLength={4}
                    value={loginOtp}
                    onChange={(e) => setLoginOtp(e.target.value)}
                    className="w-full text-center tracking-[0.5em] text-2xl font-black font-mono py-3 rounded-xl bg-white border-2 border-emerald-500 text-slate-900"
                  />
                </div>
              )}

              <div className="space-y-3 pt-2">
                <button
                  type="button"
                  onClick={handleLoginSubmit}
                  className="w-full py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-base shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>{isLoginOtpSent ? 'Verify OTP & Login' : 'Get OTP Code'}</span>
                  <ArrowRight className="w-5 h-5" />
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentView('welcome')}
                  className="w-full py-3 text-xs font-bold text-slate-600 hover:text-slate-900 text-center block cursor-pointer"
                >
                  ← Back to Main Menu
                </button>
              </div>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* 3.5 GOOGLE AUTH FORM (Real-Time User Email & Name Input)  */}
          {/* ========================================================= */}
          {currentView === 'googleAuth' && (
            <motion.div
              key="view-google-auth"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.25 }}
              className="bg-white border border-emerald-100 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6 text-slate-800"
            >
              <div className="text-center space-y-2">
                <div className="w-14 h-14 rounded-2xl bg-white border border-slate-200 shadow-sm mx-auto flex items-center justify-center p-2">
                  <svg className="w-9 h-9" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                </div>
                <h2 className="text-2xl font-extrabold text-slate-900 font-outfit">
                  {language === 'mr' ? 'Google द्वारे साइन इन करा' : language === 'hi' ? 'Google से साइन इन करें' : 'Sign in with Google Account'}
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                  {language === 'mr' ? 'आपला खरा गूगल ईमेल आणि नाव टाका' : 'Enter your real Google Account Email & Name'}
                </p>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!googleEmailInput.trim() || !googleNameInput.trim()) {
                    alert(language === 'mr' ? 'कृपया आपला ईमेल आणि नाव प्रविष्ट करा.' : 'Please enter your Google Email and Full Name.');
                    return;
                  }
                  loginWithCustomGoogleProfile(googleEmailInput, googleNameInput);
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    {language === 'mr' ? 'गूगल ईमेल पत्ता (Google Email)' : 'Google Account Email'}
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">📧</span>
                    <input
                      type="email"
                      required
                      value={googleEmailInput}
                      onChange={(e) => setGoogleEmailInput(e.target.value)}
                      placeholder="e.g. vaishnavi@gmail.com"
                      className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-slate-50 border-2 border-emerald-200 focus:border-emerald-600 text-sm font-bold text-slate-900 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    {language === 'mr' ? 'तुमचे नाव (Full Name)' : 'Your Full Name'}
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">👤</span>
                    <input
                      type="text"
                      required
                      value={googleNameInput}
                      onChange={(e) => setGoogleNameInput(e.target.value)}
                      placeholder="e.g. Vaishnavi Shinde"
                      className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-slate-50 border-2 border-emerald-200 focus:border-emerald-600 text-sm font-bold text-slate-900 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  <button
                    type="submit"
                    className="w-full py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-base shadow-md flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>{language === 'mr' ? 'गूगल ने लॉगिन पूर्ण करा 🚀' : 'Complete Google Login 🚀'}</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => setCurrentView('welcome')}
                    className="w-full py-2.5 text-xs font-bold text-slate-600 hover:text-slate-900 text-center block cursor-pointer"
                  >
                    ← Back to Main Menu
                  </button>
                </div>
              </form>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* 4. SUCCESS CELEBRATION SCREEN                             */}
          {/* ========================================================= */}
          {currentView === 'success' && (
            <motion.div
              key="view-success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="bg-white border border-emerald-100 rounded-3xl p-8 shadow-xl text-center space-y-4"
            >
              <div className="w-20 h-20 bg-emerald-100 text-emerald-700 rounded-3xl mx-auto flex items-center justify-center text-4xl shadow-md animate-bounce">
                🎉
              </div>
              <h2 className="text-2xl font-extrabold text-slate-900 font-outfit">
                {language === 'mr' ? 'नोंदणी यशस्वी झाली!' : 'Registration Successful!'}
              </h2>
              <p className="text-sm text-slate-600 font-medium">
                Opening KisanAI Farmer Dashboard...
              </p>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  );
};
