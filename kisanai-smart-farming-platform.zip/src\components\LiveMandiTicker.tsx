import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { TrendingUp, TrendingDown, RefreshCw, Zap, ArrowUpRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MandiPrice } from '../types';

export const LiveMandiTicker: React.FC = () => {
  const { openModal, language } = useApp();
  const [rates, setRates] = useState<MandiPrice[]>([]);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastUpdatedTime, setLastUpdatedTime] = useState<string>('Live');

  const fetchLiveRates = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch('/api/mandi-rates/live');
      const data = await res.json();
      if (data.data && Array.isArray(data.data)) {
        setRates(data.data);
        const timeNow = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
        setLastUpdatedTime(timeNow);
      }
    } catch (err) {
      console.warn('Failed to fetch live mandi ticker rates:', err);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchLiveRates();
    // Auto refresh live prices every 10 seconds for real-time feel
    const interval = setInterval(() => {
      fetchLiveRates();
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  if (!rates || rates.length === 0) return null;

  return (
    <div className="w-full bg-[#064e3b] border-b border-emerald-700/50 py-2 px-3 sm:px-6 text-white overflow-hidden shadow-xs flex items-center gap-3">
      {/* Live Badge */}
      <div
        onClick={() => openModal('mandiPrices')}
        className="flex items-center gap-2 shrink-0 bg-emerald-800/90 border border-emerald-400/40 px-2.5 py-1 rounded-xl shadow-xs cursor-pointer"
      >
        <span className="relative flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
        </span>
        <span className="text-[11px] font-black tracking-wider uppercase text-emerald-300 flex items-center gap-1 font-outfit">
          <Zap className="w-3 h-3 text-amber-400 fill-amber-400" />
          {language === 'mr' ? 'थेट बाजारभाव' : language === 'hi' ? 'लाइव मंडी भाव' : 'Live APMC'}
        </span>
      </div>

      {/* Marquee Rate Stream */}
      <div className="flex-1 overflow-x-auto no-scrollbar flex items-center gap-4 py-0.5">
        {rates.map((item) => {
          const isUp = item.trend === 'up';
          return (
            <button
              key={item.id}
              onClick={() => openModal('mandiPrices')}
              className="flex items-center gap-2 px-3 py-1 rounded-xl bg-white/5 hover:bg-white/10 border border-emerald-500/20 hover:border-emerald-500/50 text-left transition-all cursor-pointer shrink-0 text-xs group"
            >
              <span className="font-bold text-emerald-100 group-hover:text-emerald-300 transition-colors">
                {item.commodity.split(' ')[0]} ({item.market})
              </span>
              <span className="font-mono font-black text-amber-300">
                ₹{item.modalPrice.toLocaleString('en-IN')}
              </span>
              <span
                className={`flex items-center text-[10px] font-extrabold px-1.5 py-0.5 rounded-md ${
                  isUp
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                }`}
              >
                {isUp ? <TrendingUp className="w-2.5 h-2.5 mr-0.5" /> : <TrendingDown className="w-2.5 h-2.5 mr-0.5" />}
                {isUp ? `+${item.change24h}%` : `${item.change24h}%`}
              </span>
            </button>
          );
        })}
      </div>

      {/* Manual Refresh & All Rates Link */}
      <div className="flex items-center gap-1.5 shrink-0">
        <button
          onClick={fetchLiveRates}
          disabled={isRefreshing}
          className="p-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 hover:text-white transition-colors cursor-pointer disabled:opacity-50"
          title="Refresh live prices"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
        </button>
        <button
          onClick={() => openModal('mandiPrices')}
          className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition-all cursor-pointer shadow-sm"
        >
          <span>{language === 'mr' ? 'सर्व भाव' : language === 'hi' ? 'सभी भाव' : 'All Mandis'}</span>
          <ArrowUpRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
