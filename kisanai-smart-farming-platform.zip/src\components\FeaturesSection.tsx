import React from 'react';
import { motion } from 'motion/react';
import {
  Scan,
  Sprout,
  CloudRain,
  TrendingUp,
  Landmark,
  FlaskConical,
  Droplets,
  Mic,
  ArrowRight,
  Sparkles,
  Zap,
} from 'lucide-react';
import { FEATURES_LIST } from '../data/mockAgriData';
import { useApp } from '../context/AppContext';

export const FeaturesSection: React.FC = () => {
  const { openModal, setActiveTab, t } = useApp();

  const iconMap: Record<string, any> = {
    Scan,
    Sprout,
    CloudRain,
    TrendingUp,
    Landmark,
    FlaskConical,
    Droplets,
    Mic,
  };

  const handleCardAction = (id: string) => {
    switch (id) {
      case 'disease-detection':
        openModal('diagnose');
        break;
      case 'ai-voice-assistant':
        openModal('askAi');
        break;
      case 'weather-intelligence':
        openModal('weatherAdvisory');
        break;
      case 'market-prices':
        openModal('marketIntelligence');
        break;
      case 'soil-analysis':
        openModal('soilHealth');
        break;
      case 'government-schemes':
        openModal('schemes');
        break;
      case 'crop-recommendation':
        openModal('cropRecommendation');
        break;
      case 'smart-irrigation':
        openModal('cropLifecycle');
        break;
      default:
        openModal('askAi');
    }
  };

  return (
    <section id="features" className="py-16 sm:py-24 relative overflow-hidden">
      {/* Subtle Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-6xl h-full bg-radial from-emerald-500/5 via-transparent to-transparent blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 dark:bg-emerald-500/15 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 text-xs sm:text-sm font-semibold">
            <Sparkles className="w-4 h-4 text-emerald-500" />
            <span>Intelligent Agricultural Suite</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-emerald-950 dark:text-white font-outfit tracking-tight leading-tight">
            {t('featuresTitle')}
          </h2>

          <p className="text-base sm:text-lg text-emerald-900/70 dark:text-emerald-200/70 leading-relaxed font-normal">
            {t('featuresSubtitle')}
          </p>
        </div>

        {/* 8 Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {FEATURES_LIST.map((feature, index) => {
            const Icon = iconMap[feature.iconName] || Sprout;
            return (
              <motion.div
                key={feature.id}
                id={`feature-card-${feature.id}`}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.07 }}
                whileHover={{ y: -6, transition: { duration: 0.2 } }}
                className="relative rounded-3xl p-6 bg-white/90 dark:bg-emerald-950/70 backdrop-blur-xl border border-emerald-500/20 hover:border-emerald-500/50 shadow-xl shadow-emerald-950/5 hover:shadow-2xl hover:shadow-emerald-500/15 transition-all flex flex-col justify-between group overflow-hidden"
              >
                {/* Subtle Top Gradient Accent */}
                <div className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r ${feature.color}`} />

                <div>
                  {/* Card Header: Icon & Badge */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-md shadow-emerald-500/25 group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 border border-emerald-500/20">
                      {feature.badge}
                    </span>
                  </div>

                  {/* Title & Tagline */}
                  <div className="space-y-1.5 mb-3">
                    <h3 className="text-xl font-bold text-emerald-950 dark:text-white font-outfit tracking-tight">
                      {feature.title}
                    </h3>
                    <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                      {feature.tagline}
                    </p>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-zinc-600 dark:text-zinc-300 leading-relaxed line-clamp-4 mb-4">
                    {feature.description}
                  </p>
                </div>

                {/* Footer: Metric & Action CTA */}
                <div className="pt-4 border-t border-emerald-500/15 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-500 dark:text-zinc-400">{feature.statsLabel}</span>
                    <span className="font-extrabold text-emerald-700 dark:text-emerald-300 font-mono">
                      {feature.statsMetric}
                    </span>
                  </div>

                  <button
                    id={`feature-btn-${feature.id}`}
                    onClick={() => handleCardAction(feature.id)}
                    className="w-full py-2.5 px-4 rounded-xl bg-emerald-50 dark:bg-emerald-900/40 hover:bg-emerald-600 hover:text-white text-emerald-900 dark:text-emerald-100 font-semibold text-xs border border-emerald-500/25 hover:border-emerald-600 transition-all flex items-center justify-center gap-2 cursor-pointer group/btn"
                  >
                    <span>Launch Tool</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
