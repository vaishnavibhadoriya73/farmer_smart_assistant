import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Coins,
  TrendingUp,
  ArrowRight,
  ShieldAlert,
  Volume2,
  VolumeX,
  X,
  Sparkles,
  Percent,
  Sliders,
  DollarSign,
  Scale,
  Award,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Cell,
  PieChart,
  Pie,
} from 'recharts';
import { useApp } from '../context/AppContext';
import { ProfitPredictionData } from '../types';

export const ProfitPredictionModal: React.FC = () => {
  const { activeModal, closeModal, language, speakText, isSpeaking, stopSpeaking, selectedCrop, savePredictionRecord } = useApp();

  const [cropName, setCropName] = useState<string>(selectedCrop?.name || 'Red Onion (कांदा)');
  const [landAcres, setLandAcres] = useState<number>(selectedCrop?.plotSizeAcres || 3);
  const [expectedYieldQuintals, setExpectedYieldQuintals] = useState<number>(360);
  const [expectedPricePerQuintal, setExpectedPricePerQuintal] = useState<number>(2450);
  const [totalCost, setTotalCost] = useState<number>(105000);
  const [profitData, setProfitData] = useState<ProfitPredictionData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const fetchProfitPrediction = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/ai/profit-prediction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cropName,
          landAcres,
          expectedYieldQuintals,
          expectedPricePerQuintal,
          totalCostOverride: totalCost,
        }),
      });
      const data = await res.json();
      if (data.data) {
        setProfitData(data.data);
        // Persist profit prediction to Firestore
        savePredictionRecord({
          id: `profit_${Date.now()}`,
          type: 'profit',
          cropName,
          plotSizeAcres: landAcres,
          predictedAmount: data.data.netProfit,
          unit: 'INR (₹)',
          confidenceScore: data.data.roiPercentage > 50 ? 92 : 85,
          factors: [`ROI: ${data.data.roiPercentage}%`, `Profit Margin: ${data.data.profitMarginPercentage}%`],
          recommendation: language === 'mr' ? data.data.audioAdvisoryMr : data.data.audioAdvisoryEn,
          timestamp: new Date().toISOString(),
        });
      }
    } catch (e) {
      console.error('Error fetching profit prediction:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (activeModal === 'profitPrediction') {
      fetchProfitPrediction();
    }
  }, [activeModal, cropName, landAcres, expectedYieldQuintals, expectedPricePerQuintal, totalCost]);

  if (activeModal !== 'profitPrediction') return null;

  const handleSpeak = () => {
    if (!profitData) return;
    if (isSpeaking) {
      stopSpeaking();
    } else {
      const textToSpeak =
        language === 'mr'
          ? profitData.audioAdvisoryMr
          : language === 'hi'
          ? profitData.audioAdvisoryHi
          : profitData.audioAdvisoryEn;
      speakText(textToSpeak, language);
    }
  };

  const COST_COLORS = ['#10b981', '#06b6d4', '#f59e0b', '#ec4899', '#8b5cf6', '#64748b'];

  return (
    <div
      id="profit-prediction-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-emerald-950/80 backdrop-blur-md overflow-y-auto"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        className="relative w-full max-w-5xl max-h-[92vh] rounded-3xl bg-white dark:bg-[#072418] border border-emerald-500/30 shadow-2xl flex flex-col overflow-hidden text-slate-900 dark:text-emerald-50"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-emerald-500/20 bg-emerald-50/90 dark:bg-emerald-950/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-emerald-500 text-white flex items-center justify-center shadow-md">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold font-outfit text-emerald-950 dark:text-white">
                  {language === 'mr' ? 'AI नफा अंदाज व अर्थशास्त्र' : language === 'hi' ? 'AI लाभ एवं आय अनुमान' : 'AI Crop Profit & ROI Calculator'}
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                  Agri-Economics
                </span>
              </div>
              <p className="text-xs text-emerald-800/80 dark:text-emerald-300/80">
                Investment → Expected Yield → Market Price → Revenue → Net Profit
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="listen-profit-btn"
              onClick={handleSpeak}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-800 dark:text-emerald-200 text-xs font-bold transition-all cursor-pointer"
            >
              {isSpeaking ? (
                <>
                  <VolumeX className="w-4 h-4 text-emerald-600 dark:text-emerald-300 animate-pulse" />
                  <span>{language === 'mr' ? 'थांबवा' : 'Stop'}</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 text-emerald-600 dark:text-emerald-300" />
                  <span>🔊 {language === 'mr' ? 'ऐका' : 'Listen'}</span>
                </>
              )}
            </button>

            <button
              id="close-profit-modal"
              onClick={closeModal}
              className="p-2 rounded-xl bg-emerald-100/60 dark:bg-emerald-900/40 hover:bg-emerald-200 dark:hover:bg-emerald-800/60 text-emerald-800 dark:text-emerald-200 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Interactive Calculation Pipeline Flow */}
          <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-emerald-900 via-teal-900 to-emerald-950 text-white shadow-lg border border-emerald-500/30">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-300 block mb-3">
              {language === 'mr' ? 'पायरी-दर-पायरी आर्थिक गणना' : 'Economics Calculation Flow'}
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 sm:gap-3 items-center text-center">
              {/* 1. Investment */}
              <div className="p-2.5 sm:p-3 rounded-2xl bg-white/10 border border-white/20">
                <span className="text-[9px] text-emerald-200 uppercase font-semibold block">1. Total Cost</span>
                <div className="text-sm sm:text-base font-black text-white mt-0.5">
                  ₹{profitData?.totalInvestment.toLocaleString('en-IN') || 0}
                </div>
              </div>

              {/* 2. Expected Yield */}
              <div className="p-2.5 sm:p-3 rounded-2xl bg-white/10 border border-white/20">
                <span className="text-[9px] text-emerald-200 uppercase font-semibold block">2. Yield</span>
                <div className="text-sm sm:text-base font-black text-white mt-0.5">
                  {profitData?.expectedYieldTotalQuintals || 0} Q
                </div>
              </div>

              {/* 3. Market Price */}
              <div className="p-2.5 sm:p-3 rounded-2xl bg-white/10 border border-white/20">
                <span className="text-[9px] text-emerald-200 uppercase font-semibold block">3. Avg Price</span>
                <div className="text-sm sm:text-base font-black text-white mt-0.5">
                  ₹{profitData?.expectedPricePerQuintal || 0} /Q
                </div>
              </div>

              {/* 4. Total Revenue */}
              <div className="p-2.5 sm:p-3 rounded-2xl bg-white/10 border border-white/20">
                <span className="text-[9px] text-emerald-200 uppercase font-semibold block">4. Gross Revenue</span>
                <div className="text-sm sm:text-base font-black text-emerald-300 mt-0.5">
                  ₹{profitData?.grossRevenue.toLocaleString('en-IN') || 0}
                </div>
              </div>

              {/* 5. Net Profit */}
              <div className="col-span-2 sm:col-span-1 p-2.5 sm:p-3 rounded-2xl bg-amber-400 text-emerald-950 font-black shadow-lg">
                <span className="text-[9px] uppercase font-extrabold block">5. Net Profit</span>
                <div className="text-base sm:text-lg font-black mt-0.5">
                  ₹{profitData?.netProfit.toLocaleString('en-IN') || 0}
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Sliders / Inputs */}
          <div className="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/40 border border-emerald-500/20 space-y-4">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-emerald-300">
              <span className="flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-emerald-500" />
                {language === 'mr' ? 'किमती व खर्चाचे प्रमाण बदला' : 'Customize Economics Simulation'}
              </span>
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400">Live Recalculation</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  🌾 Crop:
                </label>
                <select
                  value={cropName}
                  onChange={(e) => setCropName(e.target.value)}
                  className="w-full p-2 rounded-xl bg-white dark:bg-emerald-900/60 border border-emerald-500/30 font-medium focus:outline-none focus:border-emerald-500"
                >
                  <option value="Red Onion (कांदा)">Red Onion (कांदा)</option>
                  <option value="Bt Cotton (कापूस)">Bt Cotton (कापूस)</option>
                  <option value="Soybean (सोयाबीन)">Soybean (सोयाबीन)</option>
                  <option value="Tomato (टोमॅटो)">Tomato (टोमॅटो)</option>
                  <option value="Wheat (गहू)">Wheat (गहू)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  🚜 Land Area: {landAcres} Acres
                </label>
                <input
                  type="range"
                  min="1"
                  max="20"
                  step="0.5"
                  value={landAcres}
                  onChange={(e) => {
                    const acres = parseFloat(e.target.value);
                    setLandAcres(acres);
                    setExpectedYieldQuintals(acres * 120);
                    setTotalCost(acres * 35000);
                  }}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  💰 Expected Price: ₹{expectedPricePerQuintal} / Q
                </label>
                <input
                  type="range"
                  min="1000"
                  max="6000"
                  step="50"
                  value={expectedPricePerQuintal}
                  onChange={(e) => setExpectedPricePerQuintal(parseInt(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400 block mb-1">
                  📈 Expected Yield: {expectedYieldQuintals} Quintals
                </label>
                <input
                  type="range"
                  min="20"
                  max="1000"
                  step="10"
                  value={expectedYieldQuintals}
                  onChange={(e) => setExpectedYieldQuintals(parseInt(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {profitData && (
            <>
              {/* Key Metrics 4-Box */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Net Profit */}
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30">
                  <span className="text-[11px] font-bold text-amber-800 dark:text-amber-300 uppercase block">
                    {language === 'mr' ? 'एकूण निव्वळ नफा' : 'Estimated Net Profit'}
                  </span>
                  <div className="text-2xl sm:text-3xl font-black font-outfit text-amber-600 dark:text-amber-400 mt-1">
                    ₹{profitData.netProfit.toLocaleString('en-IN')}
                  </div>
                  <span className="text-[10px] text-zinc-500 dark:text-emerald-400/80">
                    ₹{profitData.netProfitPerAcre.toLocaleString('en-IN')} / Acre
                  </span>
                </div>

                {/* Return on Investment ROI */}
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30">
                  <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 uppercase block">
                    {language === 'mr' ? 'परतावा दर (ROI)' : 'Return on Investment'}
                  </span>
                  <div className="text-2xl sm:text-3xl font-black font-outfit text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1">
                    <span>{profitData.roiPercentage}%</span>
                    <TrendingUp className="w-5 h-5 text-emerald-500" />
                  </div>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                    ₹{(profitData.grossRevenue / (profitData.totalInvestment || 1)).toFixed(2)}x Revenue Multiple
                  </span>
                </div>

                {/* Break-even Price */}
                <div className="p-4 rounded-2xl bg-sky-500/10 border border-sky-500/30">
                  <span className="text-[11px] font-bold text-sky-800 dark:text-sky-300 uppercase block">
                    {language === 'mr' ? 'किफायतशीर किमान भाव' : 'Break-Even Minimum Price'}
                  </span>
                  <div className="text-xl sm:text-2xl font-black font-outfit text-sky-700 dark:text-sky-300 mt-1">
                    ₹{profitData.breakEvenPricePerQuintal} / Q
                  </div>
                  <span className="text-[10px] text-zinc-500 dark:text-sky-300/80">No profit / no loss line</span>
                </div>

                {/* Risk Category */}
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30">
                  <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 uppercase block">
                    {language === 'mr' ? 'जोखीम पातळी' : 'Profit Risk Profile'}
                  </span>
                  <div className="text-xl sm:text-2xl font-black font-outfit text-emerald-600 dark:text-emerald-400 mt-1">
                    {profitData.riskLevel} Risk
                  </div>
                  <span className="text-[10px] text-zinc-500 dark:text-emerald-400/80">High market stability</span>
                </div>
              </div>

              {/* Charts & Cost Breakdown */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Price Scenarios Comparison */}
                <div className="lg:col-span-7 p-5 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 space-y-3">
                  <h3 className="text-xs sm:text-sm font-bold font-outfit text-emerald-950 dark:text-white">
                    {language === 'mr' ? 'बाजारभाव परिस्थितीनुसार नफा तुलना' : 'Profit Scenarios by Market Price'}
                  </h3>

                  <div className="h-60 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={profitData.scenarios} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#10b981" opacity={0.15} />
                        <XAxis dataKey="scenario" tick={{ fontSize: 10, fill: '#64748b' }} />
                        <YAxis tick={{ fontSize: 10, fill: '#64748b' }} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#06291a',
                            borderRadius: '12px',
                            border: '1px solid #10b981',
                            color: '#fff',
                            fontSize: '12px',
                          }}
                        />
                        <Legend />
                        <Bar dataKey="revenue" name="Revenue (₹)" fill="#06b6d4" radius={[6, 6, 0, 0]} />
                        <Bar dataKey="profit" name="Net Profit (₹)" fill="#10b981" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Investment Cost Head Breakdown */}
                <div className="lg:col-span-5 p-5 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 space-y-3">
                  <h3 className="text-xs sm:text-sm font-bold font-outfit text-emerald-950 dark:text-white">
                    {language === 'mr' ? 'भांडवली खर्चाचे विभाजन' : 'Investment Cost Breakdown'}
                  </h3>

                  <div className="space-y-2 text-xs">
                    {profitData.costBreakdown.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-2 rounded-xl bg-emerald-50/50 dark:bg-emerald-900/30 border border-emerald-500/15"
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="w-2.5 h-2.5 rounded-full shrink-0"
                            style={{ backgroundColor: COST_COLORS[idx % COST_COLORS.length] }}
                          />
                          <span className="font-semibold text-slate-800 dark:text-emerald-100">{item.item}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 dark:text-white">
                            ₹{item.amount.toLocaleString('en-IN')}
                          </span>
                          <span className="text-[10px] text-zinc-500 dark:text-emerald-400 font-mono">
                            ({item.percentage}%)
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
};
