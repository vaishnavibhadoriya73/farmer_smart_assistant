export type LanguageCode = 'en' | 'hi' | 'mr' | 'pa' | 'te' | 'ta' | 'bn' | 'gu' | 'kn';

export interface Language {
  code: LanguageCode;
  name: string;
  nativeName: string;
  flag: string;
}

export interface FarmerProfile {
  id: string;
  userId?: string;
  email?: string;
  fullName: string;
  name?: string;
  phone: string;
  kisanId: string;
  language: LanguageCode;
  state: string;
  district: string;
  village: string;
  location?: string;
  landArea?: number;
  totalLandAcres: number;
  mainCrop?: string;
  soilType: string;
  irrigationSource: string;
  irrigationType?: string;
  avatarUrl?: string;
  registeredCropsCount: number;
  soilHealthStatus: 'Optimal' | 'Needs NPK' | 'Acidic' | 'Alkaline';
  activeAlertsCount: number;
  isRegistered?: boolean;
  latitude?: number;
  longitude?: number;
  farmGpsAddress?: string;
}

export interface CropItem {
  id: string;
  name: string;
  variety: string;
  category: 'Cereal' | 'Pulse' | 'Cash Crop' | 'Horticulture' | 'Oilseed' | 'Vegetable';
  sowingDate: string;
  harvestDate: string;
  plotSizeAcres: number;
  stage: 'Sowing' | 'Germination' | 'Vegetative' | 'Flowering' | 'Fruiting' | 'Harvesting';
  progressPercentage: number;
  healthStatus: 'Excellent' | 'Healthy' | 'Attention' | 'Critical';
  soilMoisture: number; // percentage
  temperature: number; // Celsius
  nextAction: string;
  expectedYieldQuintals: number;
  estimatedRevenue: number;
  image: string;
}

export interface DiseaseDiagnosis {
  id: string;
  type?: 'disease' | 'pest';
  cropName: string;
  diseaseName: string;
  nameMr?: string;
  nameHi?: string;
  scientificName?: string;
  confidenceScore: number; // 0 to 100
  severity: 'Low' | 'Medium' | 'Moderate' | 'High' | 'Severe';
  imageUrl?: string;
  detectedAt: string;
  symptoms: string[];
  causes?: string[];
  damage?: string[];
  treatment?: string[];
  organicRemedies: string[];
  chemicalRemedies: string[];
  preventiveMeasures: string[];
  expertAdvice: string;
  safeUseWarning?: string;
}

export interface AiChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  language?: LanguageCode;
  audioAvailable?: boolean;
  category?: 'disease' | 'weather' | 'mandi' | 'irrigation' | 'fertilizer' | 'schemes' | 'general';
  quickActions?: { label: string; action: string }[];
}

export interface WeatherAlert {
  id: string;
  type: 'heavy-rain' | 'heatwave' | 'strong-wind' | 'extreme-temp';
  titleMr: string;
  titleHi: string;
  titleEn: string;
  severity: 'warning' | 'critical' | 'info';
  adviceMr: string;
  adviceHi: string;
  adviceEn: string;
  icon: string;
}

export interface SmartIrrigationAdvisory {
  cropName: string;
  soilType: string;
  growthStage: string;
  needLevel: 'कमी' | 'मध्यम' | 'जास्त' | 'Low' | 'Medium' | 'High';
  needScore: number; // 0 to 100
  recommendationMr: string;
  recommendationHi: string;
  recommendationEn: string;
  waterQuantity: string; // e.g. "15-20 mm (Drip: 45 min)"
  bestTime: string; // e.g. "संध्याकाळी ५:०० नंतर"
  reasonMr: string;
  reasonHi: string;
  reasonEn: string;
}

export interface WeatherData {
  location: string;
  state: string;
  currentTemp: number;
  condition: string;
  conditionMr: string;
  humidity: number;
  windSpeedKmH: number;
  rainProbability: number;
  uvIndex: number;
  airQualityIndex: number;
  airQualityStatus: 'Good' | 'Moderate' | 'Poor';
  airQualityStatusMr: string;
  spraySuitability: 'Excellent' | 'Moderate' | 'Unfavorable';
  sprayAdvice: string;
  sprayAdviceMr: string;
  irrigationAdvice: string;
  irrigationAdviceMr: string;
  actionableRecommendationMr: string;
  actionableRecommendationHi: string;
  actionableRecommendationEn: string;
  alerts: WeatherAlert[];
  irrigationAdvisory: SmartIrrigationAdvisory;
  forecast: {
    day: string;
    dayMr: string;
    dayHi: string;
    tempMax: number;
    tempMin: number;
    condition: string;
    conditionMr: string;
    rainChance: number;
    icon: string;
  }[];
}

export interface SoilAnalysisResult {
  id: string;
  analyzedAt: string;
  soilType: string;
  sourceType: 'report' | 'photo' | 'voice' | 'sensor';
  ph: number;
  phStatus: 'Acidic' | 'Neutral (Optimal)' | 'Alkaline';
  phStatusMr: string;
  nitrogenKgHa: number;
  nitrogenStatus: 'Low' | 'Medium' | 'High';
  nitrogenStatusMr: string;
  phosphorusKgHa: number;
  phosphorusStatus: 'Low' | 'Medium' | 'High';
  phosphorusStatusMr: string;
  potassiumKgHa: number;
  potassiumStatus: 'Low' | 'Medium' | 'High';
  potassiumStatusMr: string;
  organicCarbonPercent: number;
  organicCarbonStatus: 'Low' | 'Optimal' | 'High';
  organicCarbonStatusMr: string;
  suitableCrops: {
    nameMr: string;
    nameHi: string;
    nameEn: string;
    icon: string;
    reasonMr: string;
    reasonEn: string;
  }[];
  fertilizerDoses: {
    nameMr: string;
    nameEn: string;
    quantityPerAcre: string;
    stageMr: string;
    stageEn: string;
    purposeMr: string;
  }[];
  soilImprovementTips: {
    titleMr: string;
    titleEn: string;
    descMr: string;
    descEn: string;
  }[];
  irrigationRecommendation: {
    methodMr: string;
    methodEn: string;
    scheduleMr: string;
    scheduleEn: string;
    waterSavingTipMr: string;
  };
  summaryMr: string;
  summaryHi: string;
  summaryEn: string;
}

export interface MandiPrice {
  id: string;
  commodity: string;
  variety: string;
  market: string;
  district: string;
  state: string;
  modalPrice: number; // per quintal in INR
  minPrice: number;
  maxPrice: number;
  mspBenchmark: number;
  change24h: number; // percentage change
  trend: 'up' | 'down' | 'stable';
  lastUpdated: string;
}

export interface GovtScheme {
  id: string;
  name: string;
  acronym: string;
  category: 'Financial Aid' | 'Crop Insurance' | 'Solar & Irrigation' | 'Soil & Organic' | 'Equipment';
  benefitAmount: string;
  eligibility: string[];
  deadline?: string;
  applicationLink: string;
  documentsRequired: string[];
  tag: 'Popular' | 'Central' | 'State' | 'High Subsidy';
}

export interface FeatureCardItem {
  id: string;
  title: string;
  tagline: string;
  description: string;
  iconName: string;
  badge: string;
  color: string;
  statsMetric: string;
  statsLabel: string;
}

export type AppMode = 'farmer' | 'pro';

export interface OnboardingCropOption {
  id: string;
  nameEn: string;
  nameHi: string;
  nameMr: string;
  icon: string;
  category: 'Cereal' | 'Cash Crop' | 'Vegetable' | 'Pulse' | 'Oilseed';
  image: string;
}

export interface OnboardingData {
  fullName: string;
  language: LanguageCode;
  selectedCrops: string[];
  totalLandAcres: number;
  state: string;
  district: string;
}

export interface GpsLocationState {
  lat: number;
  lng: number;
  accuracy: number;
  altitude?: number | null;
  speed?: number | null;
  heading?: number | null;
  timestamp: number;
  village?: string;
  taluka?: string;
  district?: string;
  state?: string;
  postcode?: string;
  formattedAddress?: string;
  isLiveTracking?: boolean;
}

export interface TreatmentWeatherAdvisory {
  cropName: string;
  cropStage: string;
  targetPestOrDisease: string;
  sprayStatus: 'OPTIMAL' | 'CAUTION' | 'UNSAFE';
  safetyScore: number;
  temperature: number;
  humidity: number;
  windSpeedKmH: number;
  rainProbability: number;
  bestMorningWindow: string;
  bestEveningWindow: string;
  rainfastnessHours: number;
  warnings: string[];
  warningsMr: string[];
  chemicalTreatment: {
    primaryMolecule: string;
    dosagePerPump15L: string;
    dosagePerAcre: string;
    targetPathogen: string;
    safeHarvestIntervalDays: number;
  };
  organicTreatment: {
    molecule: string;
    dosagePerPump15L: string;
    dosagePerAcre: string;
    benefits: string;
  };
  nozzleRecommendation: string;
  waterPhRecommendation: string;
  protectiveGearMandate: string;
  protectiveGearMandateMr: string;
  audioNarrationMr: string;
  audioNarrationHi: string;
  audioNarrationEn: string;
}

export type ActiveModalType = 
  | null 
  | 'askAi' 
  | 'diagnose' 
  | 'login' 
  | 'cropDetail' 
  | 'soilHealth' 
  | 'mandiPrices' 
  | 'weatherAdvisory' 
  | 'schemes'
  | 'onboarding'
  | 'cropRecommendation'
  | 'cropLifecycle'
  | 'yieldPrediction'
  | 'profitPrediction'
  | 'marketIntelligence'
  | 'gpsTracker'
  | 'treatmentWeather'
  | 'supplyChain'
  | 'notifications'
  | 'profile'
  | 'settings';

export type SupplyChainStage = 'farm' | 'collection' | 'storage' | 'transport' | 'mandi' | 'buyer';
export type SupplyChainStatus = 'Harvested' | 'Collected' | 'Stored' | 'In Transit' | 'Reached Mandi' | 'Sold';

export interface SupplyChainShipment {
  id: string;
  farmerName: string;
  cropName: string;
  cropVariety: string;
  category: 'Grain' | 'Pulse' | 'Oilseed' | 'Cash Crop' | 'Spice' | 'Vegetable' | 'Fruit';
  quantityQuintals: number;
  harvestDate: string;
  farmLocation: string;
  destinationMandi: string;
  expectedSellingDate: string;
  storageRequirement: string;
  transportType: 'Mini Truck' | 'Truck' | 'Tractor' | 'Other';
  currentStage: SupplyChainStage;
  status: SupplyChainStatus;
  progressPercentage: number;
  estimatedArrival: string;
  currentLocation: string;
  createdAt?: string;
  storageDetails: {
    recommendedType: string;
    safeDurationDays: number;
    tempRange: string;
    humidityRange: string;
    spoilageRisk: 'Low' | 'Medium' | 'High';
  };
  transportDetails: {
    recommendedVehicle: string;
    estimatedDistanceKm: number;
    estimatedFreightCost: number;
    travelTimeHours: number;
    suggestedRoute: string;
  };
  marketAnalysis: {
    bestMandiName: string;
    distanceKm: number;
    marketPrice: number;
    transportCost: number;
    storageCost: number;
    netEarning: number;
    isBestOption: boolean;
  }[];
  aiSellingAdvice: {
    decision: 'SELL NOW' | 'WAIT' | 'SELL URGENTLY';
    currentPrice: number;
    expectedPriceShortTerm: number;
    expectedProfit: number;
    riskLevel: 'Low' | 'Medium' | 'High';
    reasonMr: string;
    reasonHi: string;
    reasonEn: string;
  };
}

export interface CropRecommendationInput {
  state: string;
  district: string;
  soilType: string;
  season: 'Kharif' | 'Rabi' | 'Zaid';
  rainfall: 'Low (<500mm)' | 'Medium (500-1000mm)' | 'High (>1000mm)';
  temperatureRange: string; // e.g. '22°C - 34°C'
  waterAvailability: 'Canal' | 'Borewell / Drip' | 'Open Well' | 'Rainfed';
  marketDemand: 'High Demand' | 'Rising Trend' | 'Steady' | 'Export Oriented';
  landAcres: number;
}

export interface RecommendedCrop {
  id: string;
  cropNameEn: string;
  cropNameHi: string;
  cropNameMr: string;
  variety: string;
  suitabilityScore: number; // e.g. 96
  isBestCrop: boolean;
  expectedYieldRange: string; // e.g. '30 - 35 Quintals / Acre'
  expectedYieldQuintalsPerAcre: number;
  investmentPerAcre: number; // in INR
  expectedProfitPerAcre: number; // in INR
  expectedRevenuePerAcre: number; // in INR
  roiPercentage: number;
  durationDays: string; // e.g. '110 - 125 Days'
  riskLevel: 'Low' | 'Moderate' | 'High';
  riskFactors: string[];
  keyAdvantages: string[];
  audioAdvisoryMr: string;
  audioAdvisoryHi: string;
  audioAdvisoryEn: string;
  image: string;
}

export interface CropLifecycleStage {
  id: 'sowing' | 'germination' | 'growth' | 'flowering' | 'maturity' | 'harvest';
  stageNumber: number;
  nameEn: string;
  nameHi: string;
  nameMr: string;
  icon: string;
  durationRangeDays: string;
  currentDayRange: string;
  descriptionMr: string;
  descriptionHi: string;
  descriptionEn: string;
  keyActions: string[];
  waterRequirement: string;
  fertilizerSchedule: string;
  pestPrevention: string;
  status: 'Completed' | 'Current' | 'Upcoming';
}

export interface YieldPredictionData {
  cropName: string;
  variety: string;
  plotSizeAcres: number;
  expectedYieldQuintals: number;
  expectedYieldPerAcre: number;
  historicalAverageYieldPerAcre: number;
  predictedHarvestDate: string;
  harvestWindow: string;
  cropHealthIndex: number; // 0 to 100
  cropHealthStatus: 'Excellent' | 'Good' | 'Fair' | 'Critical';
  ndviScore: number;
  soilMoistureLevel: number;
  chlorophyllIndex: number;
  riskLevel: 'Low' | 'Moderate' | 'High';
  riskFactors: {
    factor: string;
    impact: 'Low' | 'Medium' | 'High';
    mitigation: string;
  }[];
  monthlyYieldTrend: {
    stage: string;
    predictedYield: number;
    benchmarkYield: number;
  }[];
  yieldContributingFactors: {
    name: string;
    weight: number;
    score: number;
  }[];
  audioSummaryMr: string;
  audioSummaryHi: string;
  audioSummaryEn: string;
}

export interface ProfitPredictionData {
  cropName: string;
  landAcres: number;
  investmentBreakdown: {
    seeds: number;
    fertilizersAndPesticides: number;
    irrigationAndPower: number;
    laborCost: number;
    machineryAndTransport: number;
    misc: number;
  };
  totalInvestment: number;
  expectedYieldQuintals: number;
  expectedMarketPricePerQuintal: number;
  mspBenchmarkPerQuintal: number;
  grossRevenue: number;
  estimatedNetProfit: number;
  roiPercentage: number;
  riskLevel: 'Low' | 'Moderate' | 'High';
  breakEvenPricePerQuintal: number;
  profitPerAcre: number;
  scenarioAnalysis: {
    scenario: 'Pessimistic' | 'Expected' | 'Optimistic';
    pricePerQuintal: number;
    revenue: number;
    profit: number;
    roi: number;
  }[];
  audioAdviceMr: string;
  audioAdviceHi: string;
  audioAdviceEn: string;
}

export interface MarketIntelligenceData {
  commodity: string;
  variety: string;
  selectedMarket: string;
  currentModalPrice: number;
  minPrice: number;
  maxPrice: number;
  mspBenchmark: number;
  dailyChange: number; // percentage e.g. +3.4%
  weeklyTrend: 'up' | 'down' | 'stable';
  bestMandi: {
    name: string;
    distanceKm: number;
    modalPrice: number;
    netAdvantagePerQuintal: number;
    reason: string;
  };
  bestSellingTime: {
    window: string;
    projectedPrice: number;
    expectedGainPercentage: number;
    recommendation: string;
  };
  aiMarketAdviceMr: string;
  aiMarketAdviceHi: string;
  aiMarketAdviceEn: string;
  nearbyMandis: {
    marketName: string;
    district: string;
    distanceKm: number;
    currentPrice: number;
    change24h: number;
    trend: 'up' | 'down' | 'stable';
  }[];
  weeklyPriceTrend: {
    day: string;
    price: number;
    arrivalsTons: number;
  }[];
  historical30DayPrice: {
    date: string;
    price: number;
    msp: number;
  }[];
  futurePricePrediction: {
    period: string;
    predictedPrice: number;
    lowerBound: number;
    upperBound: number;
  }[];
}

export interface DailyFarmPlanTask {
  id: string;
  titleMr: string;
  titleHi: string;
  titleEn: string;
  descMr: string;
  descHi: string;
  descEn: string;
  completed: boolean;
  priority: 'High' | 'Medium' | 'Low';
  icon: string;
  timeOfDay: string;
}

export interface DailyFarmPlan {
  greetingMr: string;
  greetingHi: string;
  greetingEn: string;
  subGreetingMr: string;
  subGreetingHi: string;
  subGreetingEn: string;
  dateStr: string;
  tasks: DailyFarmPlanTask[];
  fullVoicePlanMr: string;
  fullVoicePlanHi: string;
  fullVoicePlanEn: string;
}

export interface SmartNotificationItem {
  id: string;
  type: 'rain' | 'pest' | 'disease' | 'price';
  titleMr: string;
  titleHi: string;
  titleEn: string;
  descriptionMr: string;
  descriptionHi: string;
  descriptionEn: string;
  severity: 'Critical' | 'Warning' | 'Positive' | 'Info';
  audioNarrationMr: string;
  audioNarrationHi: string;
  audioNarrationEn: string;
  timeAgo: string;
  actionTextMr: string;
  actionTextHi: string;
  actionTextEn: string;
  actionModal?: ActiveModalType;
}

export interface SchemeQuestionnaireAnswers {
  state: string;
  district: string;
  landAcres: number;
  cropCategory: string;
  farmerCategory: 'Small / Marginal (< 5 Acres)' | 'Woman Farmer' | 'SC / ST' | 'General / Medium';
  irrigationType: 'Drip / Sprinkler' | 'Canal' | 'Open Well / Borewell' | 'Rainfed';
}

export interface SchemeWizardResult extends GovtScheme {
  matchPercentage: number;
  matchReasonMr: string;
  matchReasonHi: string;
  matchReasonEn: string;
  applicationSteps: {
    stepNumber: number;
    titleMr: string;
    titleHi: string;
    titleEn: string;
    instructionMr: string;
    instructionHi: string;
    instructionEn: string;
  }[];
  audioExplanationMr: string;
  audioExplanationHi: string;
  audioExplanationEn: string;
}

export type DetailedGovtScheme = SchemeWizardResult;
export type DailyFarmTask = DailyFarmPlanTask;


