import React from 'react';
import { Home, Sprout, Scan, Mic, User } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const MobileBottomNav: React.FC = () => {
  const { activeTab, setActiveTab, openModal, language } = useApp();

  const getLabel = (id: string) => {
    switch (id) {
      case 'home':
        return language === 'mr' ? 'मुख्य' : language === 'hi' ? 'होम' : 'Home';
      case 'mycrop':
        return language === 'mr' ? 'माझे पीक' : language === 'hi' ? 'मेरी फसल' : 'My Crop';
      case 'diagnose':
        return language === 'mr' ? 'रोग निदान' : language === 'hi' ? 'रोग निदान' : 'Diagnose';
      case 'askai':
        return language === 'mr' ? 'विचारा AI' : language === 'hi' ? 'पूछें AI' : 'Ask AI';
      case 'profile':
        return language === 'mr' ? 'शेतकरी' : language === 'hi' ? 'किसान' : 'Profile';
      default:
        return id;
    }
  };

  const navButtons = [
    {
      id: 'home',
      label: getLabel('home'),
      icon: Home,
      action: () => setActiveTab('home'),
      isHighlight: false,
    },
    {
      id: 'mycrop',
      label: getLabel('mycrop'),
      icon: Sprout,
      action: () => setActiveTab('mycrop'),
      isHighlight: false,
    },
    {
      id: 'diagnose',
      label: getLabel('diagnose'),
      icon: Scan,
      action: () => openModal('diagnose'),
      isHighlight: false,
    },
    {
      id: 'askai',
      label: getLabel('askai'),
      icon: Mic,
      action: () => openModal('askAi'),
      isHighlight: true,
    },
    {
      id: 'profile',
      label: getLabel('profile'),
      icon: User,
      action: () => setActiveTab('profile'),
      isHighlight: false,
    },
  ];

  return (
    <nav
      id="mobile-bottom-navbar"
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#042014]/95 backdrop-blur-xl border-t border-emerald-500/20 px-2 py-1.5 shadow-2xl safe-area-pb"
    >
      <div className="flex items-center justify-around">
        {navButtons.map((item) => {
          const isCurrent = activeTab === item.id;
          const Icon = item.icon;

          if (item.isHighlight) {
            return (
              <button
                key={item.id}
                id={`mobile-bottom-btn-${item.id}`}
                onClick={item.action}
                aria-label={item.label}
                className="relative -top-4 flex flex-col items-center group cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 rounded-full"
              >
                <div className="relative w-13 h-13 rounded-full bg-gradient-to-tr from-emerald-600 via-emerald-500 to-teal-400 text-white flex items-center justify-center shadow-lg shadow-emerald-500/40 group-active:scale-95 transition-transform border-4 border-white dark:border-[#031b11]">
                  <Icon className="w-6 h-6 animate-pulse" />
                  <span className="absolute -top-1 -right-1 flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
                  </span>
                </div>
                <span className="text-[11px] font-black text-emerald-700 dark:text-emerald-300 mt-1">
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              id={`mobile-bottom-btn-${item.id}`}
              onClick={item.action}
              aria-label={item.label}
              className={`flex flex-col items-center py-1 px-3 min-w-[56px] min-h-[44px] justify-center rounded-2xl transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
                isCurrent
                  ? 'text-emerald-600 dark:text-emerald-400 font-black scale-105'
                  : 'text-zinc-500 dark:text-zinc-400 hover:text-emerald-700 dark:hover:text-emerald-300 font-medium'
              }`}
            >
              <Icon className={`w-5 h-5 ${isCurrent ? 'stroke-[2.5]' : 'stroke-2'}`} />
              <span className="text-[10px] mt-0.5 tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
