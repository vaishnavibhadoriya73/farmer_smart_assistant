import React from 'react';
import { motion } from 'motion/react';
import { Users, Scan, CheckCircle2, Headphones, TrendingUp, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const StatsSection: React.FC = () => {
  const { t } = useApp();

  const stats = [
    {
      id: 'stat-farmers',
      number: '50K+',
      label: t('farmersStatLabel'),
      subtext: 'Across 18 agricultural states',
      icon: Users,
      color: 'from-emerald-500 to-teal-500',
      badge: 'Active Network',
    },
    {
      id: 'stat-diagnoses',
      number: '10K+',
      label: t('diagnosesStatLabel'),
      subtext: '240+ plant pathogens recognized',
      icon: Scan,
      color: 'from-teal-500 to-emerald-600',
      badge: 'Real-time Scans',
    },
    {
      id: 'stat-accuracy',
      number: '95%',
      label: t('accuracyStatLabel'),
      subtext: 'Verified by ICAR & KVK field trials',
      icon: CheckCircle2,
      color: 'from-green-500 to-emerald-500',
      badge: 'AI Precision',
    },
    {
      id: 'stat-assistance',
      number: '24/7',
      label: t('assistanceStatLabel'),
      subtext: 'Hindi, Marathi, Punjabi, Telugu & more',
      icon: Headphones,
      color: 'from-purple-500 to-emerald-500',
      badge: 'Zero Downtime',
    },
  ];

  return (
    <section id="stats-section" className="relative py-12 sm:py-16 border-y border-emerald-500/15 bg-emerald-50/40 dark:bg-emerald-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Empowering Rural Prosperity</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-emerald-950 dark:text-white font-outfit">
            Proven Impact Across Indian Farmlands
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.id}
                id={item.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -4, transition: { duration: 0.2 } }}
                className="relative p-6 rounded-3xl bg-white/80 dark:bg-emerald-900/30 backdrop-blur-xl border border-emerald-500/20 shadow-lg shadow-emerald-950/5 hover:border-emerald-500/40 hover:shadow-emerald-500/10 transition-all group"
              >
                {/* Top Row: Icon & Badge */}
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${item.color} text-white flex items-center justify-center shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 border border-emerald-500/20">
                    {item.badge}
                  </span>
                </div>

                {/* Big Metric Display */}
                <div className="space-y-1">
                  <div className="text-3xl sm:text-4xl font-extrabold text-emerald-950 dark:text-emerald-50 font-outfit tracking-tight">
                    {item.number}
                  </div>
                  <div className="text-sm font-bold text-emerald-800 dark:text-emerald-200">
                    {item.label}
                  </div>
                  <p className="text-xs text-emerald-700/70 dark:text-emerald-400/70 pt-1 leading-relaxed">
                    {item.subtext}
                  </p>
                </div>

                {/* Decorative Bottom Bar */}
                <div className="mt-4 pt-3 border-t border-emerald-500/10 flex items-center justify-between text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
                  <span className="flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Real-time Verified</span>
                  </span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
