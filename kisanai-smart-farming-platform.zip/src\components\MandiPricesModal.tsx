import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Search,
  MapPin,
  X,
  RefreshCw,
  Sparkles,
  Volume2,
  VolumeX,
  ShieldCheck,
  Filter,
  BarChart2,
  Table as TableIcon,
  Calculator,
  ArrowUpDown,
  AlertCircle,
  Truck,
  CheckCircle,
  Clock,
  Landmark,
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { useApp } from '../context/AppContext';
import { useMandiPrices } from '../hooks/useMandiPrices';
import { marketService, MandiComparisonResult } from '../services/marketService';
import { INDIAN_STATES_AND_UTS } from '../data/indianStates';

export const MandiPricesModal: React.FC = () => {
  const { activeModal, closeModal, language, speakText, isSpeaking, stopSpeaking } = useApp();

  const [activeTab, setActiveTab] = useState<'liveTable' | 'trendAnalytics' | 'bestMarketCalc'>('liveTable');
  const [selectedCropForAnalytics, setSelectedCropForAnalytics] = useState<string>('Tomato');
  const [activeAudioId, setActiveAudioId] = useState<string | null>(null);

  // Hook connection
  const {
    rates,
    totalCount,
    lastUpdated,
    isLiveApi,
    source,
    isLoading,
    error,
    filters,
    autoRefresh,
    setAutoRefresh,
    updateFilters,
    retryFetch,
    getCropAnalytics
  } = useMandiPrices({
    sortBy: 'latestUpdate'
  });

  // Best Market Calculator Form State
  const [calcInput, setCalcInput] = useState({
    cropName: 'Tomato',
    quantityQuintals: 50,
    farmerDistrict: 'Nagpur',
    farmerState: 'Maharashtra',
    storageDays: 2,
    vehicleType: 'Mini Truck' as const
  });
  const [calcResults, setCalcResults] = useState<MandiComparisonResult[]>([]);

  // Open modal check (matches mandiPrices and mandi)
  if (activeModal !== 'mandiPrices' && activeModal !== 'mandi') {
    return null;
  }

  const handleSearch = (term: string) => {
    updateFilters({ searchCrop: term });
  };

  const handleStateFilter = (st: string) => {
    updateFilters({ state: st });
  };

  const handleCategoryFilter = (cat: string) => {
    updateFilters({ category: cat });
  };

  const handleSortChange = (sortByVal: any) => {
    updateFilters({ sortBy: sortByVal });
  };

  const handleRunBestMarketCalculator = () => {
    const results = marketService.calculateBestMandi({
      cropName: calcInput.cropName,
      quantityQuintals: calcInput.quantityQuintals,
      farmerDistrict: calcInput.farmerDistrict,
      farmerState: calcInput.farmerState,
      requiresStorageDays: calcInput.storageDays,
      transportVehicleType: calcInput.vehicleType
    });
    setCalcResults(results);
  };

  const handleSpeakItem = (item: any) => {
    if (activeAudioId === item.id && isSpeaking) {
      stopSpeaking();
      setActiveAudioId(null);
      return;
    }

    setActiveAudioId(item.id);
    const text = 
      language === 'mr'
        ? `${item.mandi} मंडीमध्ये ${item.cropName} चा आजचा सरासरी दर ₹${item.modalPrice} प्रति क्विंटल आहे.`
        : language === 'hi'
        ? `${item.mandi} मंडी में ${item.cropName} का आज का औसत भाव ₹${item.modalPrice} प्रति क्विंटल है।`
        : `${item.cropName} modal price in ${item.mandi} is ₹${item.modalPrice} per quintal.`;

    speakText(text, language);
  };

  const analyticsData = getCropAnalytics(selectedCropForAnalytics);
  const categoriesList = ['All', 'Grains', 'Pulses', 'Oilseeds', 'Cash Crops', 'Spices', 'Vegetables', 'Fruits'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-2 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-[#f4f7f5] border border-emerald-100 rounded-3xl w-full max-w-6xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-800"
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-emerald-100 bg-white">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-extrabold text-slate-900 tracking-wide font-outfit">
                  {language === 'mr' ? 'थेट एपीएमसी मंडी भाव' : language === 'hi' ? 'लाइव मंडी भाव डैशबोर्ड' : 'Live APMC Mandi Price Dashboard'}
                </h2>
                <span className={`px-2.5 py-0.5 text-xs font-bold rounded-full flex items-center space-x-1 ${
                  isLiveApi ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'
                }`}>
                  <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping inline-block" />
                  <span>{isLiveApi ? '🔴 LIVE APMC' : 'LATEST MARKET DATA'}</span>
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                {language === 'mr' ? 'सरकारी कृषी उत्पन्न बाजार समिती (APMC) आणि Agmarknet दर' : language === 'hi' ? 'आधिकारिक कृषि उपज मंडी (APMC) एवं e-NAM आंकड़े' : 'Official Agricultural Market (APMC & Agmarknet) Rates'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`px-3 py-1.5 text-xs font-bold rounded-xl border transition flex items-center space-x-1 cursor-pointer ${
                autoRefresh ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-slate-100 text-slate-600 border-slate-200'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${autoRefresh ? 'animate-spin' : ''}`} />
              <span>{autoRefresh ? 'Auto 10s' : 'Paused'}</span>
            </button>

            <button
              onClick={() => closeModal()}
              className="p-2 text-slate-400 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Live Status Fallback Banner if Live API is unavailable */}
        {!isLiveApi && (
          <div className="bg-amber-50 border-b border-amber-200 px-4 sm:px-6 py-2 text-xs text-amber-900 flex items-center justify-between font-medium">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-amber-700 shrink-0" />
              <span>
                <strong>Live API fallback – showing latest cached mandi data</strong> ({lastUpdated}) from {source}.
              </span>
            </div>
            <button onClick={retryFetch} className="underline text-amber-800 font-bold hover:text-slate-900 cursor-pointer">
              Try Live Sync
            </button>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-2.5 bg-white border-b border-emerald-100">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveTab('liveTable')}
              className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition flex items-center space-x-2 cursor-pointer ${
                activeTab === 'liveTable'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <TableIcon className="w-4 h-4" />
              <span>{language === 'mr' ? 'दर तक्ता' : language === 'hi' ? 'मंडी भाव तालिका' : 'Mandi Price Table'} ({rates.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('trendAnalytics')}
              className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition flex items-center space-x-2 cursor-pointer ${
                activeTab === 'trendAnalytics'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <BarChart2 className="w-4 h-4" />
              <span>{language === 'mr' ? 'भाव ट्रेंड आलेख' : language === 'hi' ? 'मूल्य रुझान चार्ट' : 'Price Trend Analytics'}</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('bestMarketCalc');
                handleRunBestMarketCalculator();
              }}
              className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition flex items-center space-x-2 cursor-pointer ${
                activeTab === 'bestMarketCalc'
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'bg-amber-100 text-amber-900 hover:bg-amber-200 border border-amber-300'
              }`}
            >
              <Calculator className="w-4 h-4 text-amber-800" />
              <span>{language === 'mr' ? 'उत्तम बाजार निवडा' : language === 'hi' ? 'सर्वश्रेष्ठ बाजार कैलकुलेटर' : 'Best Mandi Revenue'}</span>
            </button>
          </div>

          <div className="hidden sm:flex items-center space-x-2 text-xs font-bold text-slate-500">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Updated: {lastUpdated}</span>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          
          {/* TAB 1: MANDI PRICE TABLE */}
          {activeTab === 'liveTable' && (
            <div className="space-y-4">
              
              {/* Search, Filter & Sort Controls */}
              <div className="bg-white border border-emerald-100 rounded-2xl p-4 space-y-4 shadow-sm">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  
                  {/* Search Crop */}
                  <div className="relative md:col-span-2">
                    <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder={language === 'mr' ? 'पिक किंवा बाजार समिती शोधा...' : language === 'hi' ? 'फसल या मंडी का नाम खोजें...' : 'Search crop name, variety, mandi...'}
                      value={filters.searchCrop || ''}
                      onChange={(e) => handleSearch(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-emerald-200 rounded-xl text-sm font-bold text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  {/* State Filter (ALL 36 STATES & UTs) */}
                  <div>
                    <select
                      value={filters.state || 'All'}
                      onChange={(e) => handleStateFilter(e.target.value)}
                      className="w-full py-2.5 px-3 bg-slate-50 border border-emerald-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-600"
                    >
                      <option value="All">🇮🇳 All States ({INDIAN_STATES_AND_UTS.length})</option>
                      {INDIAN_STATES_AND_UTS.map((st) => (
                        <option key={st.code} value={st.name}>
                          {st.name} ({st.nameHi})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Sort By */}
                  <div className="flex items-center space-x-1 bg-slate-50 border border-emerald-200 rounded-xl px-3">
                    <ArrowUpDown className="w-4 h-4 text-slate-400" />
                    <select
                      value={filters.sortBy || 'latestUpdate'}
                      onChange={(e) => handleSortChange(e.target.value)}
                      className="w-full py-2.5 bg-transparent text-sm font-bold text-slate-900 focus:outline-none"
                    >
                      <option value="latestUpdate">Latest Update</option>
                      <option value="highestPrice">Highest Price (₹)</option>
                      <option value="lowestPrice">Lowest Price (₹)</option>
                      <option value="highestDemand">Highest Arrivals</option>
                    </select>
                  </div>

                </div>

                {/* Category Pills */}
                <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
                  <span className="text-xs text-slate-500 font-bold flex items-center space-x-1 shrink-0">
                    <Filter className="w-3.5 h-3.5" />
                    <span>Category:</span>
                  </span>
                  {categoriesList.map(cat => (
                    <button
                      key={cat}
                      onClick={() => handleCategoryFilter(cat)}
                      className={`px-3 py-1.5 text-xs rounded-xl font-bold whitespace-nowrap transition cursor-pointer border ${
                        (filters.category || 'All') === cat
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                          : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mandi Rates Table - Desktop Layout */}
              <div className="hidden md:block bg-white border border-emerald-100 rounded-2xl overflow-hidden shadow-sm">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-emerald-100 text-xs font-extrabold text-slate-600 uppercase tracking-wider">
                      <th className="py-3.5 px-4">Crop</th>
                      <th className="py-3.5 px-3">Variety</th>
                      <th className="py-3.5 px-3">State / District</th>
                      <th className="py-3.5 px-3">Mandi Market</th>
                      <th className="py-3.5 px-3 text-right">Min Price</th>
                      <th className="py-3.5 px-3 text-right">Max Price</th>
                      <th className="py-3.5 px-4 text-right">Modal Price</th>
                      <th className="py-3.5 px-3 text-right">Arrivals</th>
                      <th className="py-3.5 px-3 text-center">Trend</th>
                      <th className="py-3.5 px-4 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs text-slate-800">
                    {rates.map(item => (
                      <tr key={item.id} className="hover:bg-emerald-50/50 transition-colors">
                        
                        {/* Crop Name */}
                        <td className="py-3.5 px-4 font-bold text-slate-900">
                          <div className="flex items-center space-x-2">
                            <span className="p-1 bg-emerald-100 text-emerald-800 rounded-md">🌾</span>
                            <div>
                              <span>{item.cropName}</span>
                              <div className="text-[10px] text-slate-500 font-medium">{item.category}</div>
                            </div>
                          </div>
                        </td>

                        {/* Variety */}
                        <td className="py-3.5 px-3 text-slate-700 font-medium">
                          {item.variety}
                        </td>

                        {/* State / District */}
                        <td className="py-3.5 px-3">
                          <div className="font-bold text-slate-900">{item.state}</div>
                          <div className="text-[10px] text-slate-500">{item.district}</div>
                        </td>

                        {/* Mandi */}
                        <td className="py-3.5 px-3 font-bold text-emerald-800">
                          <div className="flex items-center space-x-1">
                            <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{item.mandi}</span>
                          </div>
                        </td>

                        {/* Min Price */}
                        <td className="py-3.5 px-3 text-right font-medium text-slate-600">
                          ₹{item.minPrice.toLocaleString('en-IN')}
                        </td>

                        {/* Max Price */}
                        <td className="py-3.5 px-3 text-right font-medium text-slate-700">
                          ₹{item.maxPrice.toLocaleString('en-IN')}
                        </td>

                        {/* Modal Price */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="text-sm font-black text-emerald-700">
                            ₹{item.modalPrice.toLocaleString('en-IN')}
                          </div>
                          <div className="text-[10px] text-slate-500">per Quintal</div>
                        </td>

                        {/* Arrivals */}
                        <td className="py-3.5 px-3 text-right font-medium text-slate-700">
                          {item.arrivalQuantityQuintals.toLocaleString('en-IN')} Qtl
                        </td>

                        {/* Trend */}
                        <td className="py-3.5 px-3 text-center">
                          <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[11px] font-extrabold ${
                            item.trend === 'up'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : item.trend === 'down'
                              ? 'bg-rose-100 text-rose-800 border border-rose-300'
                              : 'bg-slate-100 text-slate-600'
                          }`}>
                            {item.trend === 'up' ? <TrendingUp className="w-3 h-3" /> : item.trend === 'down' ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                            <span>{item.priceChange24hPercent > 0 ? `+${item.priceChange24hPercent}%` : `${item.priceChange24hPercent}%`}</span>
                          </span>
                        </td>

                        {/* Action */}
                        <td className="py-3.5 px-4 text-center">
                          <div className="flex items-center justify-center space-x-1">
                            <button
                              onClick={() => handleSpeakItem(item)}
                              className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer transition"
                              title="Voice Readout"
                            >
                              {activeAudioId === item.id && isSpeaking ? <VolumeX className="w-3.5 h-3.5 text-amber-600" /> : <Volume2 className="w-3.5 h-3.5 text-slate-600" />}
                            </button>
                            <button
                              onClick={() => {
                                setSelectedCropForAnalytics(item.cropName);
                                setActiveTab('trendAnalytics');
                              }}
                              className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg text-xs font-bold cursor-pointer transition"
                              title="View Price Analytics Chart"
                            >
                              <BarChart2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>

                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Responsive Cards */}
              <div className="md:hidden space-y-3">
                {rates.map(item => (
                  <div key={item.id} className="bg-white border border-emerald-100 rounded-2xl p-4 space-y-3 shadow-xs">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-sm font-extrabold text-slate-900">{item.cropName}</span>
                        <p className="text-[11px] text-slate-500 font-medium">{item.variety} • {item.mandi}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-base font-black text-emerald-700">₹{item.modalPrice.toLocaleString('en-IN')}</div>
                        <span className={`text-[10px] font-bold ${item.trend === 'up' ? 'text-emerald-700' : 'text-rose-600'}`}>
                          {item.priceChange24hPercent > 0 ? `+${item.priceChange24hPercent}%` : `${item.priceChange24hPercent}%`}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-[11px] bg-slate-50 p-2.5 rounded-xl text-slate-700 text-center font-medium border border-slate-100">
                      <div>Min: <strong className="text-slate-900">₹{item.minPrice}</strong></div>
                      <div>Max: <strong className="text-slate-900">₹{item.maxPrice}</strong></div>
                      <div>Arrivals: <strong className="text-slate-900">{item.arrivalQuantityQuintals} Qtl</strong></div>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* TAB 2: PRICE TREND ANALYTICS */}
          {activeTab === 'trendAnalytics' && (
            <div className="space-y-6">
              <div className="bg-white border border-emerald-100 rounded-3xl p-6 space-y-6 shadow-xs">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 font-outfit">
                      <BarChart2 className="w-5 h-5 text-emerald-600" />
                      <span>{analyticsData.cropName} ({analyticsData.variety}) Price Analytics</span>
                    </h3>
                    <p className="text-xs text-slate-500 font-medium">7-Day & 30-Day APMC mandi price history analysis & trend indicators.</p>
                  </div>

                  <select
                    value={selectedCropForAnalytics}
                    onChange={(e) => setSelectedCropForAnalytics(e.target.value)}
                    className="py-2 px-3 bg-slate-50 border border-emerald-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none"
                  >
                    <option value="Tomato">Tomato (टमाटर)</option>
                    <option value="Cotton (Kapas)">Cotton (कापूस)</option>
                    <option value="Soybean">Soybean (सोयाबीन)</option>
                    <option value="Wheat">Wheat (गहू)</option>
                    <option value="Onion">Onion (कांदा)</option>
                    <option value="Turmeric (Haldi)">Turmeric (हळद)</option>
                  </select>
                </div>

                {/* Key Metric Highlights */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-1">
                    <span className="text-xs text-slate-500 font-medium">Current Modal Price</span>
                    <div className="text-xl font-black text-emerald-700">₹{analyticsData.currentModalPrice.toLocaleString('en-IN')}</div>
                    <span className="text-[10px] text-slate-500">per Quintal</span>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-1">
                    <span className="text-xs text-slate-500 font-medium">24h Price Change</span>
                    <div className={`text-xl font-black flex items-center space-x-1 ${analyticsData.priceChangePercent > 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                      {analyticsData.priceChangePercent > 0 ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                      <span>{analyticsData.priceChangePercent > 0 ? `+${analyticsData.priceChangePercent}%` : `${analyticsData.priceChangePercent}%`}</span>
                    </div>
                    <span className="text-[10px] text-slate-500">vs Yesterday (₹{analyticsData.yesterdayModalPrice})</span>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-1">
                    <span className="text-xs text-slate-500 font-medium">Highest Price Mandi</span>
                    <div className="text-sm font-bold text-slate-900 truncate">{analyticsData.highestPriceMandi.mandiName}</div>
                    <span className="text-xs font-extrabold text-amber-700">₹{analyticsData.highestPriceMandi.modalPrice.toLocaleString('en-IN')} / Qtl</span>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-1">
                    <span className="text-xs text-slate-500 font-medium">7-Day Price Trend</span>
                    <div className="text-sm font-bold text-emerald-800">
                      {analyticsData.trend === 'up' ? '📈 Price Increasing' : analyticsData.trend === 'down' ? '📉 Price Decreasing' : '➡ Stable Market'}
                    </div>
                    <span className="text-[10px] text-slate-500">Demand Rising</span>
                  </div>

                </div>

                {/* 7-Day Price Recharts Graph */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-emerald-800 uppercase tracking-wider">7-Day APMC Modal Price Trend (₹/Quintal)</h4>
                  <div className="h-64 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={analyticsData.weeklyTrend7Days}>
                        <defs>
                          <linearGradient id="priceGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#059669" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#059669" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                        <XAxis dataKey="date" stroke="#64748b" fontSize={12} />
                        <YAxis stroke="#64748b" fontSize={12} domain={['auto', 'auto']} />
                        <Tooltip
                          contentStyle={{ backgroundColor: '#ffffff', borderColor: '#059669', borderRadius: '0.75rem' }}
                          formatter={(val: any) => [`₹${val}`, 'Modal Price']}
                        />
                        <Area type="monotone" dataKey="modalPrice" stroke="#059669" strokeWidth={3} fillOpacity={1} fill="url(#priceGrad)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 3: BEST MANDI NET REVENUE CALCULATOR */}
          {activeTab === 'bestMarketCalc' && (
            <div className="space-y-6">
              <div className="bg-white border border-emerald-100 rounded-3xl p-6 space-y-6 shadow-xs">
                
                <div className="space-y-1">
                  <div className="inline-flex items-center space-x-2 px-3 py-1 bg-amber-100 text-amber-900 rounded-full text-xs font-bold border border-amber-300">
                    <Calculator className="w-3.5 h-3.5" />
                    <span>Net Revenue Engine</span>
                  </div>
                  <h2 className="text-xl font-extrabold text-slate-900 font-outfit">Best Mandi Recommendation Calculator</h2>
                  <p className="text-xs text-slate-500 font-medium">Formula: <code>Net Revenue = (Quantity × Modal Price) − Transportation Cost − Storage Cost</code></p>
                </div>

                {/* Calculator Inputs */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  
                  <div>
                    <label className="text-xs text-slate-700 font-bold block mb-1">Crop Name</label>
                    <input
                      type="text"
                      value={calcInput.cropName}
                      onChange={(e) => setCalcInput({ ...calcInput, cropName: e.target.value })}
                      className="w-full p-2.5 bg-white border border-emerald-200 rounded-xl text-xs font-bold text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-700 font-bold block mb-1">Quantity (Quintals)</label>
                    <input
                      type="number"
                      value={calcInput.quantityQuintals}
                      onChange={(e) => setCalcInput({ ...calcInput, quantityQuintals: Number(e.target.value) || 10 })}
                      className="w-full p-2.5 bg-white border border-emerald-200 rounded-xl text-xs font-bold text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-700 font-bold block mb-1">Your Location District</label>
                    <input
                      type="text"
                      value={calcInput.farmerDistrict}
                      onChange={(e) => setCalcInput({ ...calcInput, farmerDistrict: e.target.value })}
                      className="w-full p-2.5 bg-white border border-emerald-200 rounded-xl text-xs font-bold text-slate-900"
                    />
                  </div>

                  <div className="sm:col-span-3 pt-2">
                    <button
                      onClick={handleRunBestMarketCalculator}
                      className="w-full py-3.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl shadow-md transition flex items-center justify-center space-x-2 text-sm cursor-pointer"
                    >
                      <Calculator className="w-4 h-4" />
                      <span>Calculate & Compare Mandis</span>
                    </button>
                  </div>

                </div>

                {/* Mandi Net Revenue Results */}
                {calcResults.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="text-sm font-extrabold text-slate-900">Mandi Net Earning Comparison</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {calcResults.map((r, idx) => (
                        <div
                          key={idx}
                          className={`rounded-2xl p-5 border transition space-y-3 ${
                            r.isRecommended
                              ? 'bg-gradient-to-b from-amber-50 to-white border-amber-400 shadow-md'
                              : 'bg-slate-50 border-slate-200'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-sm font-bold text-slate-900">{r.mandiName}</span>
                              <p className="text-[11px] text-slate-500 font-medium">{r.district}, {r.state} ({r.distanceKm} km away)</p>
                            </div>
                            {r.isRecommended && (
                              <span className="px-3 py-1 bg-amber-400 text-slate-950 font-extrabold rounded-full text-xs shadow-xs">
                                🏆 RECOMMENDED MANDI
                              </span>
                            )}
                          </div>

                          <div className="grid grid-cols-3 gap-2 bg-white p-3 rounded-xl text-center text-xs border border-slate-200/70 font-medium">
                            <div>
                              <span className="text-[10px] text-slate-500 block">Gross Sales</span>
                              <strong className="text-slate-900">₹{r.grossRevenue.toLocaleString('en-IN')}</strong>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-500 block">Transport Cost</span>
                              <strong className="text-rose-600">-₹{r.estimatedFreightCost.toLocaleString('en-IN')}</strong>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-500 block">Storage Cost</span>
                              <strong className="text-amber-700">-₹{r.estimatedStorageCost.toLocaleString('en-IN')}</strong>
                            </div>
                          </div>

                          <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                            <span className="text-xs font-bold text-slate-700">Net Expected Revenue:</span>
                            <span className="text-lg font-black text-emerald-700">
                              ₹{r.netExpectedRevenue.toLocaleString('en-IN')}
                            </span>
                          </div>

                          {r.isRecommended && (
                            <p className="text-xs text-amber-900 bg-amber-100/70 p-2.5 rounded-xl border border-amber-300 leading-relaxed font-medium">
                              💡 <strong>Reason:</strong> {r.recommendationReasonEn}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            </div>
          )}

        </div>
      </motion.div>
    </div>
  );
};
