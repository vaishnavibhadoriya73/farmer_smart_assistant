import React from 'react';
import { motion } from 'motion/react';
import {
  User,
  MapPin,
  Phone,
  ShieldCheck,
  Award,
  CreditCard,
  Droplets,
  Layers,
  Sparkles,
  QrCode,
  CheckCircle,
  LogOut,
  UserPlus,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const FarmerProfileView: React.FC = () => {
  const {
    farmer,
    crops,
    openModal,
    logoutFarmer,
    restartOnboarding,
    language,
    firebaseUser,
    diagnosesHistory,
    predictionsHistory,
  } = useApp();

  return (
    <div id="farmer-profile-view" className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Digital Kisan ID Card */}
      <div className="relative p-6 sm:p-8 rounded-3xl bg-gradient-to-tr from-emerald-900 via-emerald-800 to-teal-900 text-white border border-emerald-500/40 shadow-2xl overflow-hidden">
        {/* Ambient Decorative Shapes */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-400/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="relative">
              <img
                src={farmer.avatarUrl}
                alt={farmer.fullName}
                referrerPolicy="no-referrer"
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl object-cover border-2 border-emerald-400/50 shadow-lg"
              />
              <span className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-emerald-500 text-white border-2 border-emerald-900">
                <CheckCircle className="w-3.5 h-3.5" />
              </span>
            </div>

            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-white/15 text-[11px] font-bold text-emerald-200 border border-white/20">
                <Award className="w-3.5 h-3.5 text-amber-300" />
                <span>ICAR Certified Progressive Farmer</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-outfit">
                {farmer.fullName}
              </h2>
              <p className="text-xs sm:text-sm text-emerald-200/90 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                <span>{farmer.village}, {farmer.district}, {farmer.state}</span>
              </p>
              <div className="flex flex-wrap items-center gap-3 text-xs font-mono text-emerald-300 pt-1">
                <span>Kisan ID: <strong className="text-white">{farmer.kisanId}</strong></span>
                <span>•</span>
                <span className="inline-flex items-center gap-1 text-emerald-200">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Cloud Synced ({firebaseUser?.email ? 'Google Auth' : 'Phone Verified'})
                </span>
              </div>
            </div>
          </div>

          {/* QR Code & KCC Credit Limit */}
          <div className="flex sm:flex-col items-center sm:items-end justify-between gap-3 p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 bg-white rounded-xl p-1.5 flex items-center justify-center text-emerald-950">
                <QrCode className="w-full h-full text-emerald-950" />
              </div>
              <div>
                <span className="text-[10px] text-emerald-200 block uppercase font-semibold">Kisan Card QR</span>
                <span className="text-xs font-bold text-white">e-KYC Verified</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-emerald-200 block">Active KCC Limit</span>
              <span className="text-sm sm:text-base font-extrabold text-amber-300 font-mono">
                ₹3,50,000
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Cloud Persistence Summary */}
      <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/20 flex flex-wrap items-center justify-between gap-3 text-xs text-emerald-200">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-bold text-white">Firebase Firestore Cloud Sync:</span>
          <span>Active</span>
        </div>
        <div className="flex items-center gap-4 text-emerald-300">
          <span>🌾 <strong>{crops.length}</strong> Crop Plots</span>
          <span>🔬 <strong>{diagnosesHistory.length}</strong> Disease Scans</span>
          <span>📊 <strong>{predictionsHistory.length}</strong> AI Predictions</span>
        </div>
      </div>

      {/* Farm Land & Agronomic Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
            <Layers className="w-4 h-4 text-emerald-500" />
            <span>Land Holding</span>
          </div>
          <div className="text-2xl font-extrabold text-emerald-950 dark:text-white font-outfit">
            {farmer.totalLandAcres} Acres
          </div>
          <p className="text-xs text-zinc-500 dark:text-zinc-400">
            Soil: <strong>{farmer.soilType}</strong> (High fertility, organic carbon: 0.55%)
          </p>
        </div>

        <div className="p-6 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
            <Droplets className="w-4 h-4 text-teal-500" />
            <span>Irrigation Setup</span>
          </div>
          <div className="text-2xl font-extrabold text-emerald-950 dark:text-white font-outfit">
            {farmer.irrigationType}
          </div>
          <p className="text-xs text-zinc-500 dark:text-zinc-400">
            Solar Pump: 5HP PM-KUSUM Grid connected with automatic timer
          </p>
        </div>

        <div className="p-6 rounded-3xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
            <CreditCard className="w-4 h-4 text-amber-500" />
            <span>PM-KISAN DBT</span>
          </div>
          <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 font-outfit">
            18th Installment
          </div>
          <p className="text-xs text-zinc-500 dark:text-zinc-400">
            Status: Credited to SBI A/c ending in •••• 8821
          </p>
        </div>
      </div>

      {/* Quick Profile Actions */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => openModal('soilHealth')}
          className="px-5 py-3 rounded-2xl bg-emerald-50 dark:bg-emerald-900/40 text-emerald-900 dark:text-emerald-100 border border-emerald-500/30 text-xs font-bold hover:bg-emerald-600 hover:text-white transition-all cursor-pointer"
        >
          View Soil Health Card
        </button>

        <button
          onClick={() => openModal('schemes')}
          className="px-5 py-3 rounded-2xl bg-emerald-50 dark:bg-emerald-900/40 text-emerald-900 dark:text-emerald-100 border border-emerald-500/30 text-xs font-bold hover:bg-emerald-600 hover:text-white transition-all cursor-pointer"
        >
          Check Scheme Eligibility
        </button>

        <button
          onClick={() => openModal('askAi')}
          className="px-5 py-3 rounded-2xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-500 transition-all cursor-pointer shadow-md"
        >
          Consult KisanAI Agronomist
        </button>

        <button
          onClick={restartOnboarding}
          className="px-5 py-3 rounded-2xl bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-500/30 text-xs font-bold hover:bg-amber-500 hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>{language === 'mr' ? 'नवीन शेतकरी नोंदणी' : 'New Farmer Registration'}</span>
        </button>

        <button
          onClick={logoutFarmer}
          className="px-5 py-3 rounded-2xl bg-rose-500/15 text-rose-800 dark:text-rose-300 border border-rose-500/30 text-xs font-bold hover:bg-rose-500 hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>{language === 'mr' ? 'लॉगआउट (Logout)' : 'Logout'}</span>
        </button>
      </div>
    </div>
  );
};
