import React from 'react';
import { motion } from 'motion/react';
import { Bell, X, CloudRain, TrendingUp, Sprout, Landmark, Truck } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const NotificationCenterModal: React.FC = () => {
  const { activeModal, closeModal, language, openModal } = useApp();

  if (activeModal !== 'notifications') return null;

  const notificationItems = [
    {
      id: 'n1',
      type: 'rain',
      titleEn: 'Rain Warning for Tomorrow',
      titleHi: 'कल के लिए बारिश की चेतावनी',
      titleMr: 'उद्या पावसाचा इशारा',
      descEn: 'Heavy rain predicted in your district. Consider delaying pesticide spray & irrigation.',
      descHi: 'आपके जिले में भारी बारिश का अनुमान। कीटनाशक छिड़काव रोकें।',
      descMr: 'तुमच्या जिल्ह्यात मुसळधार पावसाचा अंदाज. फवारणी पुढे ढकला.',
      timeAgo: '10 min ago',
      actionModal: 'weatherAdvisory' as const,
      actionTextEn: 'View Radar',
      actionTextHi: 'रडार देखें',
      actionTextMr: 'अंदाज पहा'
    },
    {
      id: 'n2',
      type: 'price',
      titleEn: 'Tomato Market Price Up +12%',
      titleHi: 'टमाटर मंडी भाव में +12% उछाल',
      titleMr: 'टोमॅटो दरात +१२% वाढ',
      descEn: 'Nagpur Kalamna APMC reached ₹2,800/quintal. Recommended window to sell.',
      descHi: 'नागपुर कलमना मंडी में ₹2,800/क्विंटल भाव। बेचने का सही समय।',
      descMr: 'कलमना एपीएमसीमध्ये ₹२,८०० दर. माल विक्रीसाठी उत्तम वेळ.',
      timeAgo: '2 hours ago',
      actionModal: 'mandiPrices' as const,
      actionTextEn: 'View Rates',
      actionTextHi: 'भाव देखें',
      actionTextMr: 'दर पहा'
    },
    {
      id: 'n3',
      type: 'scheme',
      titleEn: 'New Drip Irrigation 80% Subsidy Open',
      titleHi: 'ड्रिप सिंचाई पर 80% सब्सिडी शुरू',
      titleMr: 'ठिबक सिंचनावर ८०% नवीन अनुदान सुरू',
      descEn: 'MahaDBT PMKSY micro-irrigation portal is accepting applications for Kharif season.',
      descHi: 'पीएमकेएसवाई ड्रिप सब्सिडी पोर्टल पर नए आवेदन शुरू।',
      descMr: 'MahaDBT पोर्टलवर ठिबक सिंचनासाठी नवीन अर्ज सुरू.',
      timeAgo: 'Yesterday',
      actionModal: 'schemes' as const,
      actionTextEn: 'View Scheme',
      actionTextHi: 'योजना देखें',
      actionTextMr: 'योजना पहा'
    },
    {
      id: 'n4',
      type: 'shipment',
      titleEn: 'Shipment #SHIP-2026-9041 In Transit',
      titleHi: 'शिपमेंट #SHIP-2026-9041 रास्ते में है',
      titleMr: 'शिपमेंट #SHIP-2026-9041 वाहतूक सुरू',
      descEn: 'Your 50 Quintal Cotton shipment reached Nagpur Highway Toll Plaza.',
      descHi: 'आपकी 50 क्विंटल कपास की गाड़ी हाईवे पर है।',
      descMr: 'तुमची ५० क्विंटल कापसाची वाहतूक नागपूर हायवेवर पोहोचली आहे.',
      timeAgo: '3 hours ago',
      actionModal: 'supplyChain' as const,
      actionTextEn: 'Track Shipment',
      actionTextHi: 'ट्रैक करें',
      actionTextMr: 'ट्रॅक करा'
    }
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'rain': return <CloudRain className="w-5 h-5 text-sky-600" />;
      case 'price': return <TrendingUp className="w-5 h-5 text-emerald-600" />;
      case 'scheme': return <Landmark className="w-5 h-5 text-amber-600" />;
      case 'shipment': return <Truck className="w-5 h-5 text-purple-600" />;
      default: return <Sprout className="w-5 h-5 text-teal-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white border border-emerald-100 rounded-3xl w-full max-w-lg p-6 shadow-2xl space-y-4 text-slate-800"
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl border border-emerald-200">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                {language === 'mr' ? 'सूचना केंद्र' : language === 'hi' ? 'सूचना केंद्र' : 'Notification Center'}
              </h3>
              <p className="text-xs text-slate-500">
                {language === 'mr' ? 'हवामान, बाजारभाव, योजना व वाहतूक अपडेट्स' : 'Weather, Price, Scheme & Supply Chain Alerts'}
              </p>
            </div>
          </div>
          <button onClick={() => closeModal()} className="p-1.5 bg-slate-100 text-slate-500 hover:text-slate-900 rounded-lg">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
          {notificationItems.map(item => (
            <div key={item.id} className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-2 hover:border-emerald-300 transition">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-white rounded-xl shadow-xs border border-slate-100">
                    {getIcon(item.type)}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      {language === 'mr' ? item.titleMr : language === 'hi' ? item.titleHi : item.titleEn}
                    </h4>
                    <span className="text-[10px] text-slate-500">{item.timeAgo}</span>
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-600 pl-11">
                {language === 'mr' ? item.descMr : language === 'hi' ? item.descHi : item.descEn}
              </p>

              <div className="pt-1 pl-11 flex items-center justify-between">
                <button
                  onClick={() => {
                    closeModal();
                    openModal(item.actionModal);
                  }}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-xs transition"
                >
                  {language === 'mr' ? item.actionTextMr : language === 'hi' ? item.actionTextHi : item.actionTextEn} →
                </button>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};
