import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { WifiOff, RefreshCw, Wifi, AlertTriangle } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const OfflineNetworkBanner: React.FC = () => {
  const { language } = useApp();
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine);
  const [isRetrying, setIsRetrying] = useState<boolean>(false);
  const [showReconnectedBanner, setShowReconnectedBanner] = useState<boolean>(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      setShowReconnectedBanner(true);
      setTimeout(() => setShowReconnectedBanner(false), 3500);
    };

    const handleOffline = () => {
      setIsOffline(true);
      setShowReconnectedBanner(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleManualRetry = () => {
    setIsRetrying(true);
    // Ping health endpoint to test live connectivity
    fetch('/api/health')
      .then((res) => {
        if (res.ok) {
          setIsOffline(false);
          setShowReconnectedBanner(true);
          setTimeout(() => setShowReconnectedBanner(false), 3000);
        }
      })
      .catch(() => {
        // Still offline
      })
      .finally(() => {
        setTimeout(() => setIsRetrying(false), 800);
      });
  };

  const getOfflineText = () => {
    if (language === 'mr') {
      return 'इंटरनेट कनेक्शन कमी आहे. आम्ही पुन्हा प्रयत्न करत आहोत.';
    } else if (language === 'hi') {
      return 'इंटरनेट कनेक्शन धीमा है। हम पुनः प्रयास कर रहे हैं।';
    } else {
      return 'Low internet connection. Retrying automatically...';
    }
  };

  const getReconnectedText = () => {
    if (language === 'mr') {
      return 'इंटरनेट पूर्ववत सुरू झाले! सर्व माहिती अपडेट केली आहे.';
    } else if (language === 'hi') {
      return 'इंटरनेट पुनः कनेक्ट हो गया! डेटा अपडेट कर दिया गया है।';
    } else {
      return 'Back Online! Live farm data refreshed.';
    }
  };

  return (
    <AnimatePresence>
      {isOffline && (
        <motion.div
          id="offline-network-banner"
          initial={{ opacity: 0, y: -40 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -40 }}
          className="fixed top-0 left-0 right-0 z-[100] bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white px-4 py-2.5 shadow-xl border-b border-amber-400/30 flex items-center justify-between text-xs sm:text-sm font-bold"
        >
          <div className="flex items-center gap-2.5 max-w-4xl mx-auto w-full justify-between">
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-lg bg-black/20">
                <WifiOff className="w-4 h-4 text-amber-200 animate-pulse" />
              </span>
              <span className="leading-tight tracking-tight">
                {getOfflineText()}
              </span>
            </div>

            <button
              onClick={handleManualRetry}
              disabled={isRetrying}
              className="px-3 py-1 rounded-xl bg-white/20 hover:bg-white/30 active:scale-95 text-white text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer shrink-0 border border-white/20"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRetrying ? 'animate-spin' : ''}`} />
              <span>{language === 'mr' ? 'पुन्हा प्रयत्न करा' : language === 'hi' ? 'पुनः प्रयास करें' : 'Retry'}</span>
            </button>
          </div>
        </motion.div>
      )}

      {showReconnectedBanner && (
        <motion.div
          id="reconnected-network-banner"
          initial={{ opacity: 0, y: -40 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -40 }}
          className="fixed top-0 left-0 right-0 z-[100] bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-4 py-2.5 shadow-xl border-b border-emerald-400/30 flex items-center justify-center text-xs sm:text-sm font-bold"
        >
          <div className="flex items-center gap-2">
            <Wifi className="w-4 h-4 text-emerald-200" />
            <span>{getReconnectedText()}</span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
