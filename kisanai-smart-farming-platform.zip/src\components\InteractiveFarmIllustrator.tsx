import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Scan, Droplets, CloudSun, Radio, Cpu, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const InteractiveFarmIllustrator: React.FC = () => {
  const { openModal } = useApp();
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);

  const hotspots = [
    {
      id: 'drone',
      title: 'Multispectral AI Drone',
      desc: 'Scanning NDVI canopy chlorophyll levels & heat stress.',
      x: '25%',
      y: '22%',
      icon: Scan,
      action: () => openModal('diagnose'),
    },
    {
      id: 'iot',
      title: 'IoT Soil Sensor Node',
      desc: 'Measuring root-zone NPK & volumetric moisture (44%).',
      x: '72%',
      y: '68%',
      icon: Droplets,
      action: () => openModal('soilHealth'),
    },
    {
      id: 'weather',
      title: 'Micro-Weather Radar',
      desc: 'Zero rain risk for 48h. Safe for foliar spray.',
      x: '78%',
      y: '20%',
      icon: CloudSun,
      action: () => openModal('weatherAdvisory'),
    },
  ];

  return (
    <div
      id="interactive-farm-illustration"
      className="relative w-full aspect-[4/3] sm:aspect-[16/10] rounded-3xl overflow-hidden border border-emerald-500/20 bg-gradient-to-b from-emerald-950 via-emerald-900 to-[#062416] p-4 sm:p-6 shadow-2xl shadow-emerald-950/40 select-none group"
    >
      {/* Background Animated Sky & Sun */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Glowing Sun / Atmosphere */}
        <motion.div
          animate={{ scale: [1, 1.08, 1], opacity: [0.7, 0.9, 0.7] }}
          transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -top-16 -right-16 w-64 h-64 rounded-full bg-gradient-to-br from-amber-300/40 via-emerald-400/20 to-transparent blur-3xl"
        />

        {/* Ambient Neural Grid */}
        <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px] opacity-20" />

        {/* Floating Clouds */}
        <motion.div
          animate={{ x: [-40, 40, -40] }}
          transition={{ duration: 24, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute top-8 left-12 w-32 h-10 rounded-full bg-white/10 blur-md"
        />
        <motion.div
          animate={{ x: [30, -30, 30] }}
          transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute top-16 right-24 w-40 h-12 rounded-full bg-white/10 blur-md"
        />
      </div>

      {/* SVG Farm Landscape Art */}
      <svg
        viewBox="0 0 800 500"
        className="w-full h-full relative z-10 filter drop-shadow-md"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Gradients */}
          <linearGradient id="hillGrad1" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#0d4a2d" />
            <stop offset="100%" stopColor="#052817" />
          </linearGradient>
          <linearGradient id="hillGrad2" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#064e3b" />
          </linearGradient>
          <linearGradient id="terraceGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#047857" />
            <stop offset="50%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#059669" />
          </linearGradient>
          <linearGradient id="scanBeam" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#34d399" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="farmerGlow" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#6ee7b7" />
            <stop offset="100%" stopColor="#047857" />
          </linearGradient>
        </defs>

        {/* Distant Rolling Terraces / Mountains */}
        <path
          d="M 0,280 Q 200,210 400,260 T 800,240 L 800,500 L 0,500 Z"
          fill="url(#hillGrad1)"
          opacity="0.85"
        />

        {/* Terraced Crops & Crop Furrows */}
        <path
          d="M 0,330 Q 220,270 450,320 T 800,300 L 800,500 L 0,500 Z"
          fill="url(#hillGrad2)"
          opacity="0.9"
        />

        {/* Dynamic Contour lines / Smart Irrigation Drip Pipes */}
        <g stroke="#34d399" strokeWidth="1.5" strokeDasharray="6,6" opacity="0.4">
          <path d="M 50,360 Q 250,310 500,350 T 800,340" />
          <path d="M 0,400 Q 230,350 480,390 T 800,380" />
          <path d="M 20,440 Q 280,390 520,430 T 800,420" />
        </g>

        {/* Farm Field Plant Rows / Golden Wheat & Emerald Stalks */}
        <g>
          {[
            { x: 120, y: 390, h: 28, c: '#6ee7b7' },
            { x: 140, y: 395, h: 32, c: '#34d399' },
            { x: 160, y: 388, h: 26, c: '#fcd34d' },
            { x: 180, y: 392, h: 30, c: '#34d399' },
            { x: 200, y: 385, h: 34, c: '#6ee7b7' },
            { x: 220, y: 390, h: 28, c: '#fcd34d' },

            { x: 340, y: 410, h: 36, c: '#34d399' },
            { x: 365, y: 415, h: 40, c: '#6ee7b7' },
            { x: 390, y: 408, h: 38, c: '#fcd34d' },
            { x: 415, y: 412, h: 42, c: '#34d399' },
            { x: 440, y: 418, h: 35, c: '#6ee7b7' },

            { x: 540, y: 430, h: 44, c: '#34d399' },
            { x: 570, y: 435, h: 48, c: '#fcd34d' },
            { x: 600, y: 428, h: 42, c: '#6ee7b7' },
            { x: 630, y: 432, h: 46, c: '#34d399' },
            { x: 660, y: 438, h: 40, c: '#fcd34d' },
          ].map((plant, idx) => (
            <g key={idx} transform={`translate(${plant.x}, ${plant.y})`}>
              <path
                d={`M 0,0 Q -4,-${plant.h / 2} 0,-${plant.h} Q 4,-${plant.h / 2} 0,0`}
                fill={plant.c}
                opacity="0.9"
              />
              <circle cx="0" cy={-plant.h} r="3" fill="#fbbf24" opacity="0.9" />
            </g>
          ))}
        </g>

        {/* AI Drone with Scanning Cone */}
        <g transform="translate(200, 110)">
          {/* Scan Cone */}
          <polygon points="0,15 -70,180 70,180" fill="url(#scanBeam)" opacity="0.35" />
          <line x1="-70" y1="180" x2="70" y2="180" stroke="#6ee7b7" strokeWidth="2" opacity="0.8" />

          {/* Drone Body */}
          <rect x="-18" y="-6" width="36" height="12" rx="6" fill="#047857" stroke="#34d399" strokeWidth="1.5" />
          <circle cx="0" cy="0" r="4" fill="#34d399" />
          <line x1="-28" y1="0" x2="28" y2="0" stroke="#a7f3d0" strokeWidth="2" />
          {/* Rotors */}
          <circle cx="-28" cy="0" r="8" stroke="#34d399" strokeWidth="1" fill="none" opacity="0.8" />
          <circle cx="28" cy="0" r="8" stroke="#34d399" strokeWidth="1" fill="none" opacity="0.8" />
        </g>

        {/* Farmer with AI Digital Tablet & Smart Hat */}
        <g transform="translate(100, 310)">
          {/* Farmer Hat (Traditional Pagadi / Straw Hat stylized) */}
          <ellipse cx="25" cy="-28" rx="20" ry="6" fill="#f59e0b" />
          <circle cx="25" cy="-32" r="10" fill="#d97706" />

          {/* Body / Kurta */}
          <path d="M 12,-18 L 38,-18 L 44,45 L 6,45 Z" fill="#ecfdf5" stroke="#10b981" strokeWidth="1.5" />

          {/* Arms holding AI Tablet */}
          <path d="M 8,-8 L 22,12 L 28,12" stroke="#ecfdf5" strokeWidth="4" strokeLinecap="round" />
          <path d="M 42,-8 L 28,12" stroke="#ecfdf5" strokeWidth="4" strokeLinecap="round" />

          {/* AI Tablet Device Glowing */}
          <rect x="20" y="4" width="16" height="22" rx="3" fill="#022c22" stroke="#34d399" strokeWidth="1.5" />
          <rect x="23" y="7" width="10" height="12" rx="1" fill="#10b981" />
          <circle cx="28" cy="22" r="1.5" fill="#a7f3d0" />

          {/* WiFi / Telemetry Rays from Tablet to Cloud */}
          <path
            d="M 28,2 Q 40,-40 90,-90"
            fill="none"
            stroke="#34d399"
            strokeWidth="1.5"
            strokeDasharray="4,4"
            opacity="0.6"
          />
        </g>

        {/* IoT Soil Moisture Probe Node */}
        <g transform="translate(580, 340)">
          {/* Pole */}
          <line x1="0" y1="-20" x2="0" y2="40" stroke="#047857" strokeWidth="3" />
          {/* Sensor Solar Top */}
          <polygon points="-10,-20 10,-20 14,-28 -14,-28" fill="#065f46" stroke="#34d399" strokeWidth="1" />
          {/* Antenna */}
          <line x1="0" y1="-28" x2="0" y2="-40" stroke="#6ee7b7" strokeWidth="1.5" />
          <circle cx="0" cy="-40" r="2.5" fill="#f59e0b" />
          {/* Signal rings */}
          <circle cx="0" cy="-40" r="8" fill="none" stroke="#34d399" strokeWidth="1" opacity="0.6" />
          <circle cx="0" cy="-40" r="16" fill="none" stroke="#34d399" strokeWidth="0.7" opacity="0.3" />
        </g>

        {/* Weather Radar Station */}
        <g transform="translate(680, 150)">
          <line x1="0" y1="0" x2="0" y2="50" stroke="#065f46" strokeWidth="2.5" />
          <circle cx="0" cy="0" r="12" fill="#064e3b" stroke="#34d399" strokeWidth="1.5" />
          <path d="M -8,-2 Q 0,-10 8,-2" stroke="#fbbf24" strokeWidth="2" fill="none" />
          <circle cx="0" cy="0" r="3" fill="#34d399" />
        </g>
      </svg>

      {/* Interactive Overlaid Badges & AI HUD */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-950/80 backdrop-blur-md border border-emerald-500/30 text-emerald-300 text-xs font-semibold shadow-lg">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        <span>KisanAI Live Farm Telemetry</span>
      </div>

      {/* Floating Interactive Live Cards */}
      {/* 1. Live Crop Health Card */}
      <motion.div
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
        onClick={() => openModal('diagnose')}
        className="absolute bottom-4 left-4 z-20 hidden sm:flex items-center gap-3 p-3 rounded-2xl bg-white/90 dark:bg-emerald-950/85 backdrop-blur-xl border border-emerald-500/30 shadow-xl cursor-pointer hover:scale-105 transition-transform"
      >
        <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
          <Scan className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950 dark:text-emerald-100">
            <span>Wheat Crop Scan</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono">
              98.4%
            </span>
          </div>
          <p className="text-[11px] text-emerald-700/80 dark:text-emerald-300/80">
            Healthy Flag Leaves • No Blight
          </p>
        </div>
      </motion.div>

      {/* 2. Soil Moisture & Weather Card */}
      <motion.div
        animate={{ y: [0, 6, 0] }}
        transition={{ duration: 4.5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
        onClick={() => openModal('weatherAdvisory')}
        className="absolute top-4 right-4 z-20 hidden sm:flex items-center gap-3 p-3 rounded-2xl bg-white/90 dark:bg-emerald-950/85 backdrop-blur-xl border border-emerald-500/30 shadow-xl cursor-pointer hover:scale-105 transition-transform"
      >
        <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
          <Droplets className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950 dark:text-emerald-100">
            <span>Moisture: 44%</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono">
              Optimal
            </span>
          </div>
          <p className="text-[11px] text-emerald-700/80 dark:text-emerald-300/80">
            28°C • Safe to spray till 4:30 PM
          </p>
        </div>
      </motion.div>

      {/* Interactive Clickable Hotspots */}
      {hotspots.map((hs) => {
        const Icon = hs.icon;
        return (
          <div
            key={hs.id}
            style={{ left: hs.x, top: hs.y }}
            className="absolute z-30 transform -translate-x-1/2 -translate-y-1/2 cursor-pointer"
            onClick={hs.action}
            onMouseEnter={() => setActiveHotspot(hs.id)}
            onMouseLeave={() => setActiveHotspot(null)}
          >
            <div className="relative flex items-center justify-center">
              <span className="absolute w-8 h-8 rounded-full bg-emerald-400/40 animate-ping" />
              <div className="relative w-7 h-7 rounded-full bg-emerald-600 border-2 border-white dark:border-emerald-300 flex items-center justify-center text-white shadow-lg hover:scale-110 transition-transform">
                <Icon className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Tooltip on hover */}
            {activeHotspot === hs.id && (
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-44 p-2.5 rounded-xl bg-emerald-950/95 backdrop-blur-md border border-emerald-500/40 text-white text-center shadow-2xl z-40 pointer-events-none">
                <p className="text-xs font-bold text-emerald-300">{hs.title}</p>
                <p className="text-[10px] text-emerald-100/80 mt-0.5">{hs.desc}</p>
                <p className="text-[9px] text-amber-300 font-semibold mt-1">Click to open tool →</p>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
