import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signInAnonymously, 
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User 
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDoc, 
  getDocFromServer,
  setDoc, 
  updateDoc, 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where,
  orderBy, 
  limit, 
  deleteDoc,
  serverTimestamp,
  Timestamp 
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { FarmerProfile, CropItem, DiseaseDiagnosis, YieldPredictionData, ProfitPredictionData } from '../types';

// Operation types for security and debugging telemetry
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const currentAuth = auth.currentUser;
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: currentAuth?.uid || null,
      email: currentAuth?.email || null,
      emailVerified: currentAuth?.emailVerified || false,
      isAnonymous: currentAuth?.isAnonymous || false,
      tenantId: currentAuth?.tenantId || null,
      providerInfo: currentAuth?.providerData?.map((provider) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Initialize Firebase App singleton
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Firebase Authentication
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Initialize Firestore with the named database instance from configuration
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Validate Connection to Firestore on module boot
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Firestore connection error: please check network and Firebase configuration.');
    }
    return false;
  }
}
testConnection();

/**
 * Sign in with Google Popup
 */
export const signInWithGoogle = async (): Promise<User> => {
  try {
    googleProvider.setCustomParameters({
      prompt: 'select_account',
    });
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error: any) {
    const isPopupBlocked = error?.code === 'auth/popup-blocked' || error?.message?.includes('popup-blocked');
    const isPopupDismissed = error?.code === 'auth/popup-closed-by-user' || error?.code === 'auth/cancelled-popup-request';
    if (isPopupBlocked || isPopupDismissed) {
      console.warn('Google Sign-in popup notice:', error?.code || error?.message);
    } else {
      console.error('Google Sign-in error:', error);
    }
    throw error;
  }
};

/**
 * Sign in anonymously for rapid, zero-barrier mobile farmer onboarding
 */
export const signInFarmerSession = async (): Promise<User> => {
  try {
    if (auth.currentUser) {
      return auth.currentUser;
    }
    const cred = await signInAnonymously(auth);
    return cred.user;
  } catch (error: any) {
    console.error('Anonymous farmer auth error:', error);
    throw error;
  }
};

/**
 * Sign out
 */
export const logOutUser = async (): Promise<void> => {
  try {
    await firebaseSignOut(auth);
  } catch (error: any) {
    console.error('Sign-out error:', error);
    throw error;
  }
};

// ==========================================
// FIRESTORE FARMER & USER PROFILE OPERATIONS
// Collections: users, farmerProfiles
// ==========================================

export const getFarmerProfileFromDb = async (userId: string): Promise<FarmerProfile | null> => {
  try {
    // Check primary farmerProfiles collection first
    const profileRef = doc(db, 'farmerProfiles', userId);
    const profileSnap = await getDoc(profileRef);
    if (profileSnap.exists()) {
      return profileSnap.data() as FarmerProfile;
    }

    // Fallback check users collection
    const userDocRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userDocRef);
    if (userSnap.exists()) {
      return userSnap.data() as FarmerProfile;
    }
    return null;
  } catch (error: any) {
    console.error('Failed to get farmer profile:', error);
    return null;
  }
};

export const saveFarmerProfileToDb = async (userId: string, profile: FarmerProfile): Promise<void> => {
  try {
    const timestamp = new Date().toISOString();
    
    // 1. Save core user record in `users` collection keyed by Auth UID
    const userDocRef = doc(db, 'users', userId);
    await setDoc(userDocRef, {
      id: userId,
      uid: userId,
      email: auth.currentUser?.email || null,
      displayName: profile.fullName || profile.name || auth.currentUser?.displayName || 'Farmer',
      phone: profile.phone || auth.currentUser?.phoneNumber || null,
      photoURL: profile.avatarUrl || auth.currentUser?.photoURL || null,
      role: 'farmer',
      updatedAt: timestamp,
    }, { merge: true });

    // 2. Save comprehensive farmer profile in `farmerProfiles` collection keyed by Auth UID
    const profileDocRef = doc(db, 'farmerProfiles', userId);
    await setDoc(profileDocRef, {
      ...profile,
      id: userId,
      userId: userId,
      updatedAt: timestamp,
    }, { merge: true });
  } catch (error: any) {
    console.error('Failed to save farmer profile to Firestore:', error);
    throw error;
  }
};

// ==========================================
// FIRESTORE CROPS OPERATIONS
// Collection: crops
// ==========================================

export const getFarmerCropsFromDb = async (userId: string): Promise<CropItem[]> => {
  try {
    // 1. Fetch from canonical `crops` collection where userId matches
    const cropsQuery = query(collection(db, 'crops'), where('userId', '==', userId));
    const snap = await getDocs(cropsQuery);
    const crops: CropItem[] = [];
    snap.forEach((docSnap) => {
      crops.push({ id: docSnap.id, ...(docSnap.data() as Omit<CropItem, 'id'>) });
    });

    // 2. Check legacy subcollection if canonical crops are not yet present
    if (crops.length === 0) {
      const legacyColRef = collection(db, 'users', userId, 'crops');
      const legacySnap = await getDocs(legacyColRef);
      legacySnap.forEach((docSnap) => {
        crops.push({ id: docSnap.id, ...(docSnap.data() as Omit<CropItem, 'id'>) });
      });
    }

    return crops;
  } catch (error: any) {
    console.error('Failed to fetch crops from Firestore:', error);
    return [];
  }
};

export const saveCropToDb = async (userId: string, crop: CropItem): Promise<string> => {
  try {
    const cropId = crop.id || `crop_${Date.now()}`;
    const timestamp = new Date().toISOString();

    // Save in canonical `crops` collection with owner userId
    const cropDocRef = doc(db, 'crops', cropId);
    await setDoc(cropDocRef, {
      ...crop,
      id: cropId,
      userId: userId,
      updatedAt: timestamp,
    }, { merge: true });

    return cropId;
  } catch (error: any) {
    console.error('Failed to save crop to Firestore:', error);
    throw error;
  }
};

export const deleteCropFromDb = async (userId: string, cropId: string): Promise<void> => {
  try {
    const cropDocRef = doc(db, 'crops', cropId);
    await deleteDoc(cropDocRef);

    // Also remove from legacy subcollection if present
    const legacyDocRef = doc(db, 'users', userId, 'crops', cropId);
    await deleteDoc(legacyDocRef).catch(() => {});
  } catch (error: any) {
    console.error('Failed to delete crop from Firestore:', error);
    throw error;
  }
};

// ==========================================
// FIRESTORE DISEASE HISTORY OPERATIONS
// Collection: diseaseHistory
// ==========================================

export const saveDiagnosisToDb = async (userId: string, diagnosis: DiseaseDiagnosis): Promise<string> => {
  try {
    const historyId = diagnosis.id || `diag_${Date.now()}`;
    const historyDocRef = doc(db, 'diseaseHistory', historyId);
    await setDoc(historyDocRef, {
      ...diagnosis,
      id: historyId,
      userId: userId,
      createdAt: new Date().toISOString(),
    }, { merge: true });
    return historyId;
  } catch (error: any) {
    console.error('Failed to save disease history to Firestore:', error);
    throw error;
  }
};

export const getFarmerDiagnosesFromDb = async (userId: string): Promise<DiseaseDiagnosis[]> => {
  try {
    // 1. Fetch from canonical `diseaseHistory` collection
    const historyQuery = query(collection(db, 'diseaseHistory'), where('userId', '==', userId));
    const snap = await getDocs(historyQuery);
    const results: DiseaseDiagnosis[] = [];
    snap.forEach((docSnap) => {
      results.push({ id: docSnap.id, ...(docSnap.data() as Omit<DiseaseDiagnosis, 'id'>) });
    });

    // 2. Check legacy subcollection if needed
    if (results.length === 0) {
      const legacyDiagRef = collection(db, 'users', userId, 'diagnoses');
      const legacySnap = await getDocs(legacyDiagRef);
      legacySnap.forEach((docSnap) => {
        results.push({ id: docSnap.id, ...(docSnap.data() as Omit<DiseaseDiagnosis, 'id'>) });
      });
    }

    return results.sort((a, b) => new Date(b.detectedAt || 0).getTime() - new Date(a.detectedAt || 0).getTime());
  } catch (error: any) {
    console.error('Failed to fetch disease history from Firestore:', error);
    return [];
  }
};

// ==========================================
// FIRESTORE DISEASE PREDICTIONS OPERATIONS
// Collection: diseasePredictions
// ==========================================

export const savePredictionToDb = async (
  userId: string, 
  typeOrRecord: 'yield' | 'profit' | 'disease' | any, 
  data?: YieldPredictionData | ProfitPredictionData | any
): Promise<string> => {
  try {
    const isObject = typeof typeOrRecord === 'object' && typeOrRecord !== null;
    const type = isObject ? (typeOrRecord.type || 'prediction') : typeOrRecord;
    const payload = isObject ? typeOrRecord : (data || {});
    const predId = payload.id || `pred_${type}_${Date.now()}`;
    const predDocRef = doc(db, 'diseasePredictions', predId);
    
    await setDoc(predDocRef, {
      ...payload,
      id: predId,
      type,
      userId: userId,
      cropName: payload.cropName || payload.data?.cropName || 'Crop',
      predictedAmount: payload.predictedAmount ?? payload.data?.expectedYieldQuintals ?? payload.data?.netProfit ?? 0,
      createdAt: payload.createdAt || payload.timestamp || new Date().toISOString(),
    }, { merge: true });

    return predId;
  } catch (error: any) {
    console.error('Failed to save disease prediction to Firestore:', error);
    throw error;
  }
};

export const getFarmerPredictionsFromDb = async (userId: string): Promise<any[]> => {
  try {
    // 1. Fetch from canonical `diseasePredictions` collection
    const predQuery = query(collection(db, 'diseasePredictions'), where('userId', '==', userId));
    const snap = await getDocs(predQuery);
    const results: any[] = [];
    snap.forEach((docSnap) => {
      results.push({ id: docSnap.id, ...docSnap.data() });
    });

    // 2. Check legacy subcollection if needed
    if (results.length === 0) {
      const legacyPredRef = collection(db, 'users', userId, 'predictions');
      const legacySnap = await getDocs(legacyPredRef);
      legacySnap.forEach((docSnap) => {
        results.push({ id: docSnap.id, ...docSnap.data() });
      });
    }

    return results.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
  } catch (error: any) {
    console.error('Failed to fetch disease predictions from Firestore:', error);
    return [];
  }
};
