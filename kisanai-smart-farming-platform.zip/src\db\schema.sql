-- KisanAI PostgreSQL Database Schema
-- Production-Ready Schema for Smart Agriculture Platform

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Farmers / Users Table
CREATE TABLE IF NOT EXISTS farmers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone VARCHAR(20) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    kisan_id VARCHAR(50) UNIQUE,
    preferred_language VARCHAR(10) DEFAULT 'en', -- en, hi, mr, pa, te, ta, bn, gu, kn
    state VARCHAR(100) NOT NULL,
    district VARCHAR(100) NOT NULL,
    village VARCHAR(100),
    total_land_acres NUMERIC(6, 2) DEFAULT 0,
    soil_type VARCHAR(50), -- Alluvial, Black, Red, Laterite, Desert
    irrigation_source VARCHAR(50), -- Tube well, Canal, Drip, Rainfed
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Registered Crops & Plots Table
CREATE TABLE IF NOT EXISTS farmer_crops (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farmer_id UUID REFERENCES farmers(id) ON DELETE CASCADE,
    crop_name VARCHAR(100) NOT NULL,
    variety VARCHAR(100),
    sowing_date DATE NOT NULL,
    expected_harvest_date DATE,
    plot_size_acres NUMERIC(6, 2) NOT NULL,
    stage VARCHAR(50) DEFAULT 'Vegetative', -- Sowing, Germination, Vegetative, Flowering, Fruiting, Harvesting
    health_status VARCHAR(50) DEFAULT 'Healthy', -- Excellent, Healthy, Attention Needed, Critical
    expected_yield_quintals NUMERIC(8, 2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. AI Crop Disease Diagnoses Table
CREATE TABLE IF NOT EXISTS crop_diagnoses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farmer_id UUID REFERENCES farmers(id) ON DELETE SET NULL,
    crop_name VARCHAR(100) NOT NULL,
    image_url TEXT,
    disease_detected VARCHAR(150) NOT NULL,
    confidence_score NUMERIC(5, 2) NOT NULL, -- e.g. 96.50%
    severity_level VARCHAR(20) NOT NULL, -- Low, Moderate, High, Severe
    symptoms TEXT[] NOT NULL,
    organic_remedies TEXT[] NOT NULL,
    chemical_remedies TEXT[] NOT NULL,
    preventive_measures TEXT[] NOT NULL,
    detected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. AI Voice & Chat Interactions Table
CREATE TABLE IF NOT EXISTS ai_voice_queries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farmer_id UUID REFERENCES farmers(id) ON DELETE SET NULL,
    query_text TEXT NOT NULL,
    audio_query_url TEXT,
    response_text TEXT NOT NULL,
    language VARCHAR(10) DEFAULT 'en',
    topic_category VARCHAR(50), -- Pest Management, Weather, Mandi, Irrigation, Fertilizer, Scheme
    audio_response_url TEXT,
    feedback_rating INT CHECK (feedback_rating BETWEEN 1 AND 5),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. Soil Health Records Table
CREATE TABLE IF NOT EXISTS soil_health_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farmer_id UUID REFERENCES farmers(id) ON DELETE CASCADE,
    test_date DATE DEFAULT CURRENT_DATE,
    nitrogen_kg_ha NUMERIC(6, 2),
    phosphorus_kg_ha NUMERIC(6, 2),
    potassium_kg_ha NUMERIC(6, 2),
    ph_level NUMERIC(4, 2),
    electrical_conductivity NUMERIC(4, 2),
    organic_carbon_percent NUMERIC(4, 2),
    ai_recommendation TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 6. Mandi Market Prices Table
CREATE TABLE IF NOT EXISTS mandi_prices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    commodity VARCHAR(100) NOT NULL,
    variety VARCHAR(100),
    market_name VARCHAR(100) NOT NULL,
    district VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    min_price_per_quintal NUMERIC(8, 2) NOT NULL,
    max_price_per_quintal NUMERIC(8, 2) NOT NULL,
    modal_price_per_quintal NUMERIC(8, 2) NOT NULL,
    msp_benchmark NUMERIC(8, 2),
    price_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 7. IoT & Weather Sensors Table
CREATE TABLE IF NOT EXISTS farm_sensor_telemetry (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    farmer_id UUID REFERENCES farmers(id) ON DELETE CASCADE,
    sensor_type VARCHAR(50) NOT NULL, -- soil_moisture, canopy_temp, humidity, leaf_wetness
    reading_value NUMERIC(8, 2) NOT NULL,
    unit VARCHAR(20) NOT NULL,
    battery_level INT,
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create Indexes for performance
CREATE INDEX IF NOT EXISTS idx_farmers_phone ON farmers(phone);
CREATE INDEX IF NOT EXISTS idx_crops_farmer ON farmer_crops(farmer_id);
CREATE INDEX IF NOT EXISTS idx_diagnoses_crop ON crop_diagnoses(crop_name);
CREATE INDEX IF NOT EXISTS idx_mandi_commodity ON mandi_prices(commodity, state, price_date);
CREATE INDEX IF NOT EXISTS idx_sensor_farmer_time ON farm_sensor_telemetry(farmer_id, recorded_at DESC);
