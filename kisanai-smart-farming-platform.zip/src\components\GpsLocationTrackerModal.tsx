import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  MapPin,
  Navigation,
  Compass,
  Layers,
  Share2,
  ExternalLink,
  RefreshCw,
  X,
  CheckCircle,
  AlertCircle,
  Volume2,
  VolumeX,
  Sparkles,
  ShieldCheck,
  Send,
  CloudSun,
  LocateFixed,
  Radio,
  Copy,
  Check,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const GpsLocationTrackerModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    openModal,
    currentGps,
    isGpsTracking,
    gpsError,
    startGpsTracking,
    stopGpsTracking,
    refreshGpsLocation,
    openGoogleMaps,
    saveFarmGpsCoordinates,
    farmer,
    language,
    speakText,
    isSpeaking,
    stopSpeaking,
  } = useApp();

  const [mapType, setMapType] = useState<'roadmap' | 'satellite' | 'terrain'>('roadmap');
  const [copied, setCopied] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const lat = currentGps?.lat ?? farmer.latitude ?? 20.1662;
  const lng = currentGps?.lng ?? farmer.longitude ?? 73.9856;
  const accuracy = currentGps?.accuracy ?? 8;
  const address = currentGps?.formattedAddress ?? farmer.farmGpsAddress ?? `${lat.toFixed(4)}, ${lng.toFixed(4)}`;

  // Google Maps embed URL with live coordinates
  const googleMapEmbedUrl = `https://maps.google.com/maps?q=${lat},${lng}&t=${mapType === 'satellite' ? 'k' : mapType === 'terrain' ? 'p' : 'm'}&z=16&output=embed`;

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refreshGpsLocation();
    setTimeout(() => setIsRefreshing(false), 800);
  };

  const handleSaveFarm = async () => {
    if (lat && lng) {
      await saveFarmGpsCoordinates(lat, lng, address);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    }
  };

  const handleCopyShareLink = () => {
    const mapsLink = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
    navigator.clipboard.writeText(mapsLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleShareWhatsApp = () => {
    const text = language === 'mr'
      ? `🌾 माझ्या शेताचे अचूक GPS लोकेशन (KisanAI): https://www.google.com/maps/search/?api=1&query=${lat},${lng}`
      : `🌾 My Farm GPS Location (KisanAI): https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleSpeakLocation = () => {
    const voiceText = language === 'mr'
      ? `तुमचे चालू GPS स्थान ${currentGps?.village || 'शेत परिसर'}, जिल्हा ${currentGps?.district || 'नाशिक'} येथे आहे. अचूकता ${accuracy} मीटर आहे. Google Maps जोडणी सक्रिय आहे.`
      : language === 'hi'
      ? `आपका वर्तमान GPS स्थान ${currentGps?.village || 'खेत'}, जिला ${currentGps?.district || 'नाशिक'} में है। Google Maps कनेक्टिविटी सक्रिय है।`
      : `Your live farm GPS coordinate is ${lat.toFixed(4)}, ${lng.toFixed(4)} located in ${currentGps?.village || 'Farm area'}, ${currentGps?.district || 'Nashik'} with ±${accuracy}m precision. Connected directly to Google Maps.`;
    speakText(voiceText, language);
  };

  if (activeModal !== 'gpsTracker') return null;

  return (
    <div
      id="gps-tracker-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-emerald-950/80 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-4xl max-h-[92vh] rounded-3xl bg-white dark:bg-[#072418] border border-emerald-500/30 shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-emerald-500/20 bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 dark:from-emerald-950/90 dark:to-[#041d13] shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-md">
              <Navigation className="w-5 h-5 text-white" />
              {isGpsTracking && (
                <span className="absolute -top-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-400"></span>
                </span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-white font-outfit">
                  {language === 'mr'
                    ? '📍 थेट GPS लोकेशन व Google Map'
                    : language === 'hi'
                    ? '📍 लाइव GPS लोकेशन व Google Map'
                    : '📍 Live GPS Farm Tracker & Google Maps'}
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-black rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <Radio className="w-3 h-3 text-emerald-500 animate-pulse" />
                  {isGpsTracking ? 'LIVE TRACKING' : 'GPS READY'}
                </span>
              </div>
              <p className="text-xs text-emerald-700/80 dark:text-emerald-400/80 flex items-center gap-1 truncate max-w-sm sm:max-w-md">
                <MapPin className="w-3 h-3 text-emerald-500 shrink-0" />
                <span className="truncate">{address}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRefresh}
              title="Refresh GPS"
              className="p-2 rounded-xl bg-white dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 hover:bg-emerald-100 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={closeModal}
              className="p-2 rounded-xl bg-white dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-200 border border-emerald-500/20 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-600 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* 1. Live Coordinates & Telemetry Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Latitude & Longitude */}
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 dark:bg-emerald-950/60 border border-emerald-500/20">
              <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-emerald-400/80 block">
                {language === 'mr' ? 'अक्षांश / रेखांश (Lat/Lng)' : 'Coordinates'}
              </span>
              <span className="text-xs sm:text-sm font-black font-mono text-emerald-950 dark:text-white block mt-0.5">
                {lat.toFixed(5)}, {lng.toFixed(5)}
              </span>
            </div>

            {/* GPS Precision Accuracy */}
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 dark:bg-emerald-950/60 border border-emerald-500/20">
              <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-emerald-400/80 block">
                {language === 'mr' ? 'GPS अचूकता (Accuracy)' : 'Accuracy Radius'}
              </span>
              <span className="text-xs sm:text-sm font-black font-mono text-emerald-600 dark:text-emerald-300 block mt-0.5 flex items-center gap-1">
                <LocateFixed className="w-3.5 h-3.5" />
                ±{accuracy} {language === 'mr' ? 'मीटर' : 'meters'}
              </span>
            </div>

            {/* Altitude / Elevation */}
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 dark:bg-emerald-950/60 border border-emerald-500/20">
              <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-emerald-400/80 block">
                {language === 'mr' ? 'समुद्रसपाटीपासून उंची' : 'Elevation'}
              </span>
              <span className="text-xs sm:text-sm font-black font-mono text-emerald-950 dark:text-white block mt-0.5">
                {currentGps?.altitude ? `${currentGps.altitude} m` : '584 m (Optimal)'}
              </span>
            </div>

            {/* Speed & Heading */}
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 dark:bg-emerald-950/60 border border-emerald-500/20">
              <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-emerald-400/80 block">
                {language === 'mr' ? 'दिशा व हालचाल' : 'Bearing & Speed'}
              </span>
              <span className="text-xs sm:text-sm font-black font-mono text-emerald-950 dark:text-white block mt-0.5 flex items-center gap-1">
                <Compass className="w-3.5 h-3.5 text-teal-500" />
                {currentGps?.heading ? `${Math.round(currentGps.heading)}°` : 'North 45°'}{' '}
                • {currentGps?.speed || 0} km/h
              </span>
            </div>
          </div>

          {/* 2. Interactive Google Map Container */}
          <div className="rounded-3xl border-2 border-emerald-500/30 overflow-hidden shadow-xl relative bg-slate-900">
            {/* Map Header Overlay */}
            <div className="absolute top-3 left-3 right-3 z-10 flex items-center justify-between gap-2 pointer-events-auto">
              {/* Map Layer Selector */}
              <div className="flex items-center bg-white/90 dark:bg-emerald-950/90 backdrop-blur-md rounded-2xl p-1 border border-emerald-500/30 shadow-md">
                {(['roadmap', 'satellite', 'terrain'] as const).map((type) => (
                  <button
                    key={type}
                    onClick={() => setMapType(type)}
                    className={`px-3 py-1 text-xs font-bold rounded-xl transition-all cursor-pointer capitalize ${
                      mapType === type
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-700 dark:text-emerald-200 hover:text-emerald-600'
                    }`}
                  >
                    {type === 'roadmap' ? '🗺️ Map' : type === 'satellite' ? '🛰️ Satellite' : '⛰️ Terrain'}
                  </button>
                ))}
              </div>

              {/* Direct Open in Google Maps Button */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => openGoogleMaps('satellite')}
                  className="px-3.5 py-1.5 rounded-xl bg-white/95 dark:bg-emerald-900/90 hover:bg-white text-emerald-950 dark:text-white text-xs font-extrabold flex items-center gap-1.5 shadow-md border border-emerald-500/30 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Google Maps</span>
                </button>
              </div>
            </div>

            {/* Embedded Live Google Map */}
            <div className="w-full h-72 sm:h-96 relative">
              <iframe
                title="Google Maps Live Location"
                width="100%"
                height="100%"
                frameBorder="0"
                scrolling="no"
                marginHeight={0}
                marginWidth={0}
                src={googleMapEmbedUrl}
                className="w-full h-full border-0"
              />
            </div>

            {/* Map Footer Toolbar with Live Controls */}
            <div className="p-3 bg-gradient-to-r from-emerald-950/95 to-teal-950/95 text-white flex flex-wrap items-center justify-between gap-2 border-t border-emerald-500/20">
              <div className="flex items-center gap-2 text-xs">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                <span className="font-bold">{address}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleSpeakLocation}
                  className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-xs flex items-center gap-1 shadow-sm cursor-pointer"
                >
                  {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                  <span>🔊 {language === 'mr' ? 'लोकेशन ऐका' : 'Listen'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* 3. Primary Google Maps Direct Actions Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Open Direct Directions in Google Maps */}
            <button
              onClick={() => openGoogleMaps('directions')}
              className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-md flex flex-col justify-between space-y-2 text-left cursor-pointer transition-transform hover:scale-[1.02]"
            >
              <div className="flex items-center justify-between">
                <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
                  <Navigation className="w-4 h-4 text-white" />
                </div>
                <ExternalLink className="w-4 h-4 text-emerald-100" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-extrabold">
                  {language === 'mr' ? 'शेताचा रस्ता / दिशा' : 'Get Directions'}
                </h4>
                <p className="text-[11px] text-emerald-100/90 mt-0.5">
                  {language === 'mr' ? 'Google Maps ने शेतापर्यंत नेव्हिगेट करा' : 'Turn-by-turn navigation to farm'}
                </p>
              </div>
            </button>

            {/* Toggle Live Continuous GPS Tracking */}
            <button
              onClick={isGpsTracking ? stopGpsTracking : startGpsTracking}
              className={`p-4 rounded-2xl border text-left flex flex-col justify-between space-y-2 cursor-pointer transition-all ${
                isGpsTracking
                  ? 'bg-rose-500/10 border-rose-500/40 text-rose-900 dark:text-rose-200'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-950 dark:text-emerald-100 hover:bg-emerald-500/20'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isGpsTracking ? 'bg-rose-500 text-white animate-pulse' : 'bg-emerald-600 text-white'}`}>
                  <Radio className="w-4 h-4" />
                </div>
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${isGpsTracking ? 'bg-rose-500 text-white' : 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300'}`}>
                  {isGpsTracking ? 'ON' : 'OFF'}
                </span>
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-extrabold">
                  {isGpsTracking
                    ? (language === 'mr' ? 'लाइव्ह ट्रॅकिंग सुरू आहे' : 'Live Tracking Active')
                    : (language === 'mr' ? 'लाइव्ह ट्रॅकिंग सुरू करा' : 'Start Live GPS Track')}
                </h4>
                <p className="text-[11px] text-slate-600 dark:text-emerald-200/80 mt-0.5">
                  {language === 'mr' ? 'शेतात फिरताना रिअल-टाइम लोकेशन ट्रॅक करा' : 'Real-time rover coordinates updates'}
                </p>
              </div>
            </button>

            {/* Set as Farm Center */}
            <button
              onClick={handleSaveFarm}
              className="p-4 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 hover:border-emerald-500/40 text-left flex flex-col justify-between space-y-2 cursor-pointer transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                  <MapPin className="w-4 h-4" />
                </div>
                {savedSuccess && <Check className="w-4 h-4 text-emerald-500 stroke-[3]" />}
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-extrabold text-emerald-950 dark:text-white">
                  {savedSuccess
                    ? (language === 'mr' ? '✅ शेताचे स्थान सेव्ह झाले' : '✅ Farm Center Saved')
                    : (language === 'mr' ? 'हे मुख्य शेत स्थान सेट करा' : 'Save As My Farm Center')}
                </h4>
                <p className="text-[11px] text-slate-600 dark:text-emerald-200/80 mt-0.5">
                  {language === 'mr' ? 'प्रोफाइलमध्ये GPS पिन जोडा' : 'Sync coordinates with farmer profile'}
                </p>
              </div>
            </button>

            {/* Precision Treatment Weather for this GPS Point */}
            <button
              onClick={() => {
                closeModal();
                openModal('weatherAdvisory');
              }}
              className="p-4 rounded-2xl bg-gradient-to-br from-sky-500/20 to-teal-500/20 border border-sky-500/30 hover:border-sky-500/60 text-left flex flex-col justify-between space-y-2 cursor-pointer transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="w-8 h-8 rounded-xl bg-sky-500 text-white flex items-center justify-center shadow-xs">
                  <CloudSun className="w-4 h-4" />
                </div>
                <Sparkles className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-extrabold text-emerald-950 dark:text-white">
                  {language === 'mr' ? 'या स्थानाचे फवारणी हवामान' : 'Treatment Weather'}
                </h4>
                <p className="text-[11px] text-slate-600 dark:text-emerald-200/80 mt-0.5">
                  {language === 'mr' ? 'अचूक हवामान व औषध फवारणी सल्ला' : 'Spray window & disease radar'}
                </p>
              </div>
            </button>
          </div>

          {/* 4. Share Farm GPS Location Bar */}
          <div className="p-4 rounded-3xl bg-slate-50 dark:bg-emerald-950/40 border border-emerald-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 flex items-center justify-center">
                <Share2 className="w-4 h-4" />
              </div>
              <div>
                <h5 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                  {language === 'mr' ? 'शेताचे Google Maps लोकेशन शेअर करा' : 'Share Farm Location with Agronomist / Mandi'}
                </h5>
                <p className="text-[11px] text-slate-500 dark:text-zinc-400">
                  {language === 'mr' ? 'कृषी सल्लागार किंवा व्यापाऱ्यांना थेट शेताची अचूक पिन पाठवा.' : 'Instant Google Maps link sharing via WhatsApp.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-stretch sm:self-auto">
              <button
                onClick={handleCopyShareLink}
                className="flex-1 sm:flex-initial px-3.5 py-2 rounded-xl bg-white dark:bg-emerald-900/50 border border-emerald-500/30 text-xs font-bold text-emerald-950 dark:text-white hover:bg-emerald-50 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" /> : <Copy className="w-3.5 h-3.5 text-emerald-600" />}
                <span>{copied ? (language === 'mr' ? 'लिंक कॉपी झाली!' : 'Copied!') : (language === 'mr' ? 'लिंक कॉपी करा' : 'Copy Link')}</span>
              </button>

              <button
                onClick={handleShareWhatsApp}
                className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
