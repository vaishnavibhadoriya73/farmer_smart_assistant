import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckCircle,
  X,
  ArrowRight,
  ArrowLeft,
  Volume2,
  Sparkles,
  MapPin,
  Sprout,
  Layers,
  Globe2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SUPPORTED_LANGUAGES, ONBOARDING_CROPS } from '../data/mockAgriData';
import { LanguageCode } from '../types';

export const OnboardingModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    completeOnboarding,
    speakText,
    language: currentLang,
  } = useApp();

  const [step, setStep] = useState<number>(1);
  const [selectedLang, setSelectedLang] = useState<LanguageCode>(currentLang || 'mr');
  const [farmerName, setFarmerName] = useState('रामेश्वर पाटील');
  const [selectedCrops, setSelectedCrops] = useState<string[]>(['crop-wheat', 'crop-onion']);
  const [landAcres, setLandAcres] = useState<number>(4.0);
  const [stateName, setStateName] = useState('Maharashtra');
  const [districtName, setDistrictName] = useState('Nashik');

  if (activeModal !== 'onboarding') return null;

  const toggleCrop = (cropId: string) => {
    setSelectedCrops((prev) =>
      prev.includes(cropId) ? prev.filter((id) => id !== cropId) : [...prev, cropId]
    );
  };

  const handleNext = () => {
    if (step === 1) {
      // Speak welcome in chosen language
      if (selectedLang === 'mr') {
        speakText('नमस्कार शेतकरी मित्रा! किसान ॲप मध्ये आपले स्वागत आहे.', 'mr');
      } else if (selectedLang === 'hi') {
        speakText('नमस्ते किसान भाई! किसान ऐप में आपका स्वागत है।', 'hi');
      } else {
        speakText('Welcome to KisanAI, your intelligent farming assistant.', 'en');
      }
      setStep(2);
    } else if (step === 2) {
      setStep(3);
    } else if (step === 3) {
      setStep(4);
    } else if (step === 4) {
      completeOnboarding({
        fullName: farmerName,
        language: selectedLang,
        selectedCrops,
        totalLandAcres: landAcres,
        state: stateName,
        district: districtName,
      });
    }
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <div
      id="onboarding-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-emerald-950/85 backdrop-blur-md overflow-y-auto"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="relative w-full max-w-xl rounded-3xl bg-white dark:bg-[#072519] border-2 border-emerald-500/30 p-6 sm:p-8 shadow-2xl space-y-6 my-auto text-emerald-950 dark:text-white"
      >
        {/* Close Button */}
        <button
          onClick={closeModal}
          className="absolute top-5 right-5 p-2 rounded-xl bg-emerald-100/60 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-200 hover:bg-emerald-200 transition-all cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Progress Dots */}
        <div className="flex items-center justify-center gap-2 pt-2">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={`h-2 rounded-full transition-all duration-300 ${
                s === step
                  ? 'w-8 bg-emerald-500'
                  : s < step
                  ? 'w-2 bg-emerald-400'
                  : 'w-2 bg-emerald-200 dark:bg-emerald-900'
              }`}
            />
          ))}
        </div>

        {/* STEP 1: WELCOME & GREETING */}
        {step === 1 && (
          <div className="text-center space-y-5">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-white mx-auto flex items-center justify-center text-4xl shadow-xl shadow-emerald-500/30 animate-pulse">
              🌾
            </div>

            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-500/20">
                <Sparkles className="w-3.5 h-3.5" />
                <span>KisanAI Farmer Setup</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-outfit text-emerald-950 dark:text-white">
                {selectedLang === 'mr'
                  ? 'नमस्कार शेतकरी मित्रा!'
                  : selectedLang === 'hi'
                  ? 'नमस्ते किसान भाई!'
                  : 'Welcome to KisanAI!'}
              </h2>
              <p className="text-sm text-zinc-600 dark:text-zinc-300 max-w-md mx-auto leading-relaxed">
                {selectedLang === 'mr'
                  ? 'आपल्या पिकांची अचूक काळजी घेण्यासाठी आणि अधिक नफा मिळवण्यासाठी काही सोपे पर्याय निवडा.'
                  : selectedLang === 'hi'
                  ? 'अपनी फसलों की बेहतर देखभाल और अधिक मुनाफे के लिए कुछ सरल विकल्प चुनें।'
                  : 'A simple, farmer-first setup designed to personalize your crop advisories and local mandi rates.'}
              </p>
            </div>

            {/* Quick Name Input */}
            <div className="max-w-xs mx-auto text-left">
              <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1">
                {selectedLang === 'mr' ? 'आपले नाव (Farmer Name)' : 'आपका नाम (Farmer Name)'}
              </label>
              <input
                type="text"
                value={farmerName}
                onChange={(e) => setFarmerName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/30 text-sm font-bold text-emerald-950 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
        )}

        {/* STEP 2: SELECT LANGUAGE */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="text-center space-y-1">
              <h3 className="text-xl font-extrabold font-outfit text-emerald-950 dark:text-white">
                आपली भाषा निवडा / भाषा चुनें / Select Language
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                KisanAI will adapt all buttons, voice replies, and tips into this language.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-64 overflow-y-auto p-1">
              {SUPPORTED_LANGUAGES.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setSelectedLang(lang.code)}
                  className={`p-3.5 rounded-2xl border-2 text-left flex items-center justify-between transition-all cursor-pointer ${
                    selectedLang === lang.code
                      ? 'border-emerald-500 bg-emerald-500/15 shadow-md scale-[1.02]'
                      : 'border-emerald-500/20 bg-white/50 dark:bg-emerald-900/20 hover:border-emerald-500/50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{lang.flag}</span>
                    <div>
                      <span className="block font-bold text-sm text-emerald-950 dark:text-white">
                        {lang.nativeName}
                      </span>
                      <span className="block text-[11px] text-zinc-500 dark:text-zinc-400">
                        {lang.name}
                      </span>
                    </div>
                  </div>
                  {selectedLang === lang.code && (
                    <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                  )}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STEP 3: VISUAL CROP SELECTION */}
        {step === 3 && (
          <div className="space-y-4">
            <div className="text-center space-y-1">
              <h3 className="text-xl font-extrabold font-outfit text-emerald-950 dark:text-white">
                {selectedLang === 'mr'
                  ? 'आपली मुख्य पिके निवडा'
                  : selectedLang === 'hi'
                  ? 'अपनी मुख्य फसलें चुनें'
                  : 'Select Your Active Crops'}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                {selectedLang === 'mr'
                  ? 'निवडलेल्या पिकांनुसार रोग तपासणी व बाजारभाव दिसतील'
                  : 'Tap to select one or more crops grown on your farm.'}
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-h-72 overflow-y-auto p-1">
              {ONBOARDING_CROPS.map((crop) => {
                const isSelected = selectedCrops.includes(crop.id);
                const name =
                  selectedLang === 'mr'
                    ? crop.nameMr
                    : selectedLang === 'hi'
                    ? crop.nameHi
                    : crop.nameEn;

                return (
                  <button
                    key={crop.id}
                    onClick={() => toggleCrop(crop.id)}
                    className={`relative p-2.5 rounded-2xl border-2 text-center flex flex-col items-center gap-2 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-500/20 shadow-md ring-2 ring-emerald-500/30'
                        : 'border-emerald-500/20 bg-white/50 dark:bg-emerald-900/20 hover:border-emerald-500/40'
                    }`}
                  >
                    <div className="relative w-14 h-14 rounded-xl overflow-hidden shadow-xs">
                      <img src={crop.image} alt={name} className="w-full h-full object-cover" />
                      <span className="absolute bottom-0.5 right-0.5 text-sm">{crop.icon}</span>
                    </div>
                    <span className="text-xs font-bold text-emerald-950 dark:text-white truncate max-w-full">
                      {name}
                    </span>
                    {isSelected && (
                      <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                        <CheckCircle className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* STEP 4: LAND SIZE & LOCATION */}
        {step === 4 && (
          <div className="space-y-4">
            <div className="text-center space-y-1">
              <h3 className="text-xl font-extrabold font-outfit text-emerald-950 dark:text-white">
                {selectedLang === 'mr'
                  ? 'शेतजमीन आणि जिल्हा'
                  : selectedLang === 'hi'
                  ? 'जमीन का आकार और जिला'
                  : 'Farm Land & District'}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Used to deliver precise weather radar and fertilizer calculations.
              </p>
            </div>

            {/* Quick Land Size Buttons */}
            <div>
              <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-2">
                {selectedLang === 'mr' ? 'एकूण जमीन (एकर)' : 'कुल जमीन (एकड़) / Land Size'}
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[1.5, 3.5, 5.0, 10.0].map((acres) => (
                  <button
                    key={acres}
                    onClick={() => setLandAcres(acres)}
                    className={`py-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      landAcres === acres
                        ? 'border-emerald-500 bg-emerald-600 text-white shadow-md'
                        : 'border-emerald-500/20 bg-emerald-50/50 dark:bg-emerald-900/30 text-emerald-950 dark:text-emerald-100 hover:bg-emerald-100/60'
                    }`}
                  >
                    {acres} {selectedLang === 'mr' ? 'एकर' : selectedLang === 'hi' ? 'एकड़' : 'Acres'}
                  </button>
                ))}
              </div>
            </div>

            {/* State & District */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1">
                  राज्य / State
                </label>
                <select
                  value={stateName}
                  onChange={(e) => setStateName(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/30 text-xs font-bold text-emerald-950 dark:text-white focus:outline-none"
                >
                  <option value="Maharashtra">Maharashtra (महाराष्ट्र)</option>
                  <option value="Madhya Pradesh">Madhya Pradesh (मध्य प्रदेश)</option>
                  <option value="Gujarat">Gujarat (गुजरात)</option>
                  <option value="Punjab">Punjab (ਪੰਜਾਬ)</option>
                  <option value="Haryana">Haryana (हरियाणा)</option>
                  <option value="Karnataka">Karnataka (ಕರ್ನಾಟಕ)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1">
                  जिल्हा / District
                </label>
                <input
                  type="text"
                  value={districtName}
                  onChange={(e) => setDistrictName(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/30 text-xs font-bold text-emerald-950 dark:text-white focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* Footer Navigation Buttons */}
        <div className="flex items-center justify-between gap-3 pt-3 border-t border-emerald-500/20">
          {step > 1 ? (
            <button
              onClick={handleBack}
              className="px-4 py-2.5 rounded-xl bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-200 text-xs font-bold hover:bg-zinc-300 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{selectedLang === 'mr' ? 'मागे' : selectedLang === 'hi' ? 'पीछे' : 'Back'}</span>
            </button>
          ) : (
            <div />
          )}

          <button
            onClick={handleNext}
            className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold shadow-lg shadow-emerald-600/30 transition-all flex items-center gap-2 cursor-pointer ml-auto"
          >
            <span>
              {step === 4
                ? selectedLang === 'mr'
                  ? 'किसान ॲप सुरू करा'
                  : selectedLang === 'hi'
                  ? 'किसान ऐप शुरू करें'
                  : 'Launch KisanAI'
                : selectedLang === 'mr'
                ? 'पुढे चला'
                : selectedLang === 'hi'
                ? 'आगे बढ़ें'
                : 'Continue'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </motion.div>
    </div>
  );
};
