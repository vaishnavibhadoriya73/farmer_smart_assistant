import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FlaskConical,
  CheckCircle2,
  AlertCircle,
  X,
  Sparkles,
  RefreshCw,
  Calculator,
  Leaf,
  Upload,
  Camera,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  FileText,
  Sprout,
  Droplets,
  Layers,
  ArrowRight,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SoilAnalysisResult } from '../types';

export const SoilHealthModal: React.FC = () => {
  const { activeModal, closeModal, farmer, language, speakText, isSpeaking, stopSpeaking } = useApp();

  // Input states
  const [activeInputTab, setActiveInputTab] = useState<'upload' | 'camera' | 'voice' | 'sliders'>('sliders');
  const [nitrogen, setNitrogen] = useState(240); // kg/ha
  const [phosphorus, setPhosphorus] = useState(22); // kg/ha
  const [potassium, setPotassium] = useState(290); // kg/ha
  const [ph, setPh] = useState(7.2);
  const [organicCarbon, setOrganicCarbon] = useState(0.55); // %
  const [selectedSoilType, setSelectedSoilType] = useState(farmer.soilType || 'काळी कसदार (Black Cotton)');

  // File / Camera / Voice states
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [voiceText, setVoiceText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<SoilAnalysisResult | null>(null);
  const [playingId, setPlayingId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recognitionRef = useRef<any>(null);

  // Initialize camera
  const startCamera = async () => {
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Camera access error:', err);
      setIsCameraActive(false);
      alert(language === 'mr' ? 'कॅमेरा सुरू करता आला नाही. कृपया परवानगी तपासा.' : 'Could not access camera.');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const captureSoilPhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setImagePreview(dataUrl);
      stopCamera();
    }
  };

  // Voice recording
  const toggleVoiceRecording = () => {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      alert('Speech Recognition is not supported in this browser.');
      return;
    }

    if (isRecordingVoice) {
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsRecordingVoice(false);
    } else {
      const recognition = new SpeechRec();
      recognition.lang = language === 'mr' ? 'mr-IN' : language === 'hi' ? 'hi-IN' : 'en-US';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setIsRecordingVoice(true);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setVoiceText(transcript);
        setIsRecordingVoice(false);
      };
      recognition.onerror = () => setIsRecordingVoice(false);
      recognition.onend = () => setIsRecordingVoice(false);

      recognitionRef.current = recognition;
      recognition.start();
    }
  };

  // File upload handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      const reader = new FileReader();
      reader.onload = (ev) => {
        setImagePreview(ev.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Analyze Soil
  const runSoilAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/soil/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceType: activeInputTab,
          imageBase64: imagePreview,
          voiceTranscript: voiceText,
          ph,
          nitrogen,
          phosphorus,
          potassium,
          organicCarbon,
          soilType: selectedSoilType,
          district: farmer.district,
        }),
      });
      const data = await res.json();
      if (data.data) {
        setAnalysisResult(data.data);
        // Update local sliders to match extracted values
        if (data.data.ph) setPh(data.data.ph);
        if (data.data.nitrogenKgHa) setNitrogen(data.data.nitrogenKgHa);
        if (data.data.phosphorusKgHa) setPhosphorus(data.data.phosphorusKgHa);
        if (data.data.potassiumKgHa) setPotassium(data.data.potassiumKgHa);
        if (data.data.organicCarbonPercent) setOrganicCarbon(data.data.organicCarbonPercent);
      }
    } catch (err) {
      console.error('Soil analysis failed:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSpeak = (text: string, id: string) => {
    if (isSpeaking && playingId === id) {
      stopSpeaking();
      setPlayingId(null);
    } else {
      setPlayingId(id);
      speakText(text, language);
    }
  };

  if (activeModal !== 'soilHealth') return null;

  // Fertilizer recommendations calculations
  const ureaRec = Math.max(35, Math.round((280 - nitrogen) * 0.45 + 35));
  const dapRec = Math.max(25, Math.round((25 - phosphorus) * 1.5 + 20));
  const mopRec = potassium > 280 ? 15 : 30;

  return (
    <div
      id="soil-health-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-emerald-950/80 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-4xl max-h-[90vh] rounded-3xl bg-white dark:bg-[#072418] border border-emerald-500/30 shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-emerald-500/20 bg-gradient-to-r from-lime-50 via-emerald-50 to-teal-50 dark:from-emerald-950/90 dark:to-[#041d13] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-lime-600 to-emerald-500 text-white flex items-center justify-center shadow-md">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-white font-outfit">
                  {language === 'mr'
                    ? '🧪 डिजिटल मृदा आरोग्य व खत व्यवस्थापन'
                    : language === 'hi'
                    ? '🧪 डिजिटल मृदा स्वास्थ्य व उर्वरक AI'
                    : '🧪 Digital Soil Health Card & Fertilizer AI'}
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-lime-500/20 text-lime-800 dark:text-lime-300 border border-lime-500/30">
                  NPK AI Engine
                </span>
              </div>
              <p className="text-xs text-emerald-700/80 dark:text-emerald-400/80">
                Plot #{farmer.kisanId} • {farmer.soilType}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              stopCamera();
              closeModal();
            }}
            className="p-2 rounded-xl bg-white dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-200 border border-emerald-500/20 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Analysis Running Animation Overlay */}
        {isAnalyzing && (
          <div className="p-8 text-center space-y-4 my-auto">
            <div className="relative w-24 h-24 mx-auto">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
                className="w-full h-full rounded-full border-4 border-dashed border-emerald-500"
              />
              <div className="absolute inset-0 flex items-center justify-center text-3xl">
                🧪
              </div>
            </div>
            <h4 className="text-base font-extrabold text-emerald-950 dark:text-white font-outfit">
              {language === 'mr'
                ? 'तुमच्या मातीचे AI विश्लेषण व खत शिफारस सुरू आहे...'
                : language === 'hi'
                ? 'आपकी मिट्टी का AI विश्लेषण और उर्वरक सिफारिश जारी है...'
                : 'Analyzing Soil Health Parameters with Agronomy AI...'}
            </h4>
            <p className="text-xs text-slate-500 dark:text-emerald-300">
              {language === 'mr'
                ? 'ICAR व कृषी विज्ञान केंद्राच्या मानकांनुसार NPK, pH व सेंद्रिय कर्ब तपासले जात आहे.'
                : 'Calibrating NPK, pH and organic carbon with ICAR agronomist benchmarks.'}
            </p>
          </div>
        )}

        {/* Modal Body */}
        {!isAnalyzing && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            {/* Input Selection Tabs: 📄 Upload / 📸 Camera / 🎤 Voice / 🎚️ Sliders */}
            <div className="p-4 rounded-3xl bg-emerald-50/70 dark:bg-emerald-950/50 border border-emerald-500/20 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-900 dark:text-emerald-300">
                  {language === 'mr' ? 'माती माहिती देण्याची पद्धत निवडा:' : 'Choose Soil Input Method:'}
                </span>

                {/* Tab Pill Buttons */}
                <div className="flex items-center gap-1.5 bg-white dark:bg-emerald-900/60 p-1 rounded-2xl border border-emerald-500/20 overflow-x-auto">
                  <button
                    onClick={() => {
                      stopCamera();
                      setActiveInputTab('sliders');
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
                      activeInputTab === 'sliders'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-emerald-300 hover:bg-emerald-50'
                    }`}
                  >
                    <FlaskConical className="w-3.5 h-3.5" />
                    <span>{language === 'mr' ? 'NPK मूल्ये' : 'NPK Values'}</span>
                  </button>

                  <button
                    onClick={() => {
                      stopCamera();
                      setActiveInputTab('upload');
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
                      activeInputTab === 'upload'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-emerald-300 hover:bg-emerald-50'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>{language === 'mr' ? '📄 रिपोर्ट अपलोड' : 'Upload Report'}</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveInputTab('camera');
                      startCamera();
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
                      activeInputTab === 'camera'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-emerald-300 hover:bg-emerald-50'
                    }`}
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>{language === 'mr' ? '📸 मातीचा फोटो' : 'Soil Photo'}</span>
                  </button>

                  <button
                    onClick={() => {
                      stopCamera();
                      setActiveInputTab('voice');
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
                      activeInputTab === 'voice'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-emerald-300 hover:bg-emerald-50'
                    }`}
                  >
                    <Mic className="w-3.5 h-3.5" />
                    <span>{language === 'mr' ? '🎤 बोलून सांगा' : 'Voice Input'}</span>
                  </button>
                </div>
              </div>

              {/* Mode 1: Sliders Input */}
              {activeInputTab === 'sliders' && (
                <div className="space-y-4 pt-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Nitrogen */}
                    <div className="p-3.5 rounded-2xl bg-white dark:bg-emerald-900/40 border border-emerald-500/20">
                      <div className="flex justify-between text-xs font-bold mb-1.5">
                        <span className="text-emerald-950 dark:text-emerald-100">
                          {language === 'mr' ? 'नत्र (Nitrogen N):' : 'Nitrogen (N):'} {nitrogen} kg/ha
                        </span>
                        <span className={nitrogen < 280 ? 'text-amber-500 font-extrabold' : 'text-emerald-600 font-extrabold'}>
                          {nitrogen < 280 ? (language === 'mr' ? 'कमी (Low)' : 'Low') : (language === 'mr' ? 'उत्तम (Optimal)' : 'Optimal')}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="100"
                        max="600"
                        value={nitrogen}
                        onChange={(e) => setNitrogen(Number(e.target.value))}
                        className="w-full accent-emerald-600 cursor-pointer"
                      />
                      <span className="text-[10px] text-slate-400 block mt-1">
                        सामान्य मर्यादा: २८० - ५६० kg/ha
                      </span>
                    </div>

                    {/* Phosphorus */}
                    <div className="p-3.5 rounded-2xl bg-white dark:bg-emerald-900/40 border border-emerald-500/20">
                      <div className="flex justify-between text-xs font-bold mb-1.5">
                        <span className="text-emerald-950 dark:text-emerald-100">
                          {language === 'mr' ? 'स्फुरद (Phosphorus P):' : 'Phosphorus (P):'} {phosphorus} kg/ha
                        </span>
                        <span className="text-emerald-600 font-extrabold">
                          {language === 'mr' ? 'मध्यम (Medium)' : 'Medium'}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="50"
                        value={phosphorus}
                        onChange={(e) => setPhosphorus(Number(e.target.value))}
                        className="w-full accent-emerald-600 cursor-pointer"
                      />
                      <span className="text-[10px] text-slate-400 block mt-1">
                        सामान्य मर्यादा: १२ - २५ kg/ha
                      </span>
                    </div>

                    {/* Potassium */}
                    <div className="p-3.5 rounded-2xl bg-white dark:bg-emerald-900/40 border border-emerald-500/20">
                      <div className="flex justify-between text-xs font-bold mb-1.5">
                        <span className="text-emerald-950 dark:text-emerald-100">
                          {language === 'mr' ? 'पालाश (Potassium K):' : 'Potassium (K):'} {potassium} kg/ha
                        </span>
                        <span className="text-emerald-600 font-extrabold">
                          {language === 'mr' ? 'भरपूर (High)' : 'High'}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="100"
                        max="500"
                        value={potassium}
                        onChange={(e) => setPotassium(Number(e.target.value))}
                        className="w-full accent-emerald-600 cursor-pointer"
                      />
                      <span className="text-[10px] text-slate-400 block mt-1">
                        सामान्य मर्यादा: १४० - २८० kg/ha
                      </span>
                    </div>

                    {/* pH Value */}
                    <div className="p-3.5 rounded-2xl bg-white dark:bg-emerald-900/40 border border-emerald-500/20">
                      <div className="flex justify-between text-xs font-bold mb-1.5">
                        <span className="text-emerald-950 dark:text-emerald-100">
                          {language === 'mr' ? 'सामू (Soil pH):' : 'Soil pH:'} {ph}
                        </span>
                        <span className="text-emerald-600 font-extrabold">
                          {ph < 6.5 ? 'Acidic' : ph > 7.8 ? 'Alkaline' : (language === 'mr' ? 'सुपीक (Ideal)' : 'Ideal')}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="5.0"
                        max="9.0"
                        step="0.1"
                        value={ph}
                        onChange={(e) => setPh(Number(e.target.value))}
                        className="w-full accent-emerald-600 cursor-pointer"
                      />
                      <span className="text-[10px] text-slate-400 block mt-1">
                        आदर्श श्रेणी: ६.५ ते ७.५ (Neutral)
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <span className="text-xs text-slate-600 dark:text-emerald-300 font-medium">
                      सेंद्रिय कर्ब (Organic Carbon): <strong>{organicCarbon}%</strong> (लक्ष्य: ०.७५%+)
                    </span>
                    <button
                      onClick={runSoilAnalysis}
                      className="px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs flex items-center gap-2 shadow-md transition-all cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>{language === 'mr' ? 'AI शिफारस अपडेट करा' : 'Update AI Recommendations'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Mode 2: Upload File / PDF */}
              {activeInputTab === 'upload' && (
                <div className="space-y-4 pt-2">
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="p-6 rounded-2xl border-2 border-dashed border-emerald-500/40 bg-white/70 dark:bg-emerald-900/30 text-center space-y-2 cursor-pointer hover:bg-emerald-50 transition-colors"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*,.pdf"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <Upload className="w-8 h-8 text-emerald-600 mx-auto" />
                    <div className="text-xs font-bold text-emerald-950 dark:text-white">
                      {uploadedFile ? uploadedFile.name : (language === 'mr' ? 'माती परीक्षण रिपोर्ट (PDF किंवा फोटो) येथे अपलोड करा' : 'Upload Soil Lab Report (PDF/Image)')}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {language === 'mr' ? 'क्लिक करा किंवा फाईल ओढून आणा (JPG, PNG, PDF)' : 'Click to browse or drag and drop'}
                    </p>
                  </div>

                  {imagePreview && (
                    <div className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-emerald-900/40 border border-emerald-500/20">
                      <div className="flex items-center gap-2">
                        <img src={imagePreview} alt="Report Preview" className="w-12 h-12 object-cover rounded-lg" />
                        <span className="text-xs font-bold text-emerald-950 dark:text-white">{uploadedFile?.name || 'Report Photo'}</span>
                      </div>
                      <button
                        onClick={runSoilAnalysis}
                        className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                        <span>{language === 'mr' ? 'रिपोर्ट तपासा' : 'Analyze Report'}</span>
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Mode 3: Camera Capture */}
              {activeInputTab === 'camera' && (
                <div className="space-y-4 pt-2">
                  {isCameraActive ? (
                    <div className="relative rounded-2xl overflow-hidden bg-black aspect-video max-h-64 mx-auto flex items-center justify-center">
                      <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                      <div className="absolute inset-0 border-2 border-emerald-400/60 rounded-2xl pointer-events-none" />
                      <div className="absolute bottom-3 inset-x-0 flex justify-center gap-3">
                        <button
                          onClick={captureSoilPhoto}
                          className="px-5 py-2 rounded-full bg-emerald-500 text-white font-bold text-xs shadow-lg flex items-center gap-2 cursor-pointer"
                        >
                          <Camera className="w-4 h-4" />
                          <span>{language === 'mr' ? 'फोटो काढा' : 'Capture Sample'}</span>
                        </button>
                        <button
                          onClick={stopCamera}
                          className="px-4 py-2 rounded-full bg-black/60 text-white font-bold text-xs cursor-pointer"
                        >
                          {language === 'mr' ? 'रद्द करा' : 'Cancel'}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center p-4 space-y-3">
                      {imagePreview ? (
                        <div className="space-y-3">
                          <img src={imagePreview} alt="Captured Soil" className="w-48 h-36 object-cover rounded-2xl mx-auto border-2 border-emerald-500/40" />
                          <div className="flex justify-center gap-3">
                            <button
                              onClick={startCamera}
                              className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-emerald-900/60 text-slate-800 dark:text-emerald-100 font-bold text-xs cursor-pointer"
                            >
                              🔄 {language === 'mr' ? 'पुन्हा फोटो काढा' : 'Retake'}
                            </button>
                            <button
                              onClick={runSoilAnalysis}
                              className="px-5 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
                            >
                              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                              <span>{language === 'mr' ? 'माती तपासा' : 'Analyze Soil'}</span>
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={startCamera}
                          className="px-6 py-3 rounded-2xl bg-emerald-600 text-white font-extrabold text-xs shadow-lg flex items-center gap-2 mx-auto cursor-pointer"
                        >
                          <Camera className="w-4 h-4" />
                          <span>{language === 'mr' ? 'कॅमेरा उघडा व मातीचा फोटो काढा' : 'Open Camera & Snap Soil'}</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Mode 4: Voice Input */}
              {activeInputTab === 'voice' && (
                <div className="space-y-4 pt-2 text-center">
                  <div className="p-5 rounded-2xl bg-white dark:bg-emerald-900/40 border border-emerald-500/20 space-y-3">
                    <button
                      onClick={toggleVoiceRecording}
                      className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center shadow-lg transition-all cursor-pointer ${
                        isRecordingVoice
                          ? 'bg-rose-500 text-white animate-pulse'
                          : 'bg-emerald-600 text-white hover:scale-105'
                      }`}
                    >
                      {isRecordingVoice ? <MicOff className="w-7 h-7" /> : <Mic className="w-7 h-7" />}
                    </button>

                    <div className="space-y-1">
                      <div className="text-xs font-bold text-emerald-950 dark:text-white">
                        {isRecordingVoice
                          ? (language === 'mr' ? 'तुमचे बोलणे ऐकत आहे... (मातीचा रंग किंवा समस्या सांगा)' : 'Listening... describe soil condition')
                          : (language === 'mr' ? 'माईक दाबून मातीबद्दल बोला' : 'Tap to describe soil')}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        {language === 'mr'
                          ? 'उदा. "माझी काळी कसदार जमीन आहे, कांदा पिकासाठी किती खत टाकावे?"'
                          : 'e.g. "Heavy black soil with low nitrogen, what fertilizer for onion?"'}
                      </p>
                    </div>

                    {voiceText && (
                      <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-500/20 text-xs font-medium text-emerald-900 dark:text-emerald-200">
                        "{voiceText}"
                      </div>
                    )}
                  </div>

                  {voiceText && (
                    <button
                      onClick={runSoilAnalysis}
                      className="px-6 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs flex items-center gap-2 mx-auto shadow-md cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>{language === 'mr' ? 'माहितीचे AI विश्लेषण करा' : 'Run Voice Agronomy Analysis'}</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* 1. Soil Health 5-Parameter Snapshot Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-center">
              {/* pH */}
              <div className="p-3 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-2xs">
                <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-bold">
                  {language === 'mr' ? 'सामू (pH)' : 'Soil pH'}
                </span>
                <span className="text-lg font-black font-mono text-emerald-950 dark:text-white block mt-0.5">
                  {ph}
                </span>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                  {language === 'mr' ? 'सुपीक/आदर्श' : 'Neutral/Ideal'}
                </span>
              </div>

              {/* Nitrogen N */}
              <div className="p-3 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-2xs">
                <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-bold">
                  {language === 'mr' ? 'नत्र (N)' : 'Nitrogen (N)'}
                </span>
                <span className="text-lg font-black font-mono text-amber-600 dark:text-amber-400 block mt-0.5">
                  {nitrogen}
                </span>
                <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold">
                  {language === 'mr' ? 'कमी (Low)' : 'Low'} kg/ha
                </span>
              </div>

              {/* Phosphorus P */}
              <div className="p-3 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-2xs">
                <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-bold">
                  {language === 'mr' ? 'स्फुरद (P)' : 'Phosphorus (P)'}
                </span>
                <span className="text-lg font-black font-mono text-emerald-950 dark:text-white block mt-0.5">
                  {phosphorus}
                </span>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                  {language === 'mr' ? 'मध्यम (Med)' : 'Medium'} kg/ha
                </span>
              </div>

              {/* Potassium K */}
              <div className="p-3 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-2xs">
                <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-bold">
                  {language === 'mr' ? 'पालाश (K)' : 'Potassium (K)'}
                </span>
                <span className="text-lg font-black font-mono text-emerald-950 dark:text-white block mt-0.5">
                  {potassium}
                </span>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                  {language === 'mr' ? 'भरपूर (High)' : 'High'} kg/ha
                </span>
              </div>

              {/* Organic Carbon */}
              <div className="p-3 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-2xs col-span-2 sm:col-span-1">
                <span className="text-[10px] text-slate-500 dark:text-zinc-400 block font-bold">
                  {language === 'mr' ? 'सेंद्रिय कर्ब' : 'Organic Carbon'}
                </span>
                <span className="text-lg font-black font-mono text-emerald-950 dark:text-white block mt-0.5">
                  {organicCarbon}%
                </span>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                  {language === 'mr' ? 'सुधारणा योग्य' : 'Target 0.75%'}
                </span>
              </div>
            </div>

            {/* 2. Recommended Fertilizer Dose per Acre (Exact Schedule) */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-emerald-900 dark:text-emerald-300 flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-emerald-600" />
                  <span>
                    {language === 'mr'
                      ? 'प्रति एकर शिफारस खत मात्रा (Fertilizer Blueprint)'
                      : 'Recommended Fertilizer Dose per Acre:'}
                  </span>
                </h4>

                <button
                  onClick={() =>
                    handleSpeak(
                      language === 'mr'
                        ? `प्रति एकर खत शिफारस: युरिया ${ureaRec} किलो, डीएपी ${dapRec} किलो, आणि पोटॅश ${mopRec} किलो.`
                        : `Fertilizer recommendation: Urea ${ureaRec} kg, DAP ${dapRec} kg, Potash ${mopRec} kg per acre.`,
                      'fertilizer-audio'
                    )
                  }
                  className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-xs flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                >
                  {isSpeaking && playingId === 'fertilizer-audio' ? (
                    <VolumeX className="w-3.5 h-3.5" />
                  ) : (
                    <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                  )}
                  <span>🔊 {language === 'mr' ? 'ऐका' : 'Listen'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 text-center space-y-1">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300 block">
                    {language === 'mr' ? 'युरिया (Urea ४६% N)' : 'Urea (46% N)'}
                  </span>
                  <span className="text-2xl font-black text-emerald-950 dark:text-white font-mono block">
                    {ureaRec} kg
                  </span>
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold block">
                    {language === 'mr' ? '२ हप्त्यांत विभागून द्या' : '2 Split Applications'}
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 text-center space-y-1">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300 block">
                    {language === 'mr' ? 'डीएपी (DAP १८:४६:०)' : 'DAP (18-46-0)'}
                  </span>
                  <span className="text-2xl font-black text-emerald-950 dark:text-white font-mono block">
                    {dapRec} kg
                  </span>
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold block">
                    {language === 'mr' ? 'पेरणीच्या वेळी जमिनीत' : 'Basal at Sowing'}
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 text-center space-y-1">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300 block">
                    {language === 'mr' ? 'एमओपी (Potash ६०%)' : 'MOP (Potash 60%)'}
                  </span>
                  <span className="text-2xl font-black text-emerald-950 dark:text-white font-mono block">
                    {mopRec} kg
                  </span>
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold block">
                    {language === 'mr' ? 'पेरणी किंवा फुलोरा' : 'Sowing or Pre-flowering'}
                  </span>
                </div>
              </div>
            </div>

            {/* 3. Suitable Crops for this Soil */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-emerald-900 dark:text-emerald-300 flex items-center gap-2">
                  <Sprout className="w-4 h-4 text-emerald-600" />
                  <span>
                    {language === 'mr' ? 'या जमिनीसाठी सर्वाधिक फायदेशीर पिके' : 'Recommended Suitable Crops:'}
                  </span>
                </h4>

                <button
                  onClick={() =>
                    handleSpeak(
                      language === 'mr'
                        ? 'या मातीसाठी कांदा, सोयाबीन, हरभरा आणि भाजीपाला पिके सर्वाधिक अनुकूल आहेत.'
                        : 'Recommended crops for this soil are Onion, Soybean, Chickpea, and Vegetables.',
                      'crops-audio'
                    )
                  }
                  className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-xs flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                >
                  {isSpeaking && playingId === 'crops-audio' ? (
                    <VolumeX className="w-3.5 h-3.5" />
                  ) : (
                    <Volume2 className="w-3.5 h-3.5" />
                  )}
                  <span>🔊 {language === 'mr' ? 'ऐका' : 'Listen'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {(analysisResult?.suitableCrops || [
                  {
                    nameMr: 'कांदा (Onion)',
                    nameEn: 'Onion',
                    icon: '🧅',
                    reasonMr: 'pH ७.२ व मध्यम स्फुरद असल्याने कांद्याच्या आकाराची व साठवणूक क्षमतेची वाढ उत्तम होईल.',
                    reasonEn: 'Neutral pH ensures high bulb size & storage longevity.',
                  },
                  {
                    nameMr: 'कापूस व सोयाबीन',
                    nameEn: 'Cotton & Soybean',
                    icon: '🌱',
                    reasonMr: 'काळी कसदार जमीन ओलावा टिकवून ठेवते, ज्यामुळे बोंडांचा विकास चांगला होतो.',
                    reasonEn: 'Black soil moisture retention boosts boll development.',
                  },
                  {
                    nameMr: 'हरभरा (चना)',
                    nameEn: 'Gram / Chickpea',
                    icon: '🌾',
                    reasonMr: 'रब्बी हंगामात हरभऱ्याच्या मुळांमधील गाठी हवेतील नत्र जमिनीत स्थिर करतील.',
                    reasonEn: 'Fixes atmospheric nitrogen through root nodules.',
                  },
                  {
                    nameMr: 'टोमॅटो व भाजीपाला',
                    nameEn: 'Tomato & Vegetables',
                    icon: '🍅',
                    reasonMr: 'भरपूर पोटॅशियम असल्यामुळे फळांना उत्तम चकाकी, रंग व रोगांशी लढण्याची ताकद मिळते.',
                    reasonEn: 'High potassium offers disease resistance & fruit shine.',
                  },
                ]).map((crop, i) => (
                  <div
                    key={i}
                    className="p-3.5 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 flex items-start gap-3"
                  >
                    <span className="text-2xl shrink-0">{crop.icon}</span>
                    <div>
                      <h5 className="font-extrabold text-emerald-950 dark:text-emerald-100 font-outfit">
                        {language === 'mr' ? crop.nameMr : crop.nameEn}
                      </h5>
                      <p className="text-slate-600 dark:text-slate-300 text-[11px] mt-0.5">
                        {language === 'mr' ? crop.reasonMr : crop.reasonEn}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 4. Soil Improvement & Bio-Carbon Advice */}
            <div className="p-4 sm:p-5 rounded-3xl bg-lime-500/10 border border-lime-500/30 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-emerald-950 dark:text-emerald-100 flex items-center gap-2 text-xs sm:text-sm font-outfit">
                  <Leaf className="w-4 h-4 text-emerald-600" />
                  <span>
                    {language === 'mr'
                      ? '🌿 जमीन सुधारणा व सेंद्रिय कर्ब वाढवणे (Soil Revival)'
                      : 'Soil Improvement & Bio-Carbon Revival:'}
                  </span>
                </span>

                <button
                  onClick={() =>
                    handleSpeak(
                      language === 'mr'
                        ? 'सेंद्रिय कर्ब वाढवण्यासाठी प्रति एकर २ ते ३ टन चांगले कुजलेले शेणखत किंवा गांडूळखत मिसळा आणि पेरणीपूर्वी ट्रायकोडर्मा वापरा.'
                        : 'Apply 2-3 tonnes FYM or vermicompost per acre to elevate organic carbon and use Trichoderma viride.',
                      'bio-carbon-audio'
                    )
                  }
                  className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-xs flex items-center gap-1 shadow-sm transition-all cursor-pointer shrink-0"
                >
                  {isSpeaking && playingId === 'bio-carbon-audio' ? (
                    <VolumeX className="w-3.5 h-3.5" />
                  ) : (
                    <Volume2 className="w-3.5 h-3.5" />
                  )}
                  <span>🔊 {language === 'mr' ? 'ऐका' : 'Listen'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-zinc-700 dark:text-zinc-300">
                <div className="p-3 rounded-2xl bg-white dark:bg-emerald-900/30 border border-emerald-500/15">
                  <strong className="text-emerald-800 dark:text-emerald-300 block mb-1">
                    {language === 'mr' ? '१. शेणखत / गांडूळखत:' : '1. Organic Manure:'}
                  </strong>
                  {language === 'mr'
                    ? 'प्रति एकर २ ते ३ टन कुजलेले शेणखत मिसळा, ज्यामुळे सेंद्रिय कर्ब ०.७५% पर्यंत वाढेल.'
                    : 'Apply 2-3 tonnes FYM to reach 0.75% target organic carbon.'}
                </div>

                <div className="p-3 rounded-2xl bg-white dark:bg-emerald-900/30 border border-emerald-500/15">
                  <strong className="text-emerald-800 dark:text-emerald-300 block mb-1">
                    {language === 'mr' ? '२. ट्रायकोडर्मा जिवाणू:' : '2. Trichoderma Viride:'}
                  </strong>
                  {language === 'mr'
                    ? '१ किलो ट्रायकोडर्मा ५० किलो शेणखतात मिसळून पसरल्यास बुरशीजन्य रोगांपासून मुळांचे संरक्षण होते.'
                    : 'Mix 1kg Trichoderma in 50kg FYM to prevent soil wilt pathogens.'}
                </div>

                <div className="p-3 rounded-2xl bg-white dark:bg-emerald-900/30 border border-emerald-500/15">
                  <strong className="text-emerald-800 dark:text-emerald-300 block mb-1">
                    {language === 'mr' ? '३. सिंचन व आच्छादन:' : '3. Soil Irrigation:'}
                  </strong>
                  {language === 'mr'
                    ? 'काळी कसदार जमीन असल्याने दर ४ ते ५ दिवसांनी ठिबक सिंचन द्या व पालापाचोळ्याचे आच्छादन करा.'
                    : 'Deep soil holds moisture well; irrigate every 4-5 days via drip.'}
                </div>
              </div>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
