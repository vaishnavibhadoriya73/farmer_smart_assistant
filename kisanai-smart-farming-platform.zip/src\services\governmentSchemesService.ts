import { SCHEMES_DATABASE, DetailedGovtSchemeRecord } from '../data/schemesDatabase';
import { INDIAN_STATES_AND_UTS, StateInfo } from '../data/indianStates';

export interface SchemeFilterOptions {
  state?: string; // e.g. 'Maharashtra' or 'All'
  category?: string; // e.g. 'Farmer Income Support' or 'All'
  schemeType?: 'All' | 'Central' | 'State';
  searchQuery?: string;
  benefitType?: string;
}

export interface EligibilityAssistantInput {
  state: string;
  landAcres: number;
  cropCategory: string;
  farmerType: 'Small/Marginal (< 5 Acres)' | 'Medium/Large (> 5 Acres)' | 'Tenant/Sharecropper' | 'Woman Farmer' | 'SC/ST Farmer';
  irrigationType: 'Drip/Sprinkler' | 'Borewell/Well' | 'Canal' | 'Rainfed';
  primaryActivity: 'Crops Cultivation' | 'Horticulture' | 'Dairy/Livestock' | 'Fisheries' | 'Organic Farming' | 'Infrastructure/Machinery';
}

export interface SchemeMatchResult extends DetailedGovtSchemeRecord {
  matchPercentage: number;
  matchReasonsEn: string[];
  matchReasonsHi: string[];
  matchReasonsMr: string[];
}

export class GovernmentSchemesService {
  /**
   * Fetch all schemes with optional filters.
   * Can call backend API `/api/schemes/live` or fallback cleanly to static authentic records.
   */
  public async getSchemes(filters?: SchemeFilterOptions): Promise<{
    schemes: DetailedGovtSchemeRecord[];
    totalCount: number;
    lastUpdated: string;
    source: string;
  }> {
    try {
      // Attempt API call if available
      const response = await fetch('/api/schemes/live', {
        headers: { 'Accept': 'application/json' }
      });
      if (response.ok) {
        const data = await response.json();
        if (data && Array.isArray(data.schemes)) {
          const filtered = this.applyFilters(data.schemes, filters);
          return {
            schemes: filtered,
            totalCount: filtered.length,
            lastUpdated: data.lastUpdated || new Date().toISOString().split('T')[0],
            source: data.source || 'Official Government Portals (myScheme.gov.in / Ministry of Agri)'
          };
        }
      }
    } catch {
      // Clean fallback if API is offline or un-networked
    }

    const filtered = this.applyFilters(SCHEMES_DATABASE, filters);
    return {
      schemes: filtered,
      totalCount: filtered.length,
      lastUpdated: '2026-09-05',
      source: 'Official Government Portals (myScheme.gov.in, Ministry of Agriculture & Farmers Welfare, State DBs)'
    };
  }

  /**
   * Get all Indian States and UTs metadata
   */
  public getStatesList(): StateInfo[] {
    return INDIAN_STATES_AND_UTS;
  }

  /**
   * Get state specific overview along with matching central and state schemes
   */
  public getStateExplorerOverview(stateName: string): {
    stateInfo: StateInfo | undefined;
    stateSchemes: DetailedGovtSchemeRecord[];
    applicableCentralSchemes: DetailedGovtSchemeRecord[];
    totalAvailableSchemesCount: number;
  } {
    const stateInfo = INDIAN_STATES_AND_UTS.find(s => 
      s.name.toLowerCase() === stateName.toLowerCase() ||
      s.code.toLowerCase() === stateName.toLowerCase()
    );

    const stateSchemes = SCHEMES_DATABASE.filter(s => 
      s.schemeType === 'State' && 
      s.state.toLowerCase() === stateName.toLowerCase()
    );

    const applicableCentralSchemes = SCHEMES_DATABASE.filter(s => 
      s.schemeType === 'Central' || s.state === 'All India'
    );

    return {
      stateInfo,
      stateSchemes,
      applicableCentralSchemes,
      totalAvailableSchemesCount: stateSchemes.length + applicableCentralSchemes.length
    };
  }

  /**
   * Eligibility Wizard AI Assistant calculation
   */
  public calculateEligibleSchemes(input: EligibilityAssistantInput): SchemeMatchResult[] {
    const results: SchemeMatchResult[] = SCHEMES_DATABASE.map(scheme => {
      let score = 50; // base score for active genuine schemes
      const reasonsEn: string[] = [];
      const reasonsHi: string[] = [];
      const reasonsMr: string[] = [];

      // State check
      if (scheme.state === 'All India' || scheme.state.toLowerCase() === input.state.toLowerCase()) {
        score += 20;
        reasonsEn.push(`Applicable in your state (${input.state})`);
        reasonsHi.push(`आपके राज्य (${input.state}) में लागू`);
        reasonsMr.push(`तुमच्या राज्यात (${input.state}) लागू`);
      }

      // Farmer land size check
      if (input.landAcres <= 5) {
        if (scheme.category === 'Farmer Income Support' || scheme.category === 'Crop Insurance' || scheme.category === 'Farm Machinery') {
          score += 15;
          reasonsEn.push('Higher subsidy priority for small & marginal farmers (< 5 Acres)');
          reasonsHi.push('छोटे व सीमांत किसानों को उच्च प्राथमिकता');
          reasonsMr.push('लहान व अल्पभूधारक शेतकऱ्यांसाठी प्राधान्य');
        }
      }

      // Farming activity matching
      if (input.primaryActivity === 'Horticulture' && scheme.category === 'Horticulture') {
        score += 20;
        reasonsEn.push('Directly tailored for Horticulture crops');
        reasonsHi.push('बागवानी फसलों के लिए विशेष रूप से उपयुक्त');
        reasonsMr.push('फलोत्पादन व भाजीपाला पिकांसाठी उपयुक्त');
      } else if (input.primaryActivity === 'Dairy/Livestock' && scheme.category === 'Dairy & Livestock') {
        score += 25;
        reasonsEn.push('Specifically designed for Livestock & Dairy enterprise');
        reasonsHi.push('पशुपालन और डेयरी के लिए विशेष योजना');
        reasonsMr.push('पशुसंवर्धन आणि दुग्धव्यवसायासाठी विशेष योजना');
      } else if (input.primaryActivity === 'Fisheries' && scheme.category === 'Fisheries') {
        score += 25;
        reasonsEn.push('Tailored for Inland/Marine Fisheries');
        reasonsHi.push('मत्स्य पालन के लिए समर्पित');
        reasonsMr.push('मत्स्यपालनासाठी समर्पित');
      } else if (input.primaryActivity === 'Organic Farming' && scheme.category === 'Organic Farming') {
        score += 25;
        reasonsEn.push('Provides direct organic input financial grant');
        reasonsHi.push('जैविक खाद और प्रमाणीकरण के लिए वित्तीय अनुदान');
        reasonsMr.push('सेंद्रिय खते व प्रमाणपत्रासाठी आर्थिक मदत');
      }

      // Irrigation check
      if (input.irrigationType === 'Drip/Sprinkler' && scheme.category === 'Irrigation') {
        score += 20;
        reasonsEn.push('Covers up to 80% Drip/Sprinkler micro-irrigation subsidy');
        reasonsHi.push('ड्रिप/तुषार सिंचाई पर 80% तक सब्सिडी कवर');
        reasonsMr.push('ठिबक सिंचनावर ८०% पर्यंत अनुदान');
      }

      // Special farmer categories (Woman / SC / ST)
      if (input.farmerType === 'Woman Farmer' || input.farmerType === 'SC/ST Farmer') {
        if (scheme.category === 'Farm Machinery' || scheme.category === 'Agriculture Subsidy' || scheme.category === 'Dairy & Livestock') {
          score += 15;
          reasonsEn.push('Additional 10%-20% subsidy bonus for Woman / SC / ST farmers');
          reasonsHi.push('महिला / एससी / एसटी किसानों के लिए 10%-20% अतिरिक्त सब्सिडी');
          reasonsMr.push('महिला व मागासवर्गीय शेतकऱ्यांसाठी अतिरिक्त अनुदान');
        }
      }

      const matchPercentage = Math.min(Math.max(score, 60), 98);

      return {
        ...scheme,
        matchPercentage,
        matchReasonsEn: reasonsEn.length > 0 ? reasonsEn : ['Matches basic agricultural landholding criteria'],
        matchReasonsHi: reasonsHi.length > 0 ? reasonsHi : ['आपकी बुनियादी कृषि भूमि मानदंड से मेल खाता है'],
        matchReasonsMr: reasonsMr.length > 0 ? reasonsMr : ['मूलभूत शेती निकषांशी जुळते']
      };
    });

    return results.sort((a, b) => b.matchPercentage - a.matchPercentage);
  }

  private applyFilters(schemes: DetailedGovtSchemeRecord[], filters?: SchemeFilterOptions): DetailedGovtSchemeRecord[] {
    if (!filters) return schemes;

    return schemes.filter(scheme => {
      // Filter by state
      if (filters.state && filters.state !== 'All') {
        const matchesState = scheme.state === 'All India' || scheme.state.toLowerCase() === filters.state.toLowerCase();
        if (!matchesState) return false;
      }

      // Filter by category
      if (filters.category && filters.category !== 'All') {
        if (scheme.category.toLowerCase() !== filters.category.toLowerCase()) return false;
      }

      // Filter by central/state type
      if (filters.schemeType && filters.schemeType !== 'All') {
        if (scheme.schemeType !== filters.schemeType) return false;
      }

      // Filter by benefit type
      if (filters.benefitType && filters.benefitType !== 'All') {
        if (scheme.benefitType !== filters.benefitType) return false;
      }

      // Search query filter
      if (filters.searchQuery && filters.searchQuery.trim() !== '') {
        const query = filters.searchQuery.toLowerCase().trim();
        const matchesSearch = 
          scheme.schemeNameEn.toLowerCase().includes(query) ||
          scheme.schemeNameHi.toLowerCase().includes(query) ||
          scheme.schemeNameMr.toLowerCase().includes(query) ||
          scheme.departmentEn.toLowerCase().includes(query) ||
          scheme.shortDescEn.toLowerCase().includes(query) ||
          scheme.category.toLowerCase().includes(query) ||
          scheme.state.toLowerCase().includes(query);
        
        if (!matchesSearch) return false;
      }

      return true;
    });
  }
}

export const governmentSchemesService = new GovernmentSchemesService();
