import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard,
  Home,
  Scan,
  Sprout,
  Calendar,
  CloudSun,
  TrendingUp,
  Landmark,
  Truck,
  Bot,
  BarChart3,
  User,
  LogOut,
  ChevronLeft,
  ChevronRight,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { KisanLogo } from './KisanLogo';

interface SidebarProps {
  activeView: string;
  onNavigate: (viewKey: string) => void;
  isOpenMobile: boolean;
  setIsOpenMobile: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onNavigate,
  isOpenMobile,
  setIsOpenMobile,
}) => {
  const { openModal, logoutFarmer, language, farmer } = useApp();
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);

  const navItems = [
    { key: 'dashboard', labelEn: 'Dashboard', labelHi: 'डैशबोर्ड', labelMr: 'डॅशबोर्ड', icon: LayoutDashboard, isModal: false },
    { key: 'home', labelEn: 'Home', labelHi: 'होम पेज', labelMr: 'मुख्य पान', icon: Home, isModal: false },
    { key: 'diagnose', labelEn: 'AI Disease Detection', labelHi: 'फसल रोग निदान', labelMr: 'पिक रोग निदान', icon: Scan, isModal: true },
    { key: 'cropRecommendation', labelEn: 'Crop Recommendation', labelHi: 'सर्वश्रेष्ठ फसल सलाह', labelMr: 'उत्कृष्ट पिक निवड', icon: Sprout, isModal: true },
    { key: 'cropLifecycle', labelEn: 'Crop Planning', labelHi: 'फसल कार्य योजना', labelMr: 'पिक काम नियोजन', icon: Calendar, isModal: true },
    { key: 'weatherAdvisory', labelEn: 'Weather Radar', labelHi: 'मौसम पूर्वानुमान', labelMr: 'हवामान अंदाज', icon: CloudSun, isModal: true },
    { key: 'mandiPrices', labelEn: 'Live Mandi Prices', labelHi: 'लाइव मंडी भाव', labelMr: 'थेट मंडी भाव', icon: TrendingUp, isModal: true },
    { key: 'schemes', labelEn: 'Government Schemes', labelHi: 'सरकारी योजनाएँ', labelMr: 'सरकारी योजना', icon: Landmark, isModal: true },
    { key: 'supplyChain', labelEn: 'Smart Supply Chain', labelHi: 'स्मार्ट सप्लाई चेन', labelMr: 'स्मार्ट सप्लाय चेन', icon: Truck, isModal: true },
    { key: 'askAi', labelEn: 'AI Farmer Assistant', labelHi: 'किसान AI सहायक', labelMr: 'किसान AI सहाय्यक', icon: Bot, isModal: true },
    { key: 'marketIntelligence', labelEn: 'Market Insights', labelHi: 'बाजार विश्लेषण', labelMr: 'बाजार विश्लेषण', icon: BarChart3, isModal: true },
  ];

  const handleNavClick = (item: typeof navItems[0]) => {
    if (item.isModal) {
      openModal(item.key as any);
    } else {
      onNavigate(item.key);
    }
    setIsOpenMobile(false);
  };

  const getLabel = (item: typeof navItems[0]) => {
    return language === 'mr' ? item.labelMr : language === 'hi' ? item.labelHi : item.labelEn;
  };

  return (
    <>
      {/* Desktop Collapsible Light Theme Sidebar */}
      <aside
        className={`hidden md:flex flex-col bg-white border-r border-emerald-100 text-slate-800 shadow-sm transition-all duration-300 relative z-30 ${
          isCollapsed ? 'w-20' : 'w-64'
        }`}
      >
        {/* Top Header Logo */}
        <div className="p-4 flex items-center justify-between border-b border-emerald-100/80 bg-emerald-50/40">
          <KisanLogo size="sm" showText={!isCollapsed} showTagline={false} />
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1.5 rounded-xl bg-white text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 border border-emerald-100 transition shadow-xs"
            title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Items List */}
        <div className="flex-1 overflow-y-auto py-3 px-3 space-y-1 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.key;

            return (
              <button
                key={item.key}
                onClick={() => handleNavClick(item)}
                className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl font-semibold text-xs transition ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                    : 'text-slate-700 hover:bg-emerald-50/80 hover:text-emerald-800'
                }`}
                title={getLabel(item)}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-emerald-600'}`} />
                {!isCollapsed && <span className="truncate">{getLabel(item)}</span>}
              </button>
            );
          })}
        </div>

        {/* Bottom Profile & Logout Controls */}
        <div className="p-3 border-t border-emerald-100/80 bg-emerald-50/30 space-y-1">
          <button
            onClick={() => openModal('profile')}
            className="w-full flex items-center space-x-3 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-emerald-100/60 hover:text-emerald-900 transition"
          >
            <User className="w-4 h-4 text-emerald-600 shrink-0" />
            {!isCollapsed && <span className="truncate">{farmer?.fullName || 'Farmer Profile'}</span>}
          </button>

          <button
            onClick={() => logoutFarmer()}
            className="w-full flex items-center space-x-3 px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 transition"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            {!isCollapsed && <span>{language === 'mr' ? 'लॉगआउट' : language === 'hi' ? 'लॉगआउट' : 'Logout'}</span>}
          </button>
        </div>
      </aside>

      {/* Mobile Drawer Navigation Overlay */}
      <AnimatePresence>
        {isOpenMobile && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpenMobile(false)}
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs"
            />

            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative w-4/5 max-w-xs bg-white border-r border-emerald-100 h-full flex flex-col z-10 text-slate-800 shadow-2xl"
            >
              <div className="p-4 flex items-center justify-between border-b border-emerald-100 bg-emerald-50/40">
                <KisanLogo size="sm" showTagline={false} />
                <button onClick={() => setIsOpenMobile(false)} className="p-1.5 bg-emerald-100/50 text-slate-600 rounded-xl">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-3 space-y-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeView === item.key;
                  return (
                    <button
                      key={item.key}
                      onClick={() => handleNavClick(item)}
                      className={`w-full flex items-center space-x-3 px-3.5 py-3 rounded-xl font-semibold text-xs transition ${
                        isActive ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-700 hover:bg-emerald-50'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-emerald-600'}`} />
                      <span>{getLabel(item)}</span>
                    </button>
                  );
                })}
              </div>

              <div className="p-4 border-t border-emerald-100 bg-emerald-50/30 space-y-2">
                <button
                  onClick={() => {
                    setIsOpenMobile(false);
                    openModal('profile');
                  }}
                  className="w-full py-2.5 bg-emerald-600 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-2 shadow-sm"
                >
                  <User className="w-4 h-4" />
                  <span>{language === 'mr' ? 'प्रोफाईल व माहिती' : language === 'hi' ? 'प्रोफाइल एवं विवरण' : 'Profile & Details'}</span>
                </button>
                <button
                  onClick={() => {
                    setIsOpenMobile(false);
                    logoutFarmer();
                  }}
                  className="w-full py-2.5 bg-rose-50 text-rose-700 font-bold rounded-xl text-xs border border-rose-200"
                >
                  {language === 'mr' ? 'लॉगआउट करा' : language === 'hi' ? 'लॉगआउट करें' : 'Logout'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
