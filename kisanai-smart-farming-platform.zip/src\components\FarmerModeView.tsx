import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Mic,
  Volume2,
  Scan,
  Sprout,
  CloudSun,
  TrendingUp,
  Landmark,
  FlaskConical,
  Sparkles,
  ArrowRight,
  RefreshCw,
  MapPin,
  CheckCircle,
  ChevronRight,
  ShieldCheck,
  Droplets,
  AlertTriangle,
  Calendar,
  Check,
  DollarSign,
  Sun,
  Wind,
  Phone,
  Play,
  Square,
  Compass,
  LogOut,
  Navigation,
  Truck,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { LiveMandiTicker } from './LiveMandiTicker';
import {
  DEFAULT_DAILY_FARM_PLAN,
  DEFAULT_SMART_NOTIFICATIONS,
} from '../data/mockAgriData';
import { LanguageCode, SmartNotificationItem } from '../types';

export const FarmerModeView: React.FC = () => {
  const {
    language,
    setLanguage,
    openModal,
    farmer,
    crops,
    speakText,
    isSpeaking,
    stopSpeaking,
    logoutFarmer,
    t,
  } = useApp();

  // State for Daily Farm Plan and Smart Notifications
  const [dailyPlan, setDailyPlan] = useState(DEFAULT_DAILY_FARM_PLAN);
  const [notifications, setNotifications] = useState<SmartNotificationItem[]>(DEFAULT_SMART_NOTIFICATIONS);
  const [completedTasks, setCompletedTasks] = useState<Record<string, boolean>>({
    'task-3': true,
  });
  const [activeSpeakingId, setActiveSpeakingId] = useState<string | null>(null);

  useEffect(() => {
    // Fetch live daily plan and notifications
    fetch('/api/daily-plan')
      .then((res) => res.json())
      .then((data) => {
        if (data.data) setDailyPlan(data.data);
      })
      .catch(() => {});

    fetch('/api/smart-notifications')
      .then((res) => res.json())
      .then((data) => {
        if (data.data) setNotifications(data.data);
      })
      .catch(() => {});
  }, []);

  const getLanguageLabel = (code: LanguageCode) => {
    switch (code) {
      case 'mr':
        return 'मराठी';
      case 'hi':
        return 'हिन्दी';
      case 'en':
        return 'English';
      case 'pa':
        return 'ਪੰਜਾਬੀ';
      default:
        return (code as string).toUpperCase();
    }
  };

  // Toggle individual task completion
  const handleToggleTask = (taskId: string) => {
    setCompletedTasks((prev) => ({
      ...prev,
      [taskId]: !prev[taskId],
    }));
  };

  // Voice handler: "🎤 आज मला काय करायचे?"
  const handleSpeakDailyPlan = () => {
    if (isSpeaking && activeSpeakingId === 'daily-plan') {
      stopSpeaking();
      setActiveSpeakingId(null);
      return;
    }

    setActiveSpeakingId('daily-plan');
    const textToSpeak =
      language === 'mr'
        ? dailyPlan.fullVoicePlanMr
        : language === 'hi'
        ? dailyPlan.fullVoicePlanHi
        : dailyPlan.fullVoicePlanEn;

    speakText(textToSpeak, language);
  };

  // Voice handler for single notification alert
  const handleSpeakNotification = (notif: SmartNotificationItem) => {
    if (isSpeaking && activeSpeakingId === notif.id) {
      stopSpeaking();
      setActiveSpeakingId(null);
      return;
    }

    setActiveSpeakingId(notif.id);
    const text =
      language === 'mr'
        ? notif.audioNarrationMr
        : language === 'hi'
        ? notif.audioNarrationHi
        : notif.audioNarrationEn;

    speakText(text, language);
  };

  const primaryCrop = crops[0] || {
    name: 'कापूस (Cotton)',
    stage: 'बोंड भरणे (Boll Formation)',
    health: 'उत्कृष्ट (Healthy)',
    acres: 3.5,
    daysLeft: 42,
  };

  return (
    <>
      {/* Live APMC Mandi Ticker Bar */}
      <LiveMandiTicker />
      <div id="kisanai-farmer-home-view" className="max-w-5xl mx-auto px-3 sm:px-6 py-4 space-y-6 pb-28">
      {/* 1. TOP BAR: Farmer Greeting, Location, Language Switcher & Logout */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white/80 dark:bg-emerald-950/60 backdrop-blur-xl p-4 rounded-3xl border border-emerald-500/30 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 via-emerald-500 to-teal-400 p-0.5 shadow-lg shadow-emerald-500/30 overflow-hidden shrink-0">
            <img
              src={farmer.avatarUrl || '/assets/farmer_avatar_1.jpg'}
              alt={farmer.name || farmer.fullName || 'Farmer'}
              className="w-full h-full object-cover rounded-[14px]"
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-white dark:border-emerald-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-black text-slate-900 dark:text-white font-outfit">
                {language === 'mr' ? 'नमस्कार,' : language === 'hi' ? 'नमस्ते,' : 'Welcome,'} {farmer.fullName || farmer.name || 'शेतकरी मित्र'}
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                PRO KISAN
              </span>
            </div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 dark:text-emerald-300/90 font-medium">
                <button
                  onClick={() => openModal('gpsTracker')}
                  className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold hover:underline cursor-pointer bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20"
                  title="Open Live GPS & Google Map"
                >
                  <MapPin className="w-3 h-3 text-emerald-500 animate-bounce" />
                  <span>{farmer.location || farmer.district || 'नाशिक, महाराष्ट्र'}</span>
                  <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-mono">📍 GPS Map</span>
                </button>
                {farmer.landArea ? (
                  <>
                    <span>•</span>
                    <span>{farmer.landArea} {t('acres')}</span>
                  </>
                ) : null}
              </div>
            </div>
          </div>

          {/* Language switcher + GPS Map + Voice Call + Logout */}
          <div className="flex items-center gap-2 self-end sm:self-center flex-wrap">
            <button
              onClick={() => openModal('gpsTracker')}
              className="flex items-center gap-1 px-3 py-1.5 rounded-2xl bg-gradient-to-r from-teal-500/20 to-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30 text-xs font-black cursor-pointer shadow-xs"
              title="Open Google Maps GPS Farm Tracker"
            >
              <Navigation className="w-3.5 h-3.5 text-emerald-500" />
              <span>{language === 'mr' ? '📍 Google Map' : '📍 GPS Map'}</span>
            </button>

            <div className="flex items-center bg-slate-100 dark:bg-black/40 rounded-2xl p-1 border border-emerald-500/20">
              {(['mr', 'hi', 'en'] as const).map((lang) => (
                <button
                  key={lang}
                  id={`farmer-home-lang-${lang}`}
                  onClick={() => setLanguage(lang)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    language === lang
                      ? 'bg-emerald-500 text-white shadow-md'
                      : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {getLanguageLabel(lang)}
                </button>
              ))}
            </div>

            <button
              id="farmer-home-call-kisan-btn"
              onClick={() => {
                const text =
                  language === 'mr'
                    ? 'शेतकरी मदत कॉल: १८००-१८०-१५५१ (Kisan Call Center टोल फ्री)'
                    : 'Kisan Helpline: 1800-180-1551 (Toll Free)';
                speakText(text, language);
              }}
              className="p-2.5 rounded-2xl bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30 transition-all cursor-pointer"
              title="Kisan Call Center"
            >
              <Phone className="w-4 h-4" />
            </button>

            <button
              id="farmer-home-logout-btn"
              onClick={logoutFarmer}
              className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-rose-500/10 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/30 hover:bg-rose-500/20 transition-all text-xs font-bold cursor-pointer"
              title={language === 'mr' ? 'लॉगआउट करा (Sign out)' : language === 'hi' ? 'लॉगआउट करें (Sign out)' : 'Logout (Sign out)'}
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">
                {language === 'mr' ? 'लॉगआउट' : language === 'hi' ? 'लॉगआउट' : 'Logout'}
              </span>
            </button>
          </div>
        </div>

      {/* 2. PROMINENT CROP DISEASE SCANNER BANNER (Hero Action with Real Farmer Backdrop) */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-900 via-teal-900 to-emerald-950 p-5 sm:p-7 text-white shadow-2xl shadow-emerald-950/50 border-2 border-emerald-400/40 group">
        {/* Background Image of Farmer */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <img
            src="/assets/farmer_hero.jpg"
            alt="Farmer in Field"
            className="w-full h-full object-cover object-right opacity-30 mix-blend-luminosity group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-950 via-emerald-950/85 to-transparent" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div className="space-y-2.5 max-w-lg">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/20 backdrop-blur-md text-xs font-black tracking-wide border border-emerald-400/40 text-emerald-200">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'mr' ? 'AI २.५ पिक रोग कॅमेरा' : language === 'hi' ? 'AI २.५ फसल रोग कैमरा' : 'AI 2.5 Crop Diagnosis'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black leading-tight font-outfit">
              {language === 'mr'
                ? 'पिकावर रोग किंवा किड आहे? फोटो काढा, उपाय मिळवा!'
                : language === 'hi'
                ? 'फसल पर रोग या कीट है? फोटो खींचें, तुरंत इलाज पाएं!'
                : 'Crop pest or leaf disease? Take a photo, get instant remedy!'}
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
              {language === 'mr'
                ? 'कापूस, गहू, भात, सोयाबीन, टोमॅटो, मिरची, मका सह सर्व पिकांचे अचूक निदान व फवारणी डोस.'
                : 'Accurate pathology for Cotton, Wheat, Rice, Soybean, Tomato, Chilli, Maize & more.'}
            </p>
          </div>

          <button
            id="farmer-home-hero-diagnose-btn"
            onClick={() => openModal('diagnose')}
            className="w-full md:w-auto px-7 py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-emerald-950 font-black text-sm sm:text-base flex items-center justify-center gap-3 shadow-xl shadow-emerald-500/30 hover:scale-105 active:scale-95 transition-all cursor-pointer shrink-0"
          >
            <Scan className="w-6 h-6 text-emerald-950" />
            <span>{language === 'mr' ? '📸 रोग स्कॅन करा' : language === 'hi' ? '📸 रोग स्कैन करें' : '📸 Scan Disease'}</span>
          </button>
        </div>

        {/* Decorative background glow & circles */}
        <div className="absolute -right-8 -bottom-8 w-48 h-48 rounded-full bg-white/10 blur-2xl pointer-events-none" />
      </div>

      {/* 3. VOICE-FIRST ADVISORY: "🎤 आज शेतात काय करायचे?" */}
      <div className="p-5 rounded-3xl bg-white/80 dark:bg-emerald-950/40 backdrop-blur-md border border-emerald-500/20 shadow-lg space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-500 dark:text-amber-400 flex items-center justify-center">
              <Sun className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  {language === 'mr' ? 'आजचे शेतकाम नियोजन' : language === 'hi' ? 'आज का कृषि कार्य' : "Today's Farm Action Plan"}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-600 dark:text-amber-300">
                  {dailyPlan.date}
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-zinc-300">
                {language === 'mr' ? 'हवामान व पिकाच्या अवस्थेनुसार तयार केलेला स्मार्ट सल्ला' : 'Customized according to local weather and crop growth stage'}
              </p>
            </div>
          </div>

          <button
            id="farmer-home-speak-daily-plan-btn"
            onClick={handleSpeakDailyPlan}
            className={`px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer shadow-md ${
              isSpeaking && activeSpeakingId === 'daily-plan'
                ? 'bg-rose-500 text-white animate-pulse'
                : 'bg-emerald-500 hover:bg-emerald-400 text-black'
            }`}
          >
            {isSpeaking && activeSpeakingId === 'daily-plan' ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>{language === 'mr' ? 'थांबवा' : 'Stop'}</span>
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4" />
                <span>{language === 'mr' ? '🔊 आवाज ऐका' : language === 'hi' ? '🔊 आवाज सुनें' : '🔊 Listen Voice'}</span>
              </>
            )}
          </button>
        </div>

        {/* Tasks List */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
          {dailyPlan.tasks.map((task) => {
            const isDone = completedTasks[task.id];
            const title = language === 'mr' ? task.titleMr : language === 'hi' ? task.titleHi : task.titleEn;
            const desc = language === 'mr' ? task.descMr : language === 'hi' ? task.descHi : task.descEn;

            return (
              <div
                key={task.id}
                id={`daily-task-card-${task.id}`}
                onClick={() => handleToggleTask(task.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
                  isDone
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-950 dark:text-emerald-100'
                    : 'bg-slate-50 dark:bg-black/30 border-slate-200 dark:border-emerald-500/20 hover:border-emerald-500/40'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-5 h-5 rounded-lg flex items-center justify-center text-xs font-bold ${
                        isDone ? 'bg-emerald-500 text-black' : 'border border-slate-300 dark:border-zinc-600'
                      }`}
                    >
                      {isDone && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                    <span className="text-xs font-bold text-slate-800 dark:text-white line-clamp-1">{title}</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400 font-mono">
                    {task.timeSlot}
                  </span>
                </div>

                <p className="text-[11px] text-slate-600 dark:text-zinc-300 leading-relaxed">{desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. 4-GRID COMPACT HUB: Weather, Mandi, Crop Health, Soil/Schemes */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Card A: 🌿 Treatment Weather & Spray Advisory (Connected to GPS) */}
        <div className="p-5 rounded-3xl bg-white/80 dark:bg-emerald-950/40 backdrop-blur-md border border-emerald-500/20 shadow-lg space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-xs">
                  <Sparkles className="w-5 h-5 text-amber-300" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="text-sm font-black text-slate-900 dark:text-white">
                      {language === 'mr' ? '🌿 फवारणी व उपचार हवामान' : language === 'hi' ? '🌿 छिड़काव व उपचार मौसम' : '🌿 Treatment & Spray Weather'}
                    </h4>
                    <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-emerald-500/20 text-emerald-700 dark:text-emerald-300">
                      GPS Live
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-zinc-400">{farmer.location} • आजचा सल्ला</p>
                </div>
              </div>

              <button
                id="farmer-home-open-weather-modal-btn"
                onClick={() => openModal('weatherAdvisory')}
                className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 hover:underline cursor-pointer"
              >
                <span>{language === 'mr' ? 'संपूर्ण सल्ला' : 'Full Radar'}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Spray Window & Suitability Badge */}
            <div className="mt-3 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
                <div>
                  <div className="text-[10px] font-bold uppercase text-emerald-800 dark:text-emerald-300">
                    {language === 'mr' ? 'फवारणी अनुकूलता (Spray Window)' : 'Spray Suitability'}
                  </div>
                  <div className="text-xs font-black text-emerald-950 dark:text-white">
                    {language === 'mr' ? 'उत्तम वेळ: सकाळी ६:३० - ९:३०' : 'Optimal: 6:30 AM - 9:30 AM'}
                  </div>
                </div>
              </div>

              <button
                onClick={() => openModal('gpsTracker')}
                className="px-2.5 py-1 rounded-xl bg-white dark:bg-emerald-900/50 border border-emerald-500/30 text-[11px] font-bold text-emerald-800 dark:text-emerald-200 hover:bg-emerald-100 flex items-center gap-1 cursor-pointer shrink-0"
              >
                <MapPin className="w-3 h-3 text-emerald-500" />
                <span>Map</span>
              </button>
            </div>

            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-emerald-500/20">
                <div className="text-[10px] text-slate-500 dark:text-zinc-400 font-bold">{language === 'mr' ? 'तापमान' : 'Temp'}</div>
                <div className="text-lg font-black text-slate-900 dark:text-white">२८°C</div>
                <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">बाष्पीभवन कमी</div>
              </div>
              <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-emerald-500/20">
                <div className="text-[10px] text-slate-500 dark:text-zinc-400 font-bold">{language === 'mr' ? 'पाऊस' : 'Rain'}</div>
                <div className="text-lg font-black text-sky-600 dark:text-sky-400">१०%</div>
                <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">धोका नाही</div>
              </div>
              <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-emerald-500/20">
                <div className="text-[10px] text-slate-500 dark:text-zinc-400 font-bold">{language === 'mr' ? 'वारा' : 'Wind'}</div>
                <div className="text-lg font-black text-slate-900 dark:text-white">९ km/h</div>
                <div className="text-[10px] text-emerald-500 font-medium">ड्रिफ्ट सुरक्षित</div>
              </div>
            </div>

            <div className="mt-3 p-3 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-xs text-teal-900 dark:text-teal-200 flex items-start justify-between gap-2">
              <div className="flex items-start gap-2">
                <Droplets className="w-4 h-4 text-teal-500 shrink-0 mt-0.5" />
                <span>
                  {language === 'mr'
                    ? '🌿 उपचार डोस: करपा नियंत्रणासाठी स्कोर (Difenoconazole) १५ मिली / १५L पंप फवारा.'
                    : '🌿 Treatment: Apply Score (Difenoconazole) @ 15ml / 15L pump for fungal protection.'}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => openModal('weatherAdvisory')}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-md"
          >
            <span>🌿 {language === 'mr' ? 'अचूक उपचार व फवारणी कॅल्क्युलेटर' : 'Open Spray & Treatment Advisory'}</span>
          </button>
        </div>

        {/* Card B: 💰 Mandi Market Live Prices */}
        <div className="p-5 rounded-3xl bg-white/80 dark:bg-emerald-950/40 backdrop-blur-md border border-emerald-500/20 shadow-lg space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">
                    {language === 'mr' ? 'बाजारभाव (Mandi Live)' : language === 'hi' ? 'मंडी लाइव भाव' : 'Live Mandi Prices'}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-zinc-400">जवळचे APMC मार्केट • आजचे दर</p>
                </div>
              </div>

              <button
                id="farmer-home-open-mandi-modal-btn"
                onClick={() => openModal('mandiPrices')}
                className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 hover:underline cursor-pointer"
              >
                <span>{language === 'mr' ? 'सर्व भाव' : 'All Mandis'}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Price Ticker Rows */}
            <div className="mt-3 space-y-2">
              {[
                { crop: 'कापूस (Cotton)', apmc: 'नागपूर APMC', rate: '₹७,६५०', trend: '+२.३%' },
                { crop: 'सोयाबीन (Soybean)', apmc: 'लातूर APMC', rate: '₹४,८५०', trend: '+१.५%' },
                { crop: 'गहू (Wheat)', apmc: 'अकोला APMC', rate: '₹२,६५०', trend: '+०.८%' },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-2xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-emerald-500/20 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-bold text-slate-800 dark:text-white">{item.crop}</div>
                    <div className="text-[10px] text-slate-500 dark:text-zinc-400">{item.apmc}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-black text-slate-900 dark:text-white">{item.rate}/क्विंटल</div>
                    <div className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">{item.trend} ↗</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-2 text-center">
            <button
              id="farmer-home-best-mandi-btn"
              onClick={() => openModal('mandiPrices')}
              className="w-full py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-xs font-bold transition-colors cursor-pointer"
            >
              {language === 'mr' ? 'कमाल भाव देणारी बाजारपेठ शोधा' : 'Find Best Paying APMC Market'}
            </button>
          </div>
        </div>

        {/* Card C: 🚚 Smart Supply Chain & Logistics Portal */}
        <div className="p-5 rounded-3xl bg-gradient-to-br from-amber-500/10 via-emerald-500/10 to-teal-500/10 dark:from-amber-950/40 dark:via-emerald-950/40 dark:to-teal-950/40 backdrop-blur-md border border-amber-500/30 shadow-lg space-y-4 flex flex-col justify-between col-span-1 md:col-span-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-emerald-500 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-500/30">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-base font-black text-slate-900 dark:text-white font-outfit">
                    {language === 'mr'
                      ? '🚚 बळीराजा स्मार्ट सप्लाय चेन (Farmer Supply Chain)'
                      : language === 'hi'
                      ? '🚚 किसान सप्लाई चेन (Smart Supply Chain)'
                      : '🚚 KisanAI Smart Supply Chain Portal'}
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-950">NEW</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-emerald-200/80">
                  {language === 'mr'
                    ? 'शेतातून मार्केटपर्यंत पिक प्रवास, साठवणूक, वाहतूक व सर्वाधिक नफा देणारा बाजार'
                    : 'Farm-to-Market Timeline, Cold Storage, Freight Booking & AI Selling Advice'}
                </p>
              </div>
            </div>

            <button
              onClick={() => openModal('supplyChain')}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-emerald-500 hover:from-amber-400 hover:to-emerald-400 text-slate-950 font-black text-xs sm:text-sm shadow-xl shadow-amber-500/20 hover:scale-102 active:scale-98 transition-all cursor-pointer shrink-0"
            >
              <span>{language === 'mr' ? 'सप्लाय चेन उघडा ➔' : language === 'hi' ? 'सप्लाई चेन खोलें ➔' : 'Open Supply Chain Portal ➔'}</span>
            </button>
          </div>
        </div>

        {/* Card C: 🌾 My Crop Status & Lifecycle Stage */}
        <div className="p-5 rounded-3xl bg-white/80 dark:bg-emerald-950/40 backdrop-blur-md border border-emerald-500/20 shadow-lg space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-teal-500/20 text-teal-600 dark:text-teal-300 flex items-center justify-center">
                  <Sprout className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">
                    {language === 'mr' ? 'माझे पीक स्थिती' : language === 'hi' ? 'मेरी फसल स्थिति' : 'My Active Crop'}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-zinc-400">{primaryCrop.name} • {primaryCrop.acres} {t('acres')}</p>
                </div>
              </div>

              <button
                id="farmer-home-open-lifecycle-btn"
                onClick={() => openModal('cropLifecycle')}
                className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 hover:underline cursor-pointer"
              >
                <span>{language === 'mr' ? 'वाढ टप्पे' : 'Lifecycle'}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-3 p-3 rounded-2xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-emerald-500/20 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 dark:text-zinc-400">{language === 'mr' ? 'सध्याचा टप्पा' : 'Current Stage'}:</span>
                <span className="font-black text-slate-900 dark:text-emerald-300">{primaryCrop.stage}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 dark:text-zinc-400">{language === 'mr' ? 'आरोग्य' : 'Health'}:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>{primaryCrop.health}</span>
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 dark:text-zinc-400">{language === 'mr' ? 'कापणीस उर्वरित दिवस' : 'Days to Harvest'}:</span>
                <span className="font-bold text-slate-900 dark:text-white">{primaryCrop.daysLeft} दिवस</span>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-200 dark:bg-zinc-800 h-2 rounded-full overflow-hidden mt-1">
                <div className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full w-[70%] rounded-full" />
              </div>
            </div>
          </div>

          <button
            id="farmer-home-yield-pred-btn"
            onClick={() => openModal('yieldPrediction')}
            className="w-full py-2.5 rounded-xl bg-teal-500/10 hover:bg-teal-500/20 text-teal-700 dark:text-teal-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <span>🌾 {language === 'mr' ? 'उत्पादन व नफा अंदाज तपासा' : 'Predict Yield & Profit'}</span>
          </button>
        </div>

        {/* Card D: 🧪 Soil Health & 🏛️ Government Schemes */}
        <div className="p-5 rounded-3xl bg-white/80 dark:bg-emerald-950/40 backdrop-blur-md border border-emerald-500/20 shadow-lg space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-300 flex items-center justify-center">
                  <FlaskConical className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">
                    {language === 'mr' ? 'माती परीक्षण व सरकारी योजना' : 'Soil Health & Schemes'}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-zinc-400">खत मात्रा व सबसिडी</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 mt-3">
              <button
                id="farmer-home-soil-btn"
                onClick={() => openModal('soilHealth')}
                className="p-3 rounded-2xl bg-slate-50 dark:bg-black/30 hover:bg-emerald-500/10 border border-slate-200 dark:border-emerald-500/20 text-left transition-all cursor-pointer group"
              >
                <div className="text-xl mb-1">🧪</div>
                <div className="font-bold text-xs text-slate-900 dark:text-white group-hover:text-emerald-400">
                  {language === 'mr' ? 'खत कॅल्क्युलेटर' : 'Fertilizer Calculator'}
                </div>
                <div className="text-[10px] text-slate-500 dark:text-zinc-400">NPK मात्रा काढा</div>
              </button>

              <button
                id="farmer-home-schemes-btn"
                onClick={() => openModal('schemes')}
                className="p-3 rounded-2xl bg-slate-50 dark:bg-black/30 hover:bg-emerald-500/10 border border-slate-200 dark:border-emerald-500/20 text-left transition-all cursor-pointer group"
              >
                <div className="text-xl mb-1">🏛️</div>
                <div className="font-bold text-xs text-slate-900 dark:text-white group-hover:text-emerald-400">
                  {language === 'mr' ? 'सरकारी योजना' : 'Govt Schemes'}
                </div>
                <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">₹६,००० PM-KISAN</div>
              </button>
            </div>
          </div>

          <button
            id="farmer-home-askai-trigger-btn"
            onClick={() => openModal('askAi')}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 text-black font-black text-xs flex items-center justify-center gap-2 hover:scale-102 active:scale-98 transition-all shadow-lg shadow-emerald-500/30 cursor-pointer"
          >
            <Mic className="w-4 h-4" />
            <span>{language === 'mr' ? '🤖 किसान AI ला थेट बोला' : language === 'hi' ? '🤖 किसान AI से बोलें' : '🤖 Ask Kisan AI Voice'}</span>
          </button>
        </div>
      </div>
    </div>
    </>
  );
};
