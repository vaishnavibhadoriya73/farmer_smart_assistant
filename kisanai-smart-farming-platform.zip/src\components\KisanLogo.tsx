import React from 'react';

interface KisanLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showTagline?: boolean;
  className?: string;
  animate?: boolean;
}

export const KisanLogo: React.FC<KisanLogoProps> = ({
  size = 'md',
  showText = true,
  showTagline = true,
  className = '',
  animate = false,
}) => {
  const sizeClasses = {
    sm: 'w-9 h-9',
    md: 'w-11 h-11',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
  };

  const textSizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
    xl: 'text-4xl',
  };

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Emblem SVG Container with Gold & Emerald Glowing Border */}
      <div
        className={`relative ${sizeClasses[size]} rounded-2xl p-0.5 bg-gradient-to-tr from-amber-400 via-emerald-500 to-teal-600 shadow-md shadow-emerald-600/25 flex items-center justify-center overflow-hidden transition-all duration-300 ${
          animate ? 'hover:scale-105 hover:rotate-1' : ''
        }`}
      >
        <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center p-1 relative overflow-hidden">
          {/* Vector SVG: Farmer's Heavy-Duty Green & Gold Tractor + AI Circuit Wheat */}
          <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
            <defs>
              <linearGradient id="tractorBodyGrad" x1="10" y1="20" x2="90" y2="80" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#34d399" />
                <stop offset="50%" stopColor="#059669" />
                <stop offset="100%" stopColor="#047857" />
              </linearGradient>
              <linearGradient id="goldSunGrad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#fbbf24" />
                <stop offset="100%" stopColor="#f59e0b" />
              </linearGradient>
            </defs>

            {/* Background Sun rays & AI circuit lines */}
            <circle cx="50" cy="50" r="42" stroke="url(#goldSunGrad)" strokeWidth="1.5" strokeDasharray="4 3" opacity="0.3" />
            <path d="M15 50H85M50 15V85" stroke="#10b981" strokeWidth="1" opacity="0.25" />

            {/* Sun Halo */}
            <circle cx="50" cy="30" r="14" fill="url(#goldSunGrad)" opacity="0.2" />

            {/* Farmer's Heavy Duty Tractor Silhouette & Details */}
            {/* Front Bonnet / Engine Hood */}
            <path d="M42 42H70V58H42V42Z" fill="url(#tractorBodyGrad)" rx="2" />
            <path d="M70 46H78V58H70V46Z" fill="#047857" />

            {/* Cabin / Driver Roof */}
            <path d="M26 30H52V42H26V30Z" fill="#10b981" rx="2" />
            <path d="M30 33H48V40H30V33Z" fill="#e0f2fe" opacity="0.85" />

            {/* Exhaust Pipe & Smoke */}
            <path d="M64 32V42" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round" />
            <circle cx="64" cy="28" r="2" fill="#fbbf24" />
            <circle cx="67" cy="23" r="2.5" fill="#fef3c7" opacity="0.8" />

            {/* Large Rear Tractor Tire with Heavy Treads */}
            <circle cx="34" cy="62" r="15" fill="#1e293b" stroke="#f59e0b" strokeWidth="2" />
            <circle cx="34" cy="62" r="7" fill="#fbbf24" />
            <circle cx="34" cy="62" r="3" fill="#0f172a" />
            <path d="M34 47V52M34 72V77M19 62H24M44 62H49" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round" />

            {/* Front Tractor Tire */}
            <circle cx="72" cy="66" r="9" fill="#1e293b" stroke="#34d399" strokeWidth="1.5" />
            <circle cx="72" cy="66" r="4" fill="#34d399" />
            <circle cx="72" cy="66" r="1.5" fill="#0f172a" />

            {/* AI Neural Wheat Stalk Emblem Overlay */}
            <path d="M82 22C76 28 78 40 85 48" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="82" cy="22" r="2.5" fill="#fbbf24" />
            <circle cx="86" cy="28" r="2" fill="#f59e0b" />
            <circle cx="78" cy="32" r="2" fill="#fbbf24" />

            {/* Glowing Ground Line */}
            <path d="M12 76H88" stroke="#10b981" strokeWidth="3" strokeLinecap="round" />
          </svg>
        </div>

        {/* Live Status Pulse Beacon */}
        <span className="absolute -top-0.5 -right-0.5 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500 border border-white"></span>
        </span>
      </div>

      {/* Brand Typography */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className={`${textSizes[size]} font-extrabold tracking-tight text-slate-900 font-outfit leading-none`}>
              Kisan<span className="text-emerald-600">AI</span>
            </span>
            <span className="px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider rounded-full bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
              <span>🚜</span>
              <span>SMART AGRI</span>
            </span>
          </div>
          {showTagline && (
            <span className="text-[10px] font-bold text-emerald-700 tracking-wide mt-0.5">
              Smart Farming. Better Decisions. 🚜
            </span>
          )}
        </div>
      )}
    </div>
  );
};

