import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Landmark,
  ExternalLink,
  CheckCircle,
  FileText,
  X,
  Sparkles,
  Search,
  Volume2,
  VolumeX,
  ArrowRight,
  RotateCcw,
  Calendar,
  Layers,
  ChevronDown,
  ChevronUp,
  Award,
  Check,
  Building2,
  PhoneCall,
  ShieldCheck,
  Filter,
  MapPin,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useGovernmentSchemes } from '../hooks/useGovernmentSchemes';
import { DetailedGovtSchemeRecord } from '../data/schemesDatabase';

export const SchemesModal: React.FC = () => {
  const { activeModal, closeModal, language, speakText, isSpeaking, stopSpeaking, farmer } = useApp();

  const [activeTab, setActiveTab] = useState<'allSchemes' | 'stateExplorer' | 'eligibilityWizard'>('allSchemes');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedState, setSelectedState] = useState<string>(farmer?.state || 'All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedSchemeType, setSelectedSchemeType] = useState<'All' | 'Central' | 'State'>('All');
  const [expandedSchemeId, setExpandedSchemeId] = useState<string | null>('pm-kisan');
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);

  // Hook connection
  const {
    schemes,
    totalCount,
    lastUpdated,
    source,
    isLoading,
    error,
    selectedStateInfo,
    wizardResults,
    updateFilters,
    retryFetch,
    runEligibilityWizard,
    getStatesList
  } = useGovernmentSchemes({
    state: selectedState,
    category: selectedCategory,
    schemeType: selectedSchemeType,
    searchQuery: searchQuery
  });

  // Eligibility Wizard Questions State
  const [wizardStep, setWizardStep] = useState<number>(1);
  const [wizardInputs, setWizardInputs] = useState({
    state: farmer?.state || 'Maharashtra',
    landAcres: farmer?.landArea || farmer?.totalLandAcres || 4.5,
    cropCategory: farmer?.mainCrop || 'Cotton & Soybean',
    farmerType: 'Small/Marginal (< 5 Acres)' as const,
    irrigationType: 'Drip/Sprinkler' as const,
    primaryActivity: 'Crops Cultivation' as const
  });

  if (activeModal !== 'schemes') return null;

  const statesList = getStatesList();

  const handleStateChange = (stateName: string) => {
    setSelectedState(stateName);
    updateFilters({ state: stateName });
  };

  const handleCategoryChange = (catName: string) => {
    setSelectedCategory(catName);
    updateFilters({ category: catName });
  };

  const handleSchemeTypeChange = (type: 'All' | 'Central' | 'State') => {
    setSelectedSchemeType(type);
    updateFilters({ schemeType: type });
  };

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
    updateFilters({ searchQuery: query });
  };

  const handleRunWizard = () => {
    runEligibilityWizard(wizardInputs);
    setWizardStep(6); // Step 6 shows results
  };

  const handleAudioExplain = (scheme: DetailedGovtSchemeRecord) => {
    if (playingAudioId === scheme.id && isSpeaking) {
      stopSpeaking();
      setPlayingAudioId(null);
      return;
    }

    const textToSpeak = 
      language === 'mr'
        ? `योजनेचे नाव: ${scheme.schemeNameMr}. लाभ: ${scheme.benefitsMr.join('. ')}. लागणारे कागदपत्रे: ${scheme.requiredDocuments.join(', ')}.`
        : language === 'hi'
        ? `योजना का नाम: ${scheme.schemeNameHi}। लाभ: ${scheme.benefitsHi.join('. ')}। आवश्यक दस्तावेज: ${scheme.requiredDocuments.join(', ')}।`
        : `Scheme Name: ${scheme.schemeNameEn}. Benefits: ${scheme.benefitsEn.join('. ')}. Required documents: ${scheme.requiredDocuments.join(', ')}.`;

    setPlayingAudioId(scheme.id);
    speakText(textToSpeak);
  };

  const categoriesList = [
    'All',
    'Farmer Income Support',
    'Crop Insurance',
    'Agriculture Subsidy',
    'Irrigation',
    'Seeds',
    'Fertilizers',
    'Organic Farming',
    'Soil Health',
    'Farm Machinery',
    'Women Farmers',
    'Fisheries',
    'Dairy & Livestock',
    'Horticulture',
    'Storage',
    'Agricultural Infrastructure',
    'Market Access',
    'Farmer Loans/Credit',
    'Skill Development',
    'Digital Agriculture'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-2 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-gradient-to-b from-slate-900 via-emerald-950 to-slate-900 border border-emerald-500/30 rounded-2xl w-full max-w-6xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-100"
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-emerald-500/20 bg-emerald-950/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-500/20 border border-emerald-400/40 rounded-xl text-emerald-400">
              <Landmark className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-bold text-white tracking-wide">
                  {language === 'mr' ? 'सरकारी योजना दालन' : language === 'hi' ? 'सरकारी योजनाएँ पोर्टल' : 'Government Schemes Hub'}
                </h2>
                <span className="px-2 py-0.5 text-xs font-semibold bg-amber-500/20 border border-amber-400/40 text-amber-300 rounded-full">
                  All India & State Wise
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {language === 'mr' ? 'अधिकृत सरकारी संकेतस्थळे व डीबीटी योजना' : language === 'hi' ? 'प्रमाणित सरकारी योजनाएँ एवं डीबीटी पोर्टल' : 'Authentic Central & State Schemes with Official Source Links'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => closeModal()}
              className="p-2 text-slate-400 hover:text-white bg-slate-800/60 hover:bg-slate-800 rounded-xl transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center justify-between px-4 sm:px-6 py-2 bg-slate-900/80 border-b border-emerald-500/20 gap-2">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveTab('allSchemes')}
              className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-xl transition flex items-center space-x-2 ${
                activeTab === 'allSchemes'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>{language === 'mr' ? 'सर्व योजना पहा' : language === 'hi' ? 'सभी योजनाएँ देखें' : 'Browse All Schemes'} ({totalCount})</span>
            </button>

            <button
              onClick={() => setActiveTab('stateExplorer')}
              className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-xl transition flex items-center space-x-2 ${
                activeTab === 'stateExplorer'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <MapPin className="w-4 h-4" />
              <span>{language === 'mr' ? 'राज्यवार माहिती' : language === 'hi' ? 'राज्य-वार एक्सप्लोरर' : 'India State Explorer'}</span>
            </button>

            <button
              onClick={() => setActiveTab('eligibilityWizard')}
              className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-xl transition flex items-center space-x-2 ${
                activeTab === 'eligibilityWizard'
                  ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/30'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-400/30 hover:bg-amber-500/30'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{language === 'mr' ? 'माझ्यासाठी योजना शोधा' : language === 'hi' ? 'मेरे लिए योजनाएँ खोजें' : 'Find Schemes For Me'}</span>
            </button>
          </div>

          <div className="text-xs text-emerald-400/80 flex items-center space-x-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Updated: {lastUpdated || '2026-09-05'}</span>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          
          {/* TAB 1: ALL SCHEMES BROWSER */}
          {activeTab === 'allSchemes' && (
            <div className="space-y-6">
              
              {/* Premium Landing Hero Banner */}
              <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-900/80 via-teal-900/60 to-slate-900 border border-emerald-500/30 p-6 sm:p-8 shadow-xl">
                <div className="relative z-10 max-w-3xl space-y-3">
                  <div className="inline-flex items-center space-x-2 px-3 py-1 bg-emerald-500/20 border border-emerald-400/40 rounded-full text-xs font-semibold text-emerald-300">
                    <Award className="w-3.5 h-3.5" />
                    <span>Government Schemes for Every Farmer</span>
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight">
                    {language === 'mr'
                      ? 'भारतातील सर्व केंद्रीय व राज्यस्तरीय शेतकरी योजना एकाच ठिकाणी'
                      : language === 'hi'
                      ? 'भारत की सभी केंद्रीय एवं राज्यस्तरीय किसान योजनाएँ एक ही स्थान पर'
                      : 'Discover Central and State Government Schemes, Subsidies, Insurance & Agricultural Support'}
                  </h1>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {language === 'mr'
                      ? 'पीएम-किसान, पीक विमा, नमो शेतकरी, महाडीबीटी, ड्रिप सिंचन व बँक कर्जाची संपूर्ण माहिती अधिकृत लिंकसह मिळवा.'
                      : language === 'hi'
                      ? 'पीएम-किसान, फसल बीमा, नमो शेतकारी, डीबीटी पोर्टल, सिंचाई सब्सिडी और बैंक ऋण की प्रामाणिक जानकारी पाएं।'
                      : 'Access authentic scheme details, eligibility guidelines, benefits breakdown, required documents, and official application portals.'}
                  </p>

                  <div className="flex flex-wrap gap-3 pt-2">
                    <button
                      onClick={() => setActiveTab('eligibilityWizard')}
                      className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow-lg transition flex items-center space-x-2 text-sm"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>{language === 'mr' ? 'पात्रता तपासा' : language === 'hi' ? 'पात्रता जांचें' : 'Find Schemes For Me'}</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('stateExplorer')}
                      className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-medium rounded-xl border border-slate-700 transition flex items-center space-x-2 text-sm"
                    >
                      <MapPin className="w-4 h-4 text-emerald-400" />
                      <span>{language === 'mr' ? 'राज्य निवडा' : language === 'hi' ? 'राज्य चुनें' : 'Select Your State'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Search & Filter Control Bar */}
              <div className="bg-slate-900/90 border border-emerald-500/20 rounded-2xl p-4 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  
                  {/* Search Bar */}
                  <div className="relative md:col-span-2">
                    <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder={language === 'mr' ? 'योजनेचे नाव किंवा शब्द शोधा...' : language === 'hi' ? 'योजना का नाम या शब्द खोजें...' : 'Search scheme name, department, crop...'}
                      value={searchQuery}
                      onChange={(e) => handleSearchChange(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  {/* State Dropdown */}
                  <div>
                    <select
                      value={selectedState}
                      onChange={(e) => handleStateChange(e.target.value)}
                      className="w-full py-2.5 px-3 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500"
                    >
                      <option value="All">🇮🇳 {language === 'mr' ? 'सर्व राज्ये (All India)' : language === 'hi' ? 'सभी राज्य (All India)' : 'All India & States'}</option>
                      {statesList.map(s => (
                        <option key={s.code} value={s.name}>{s.name} ({s.type === 'State' ? 'State' : 'UT'})</option>
                      ))}
                    </select>
                  </div>

                  {/* Scheme Type Selector */}
                  <div className="flex bg-slate-950 border border-slate-700 rounded-xl p-1">
                    <button
                      onClick={() => handleSchemeTypeChange('All')}
                      className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${selectedSchemeType === 'All' ? 'bg-emerald-600 text-white' : 'text-slate-400'}`}
                    >
                      All
                    </button>
                    <button
                      onClick={() => handleSchemeTypeChange('Central')}
                      className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${selectedSchemeType === 'Central' ? 'bg-emerald-600 text-white' : 'text-slate-400'}`}
                    >
                      Central
                    </button>
                    <button
                      onClick={() => handleSchemeTypeChange('State')}
                      className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${selectedSchemeType === 'State' ? 'bg-emerald-600 text-white' : 'text-slate-400'}`}
                    >
                      State
                    </button>
                  </div>

                </div>

                {/* 19 Category Pills Carousel */}
                <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
                  <span className="text-xs text-slate-400 font-semibold flex items-center space-x-1 shrink-0">
                    <Filter className="w-3.5 h-3.5" />
                    <span>Category:</span>
                  </span>
                  {categoriesList.map(cat => (
                    <button
                      key={cat}
                      onClick={() => handleCategoryChange(cat)}
                      className={`px-3 py-1.5 text-xs rounded-xl font-medium whitespace-nowrap transition border ${
                        selectedCategory === cat
                          ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-bold shadow-md shadow-emerald-500/20'
                          : 'bg-slate-950/80 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Source & Last Updated Attribution Banner */}
              <div className="flex items-center justify-between text-xs text-slate-400 px-2">
                <div>
                  Showing <span className="font-bold text-emerald-400">{schemes.length}</span> verified schemes
                  {selectedState !== 'All' && <span> for <span className="text-white font-semibold">{selectedState}</span></span>}
                </div>
                <div className="flex items-center space-x-2">
                  <span className="truncate max-w-xs">Source: {source}</span>
                  <button onClick={retryFetch} className="p-1 text-slate-400 hover:text-white" title="Refresh schemes">
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Loading State */}
              {isLoading && (
                <div className="py-12 text-center space-y-3">
                  <div className="inline-block animate-spin text-emerald-400">
                    <RefreshCw className="w-8 h-8" />
                  </div>
                  <p className="text-sm text-slate-300">Loading verified government schemes...</p>
                </div>
              )}

              {/* Error State */}
              {error && (
                <div className="p-4 bg-rose-500/20 border border-rose-500/40 rounded-xl text-rose-300 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-5 h-5 shrink-0" />
                    <span className="text-sm">{error}</span>
                  </div>
                  <button onClick={retryFetch} className="px-3 py-1 bg-rose-600 text-white rounded-lg text-xs font-semibold">
                    Retry
                  </button>
                </div>
              )}

              {/* Empty Results */}
              {!isLoading && !error && schemes.length === 0 && (
                <div className="py-12 text-center bg-slate-900/60 rounded-2xl border border-slate-800 p-6 space-y-3">
                  <Building2 className="w-12 h-12 text-slate-600 mx-auto" />
                  <h3 className="text-lg font-bold text-white">No Schemes Found</h3>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    No government schemes matched your selected filters ({selectedState}, {selectedCategory}). Try clearing filters or searching another keyword.
                  </p>
                  <button
                    onClick={() => {
                      setSelectedState('All');
                      setSelectedCategory('All');
                      setSelectedSchemeType('All');
                      setSearchQuery('');
                      updateFilters({ state: 'All', category: 'All', schemeType: 'All', searchQuery: '' });
                    }}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl"
                  >
                    Reset All Filters
                  </button>
                </div>
              )}

              {/* Scheme Cards Grid */}
              <div className="space-y-4">
                {schemes.map(scheme => {
                  const isExpanded = expandedSchemeId === scheme.id;
                  const isAudioPlaying = playingAudioId === scheme.id && isSpeaking;

                  return (
                    <div
                      key={scheme.id}
                      className="bg-slate-900/90 border border-emerald-500/30 hover:border-emerald-500/60 rounded-2xl p-5 shadow-xl transition space-y-4"
                    >
                      {/* Top Header Card */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className={`px-2.5 py-0.5 text-xs font-bold rounded-full ${
                              scheme.schemeType === 'Central' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            }`}>
                              {scheme.schemeType === 'Central' ? '🇮🇳 Central Scheme' : `🏛️ ${scheme.state} State Scheme`}
                            </span>

                            <span className="px-2.5 py-0.5 text-xs font-medium bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 rounded-full">
                              {scheme.category}
                            </span>

                            <span className="px-2 py-0.5 text-xs font-medium bg-slate-800 text-slate-300 rounded-full">
                              {scheme.benefitType}
                            </span>
                          </div>

                          <h3 className="text-lg font-bold text-white pt-1">
                            {language === 'mr' ? scheme.schemeNameMr : language === 'hi' ? scheme.schemeNameHi : scheme.schemeNameEn}
                          </h3>

                          <p className="text-xs text-slate-400 flex items-center space-x-1">
                            <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                            <span>{language === 'mr' ? scheme.departmentMr : language === 'hi' ? scheme.departmentHi : scheme.departmentEn}</span>
                          </p>
                        </div>

                        <div className="flex items-center space-x-2 shrink-0">
                          {/* Audio Voice Narration */}
                          <button
                            onClick={() => handleAudioExplain(scheme)}
                            className={`p-2 rounded-xl border transition flex items-center space-x-1 text-xs ${
                              isAudioPlaying
                                ? 'bg-amber-500 text-slate-950 border-amber-400 animate-pulse font-bold'
                                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                            }`}
                          >
                            {isAudioPlaying ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
                            <span>{isAudioPlaying ? 'Stop' : 'Voice'}</span>
                          </button>

                          {/* Expand Details Toggle */}
                          <button
                            onClick={() => setExpandedSchemeId(isExpanded ? null : scheme.id)}
                            className="px-3 py-2 bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-semibold transition flex items-center space-x-1"
                          >
                            <span>{isExpanded ? 'Less' : 'View Details'}</span>
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      {/* Short Description */}
                      <p className="text-sm text-slate-300 leading-relaxed">
                        {language === 'mr' ? scheme.shortDescMr : language === 'hi' ? scheme.shortDescHi : scheme.shortDescEn}
                      </p>

                      {/* Expanded Full Details */}
                      {isExpanded && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="space-y-4 pt-2 border-t border-slate-800/80"
                        >
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            
                            {/* Eligibility Box */}
                            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
                              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center space-x-1">
                                <CheckCircle className="w-4 h-4" />
                                <span>{language === 'mr' ? 'पात्रता निकष (Eligibility)' : language === 'hi' ? 'पात्रता मानदंड (Eligibility)' : 'Eligibility Criteria'}</span>
                              </h4>
                              <ul className="space-y-1.5 text-xs text-slate-300">
                                {(language === 'mr' ? scheme.eligibilityMr : language === 'hi' ? scheme.eligibilityHi : scheme.eligibilityEn).map((e, idx) => (
                                  <li key={idx} className="flex items-start space-x-2">
                                    <span className="text-emerald-400 font-bold">•</span>
                                    <span>{e}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {/* Benefits Box */}
                            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
                              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center space-x-1">
                                <Award className="w-4 h-4" />
                                <span>{language === 'mr' ? 'मिळणारे फायदे (Benefits)' : language === 'hi' ? 'प्राप्त लाभ (Benefits)' : 'Scheme Benefits'}</span>
                              </h4>
                              <ul className="space-y-1.5 text-xs text-slate-300">
                                {(language === 'mr' ? scheme.benefitsMr : language === 'hi' ? scheme.benefitsHi : scheme.benefitsEn).map((b, idx) => (
                                  <li key={idx} className="flex items-start space-x-2">
                                    <span className="text-amber-400 font-bold">•</span>
                                    <span>{b}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            
                            {/* Application Process Box */}
                            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
                              <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wider flex items-center space-x-1">
                                <FileText className="w-4 h-4" />
                                <span>{language === 'mr' ? 'अर्ज प्रक्रिया (Application Process)' : language === 'hi' ? 'आवेदन प्रक्रिया (Application Process)' : 'How to Apply'}</span>
                              </h4>
                              <ol className="space-y-2 text-xs text-slate-300">
                                {(language === 'mr' ? scheme.applicationProcessMr : language === 'hi' ? scheme.applicationProcessHi : scheme.applicationProcessEn).map((step, idx) => (
                                  <li key={idx} className="flex items-start space-x-2">
                                    <span className="w-4 h-4 bg-blue-500/20 text-blue-300 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0">
                                      {idx + 1}
                                    </span>
                                    <span>{step}</span>
                                  </li>
                                ))}
                              </ol>
                            </div>

                            {/* Documents Required Box */}
                            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
                              <h4 className="text-xs font-bold text-purple-400 uppercase tracking-wider flex items-center space-x-1">
                                <Layers className="w-4 h-4" />
                                <span>{language === 'mr' ? 'आवश्यक कागदपत्रे (Required Documents)' : language === 'hi' ? 'आवश्यक दस्तावेज (Required Documents)' : 'Required Documents'}</span>
                              </h4>
                              <div className="grid grid-cols-1 gap-1.5 text-xs text-slate-300">
                                {scheme.requiredDocuments.map((doc, idx) => (
                                  <div key={idx} className="flex items-center space-x-2 bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-800">
                                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                                    <span>{doc}</span>
                                  </div>
                                ))}
                              </div>
                            </div>

                          </div>
                        </motion.div>
                      )}

                      {/* Footer Link & Attribution Bar */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-800/80 text-xs">
                        <div className="text-slate-400 flex items-center space-x-3">
                          <span>Updated: <strong className="text-slate-200">{scheme.lastUpdated}</strong></span>
                          <span>•</span>
                          <span className="truncate max-w-xs">{scheme.sourceAttribution}</span>
                        </div>

                        {/* AUTHENTIC OFFICIAL SOURCE BUTTON */}
                        <a
                          href={scheme.officialWebsiteUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-xl shadow-lg transition flex items-center justify-center space-x-2 shrink-0"
                        >
                          <span>{language === 'mr' ? 'अधिकृत पोर्टलवर अर्ज करा' : language === 'hi' ? 'आधिकारिक पोर्टल देखें' : 'View Official Source'}</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>

                    </div>
                  );
                })}
              </div>

            </div>
          )}

          {/* TAB 2: INDIA STATE EXPLORER */}
          {activeTab === 'stateExplorer' && (
            <div className="space-y-6">
              
              <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-lg font-bold text-white">Interactive India State Explorer</h3>
                    <p className="text-xs text-slate-400">Select any State or Union Territory to view dedicated agriculture portals, department links, major crops, and state subsidies.</p>
                  </div>

                  <select
                    value={selectedState === 'All' ? 'Maharashtra' : selectedState}
                    onChange={(e) => handleStateChange(e.target.value)}
                    className="py-2.5 px-4 bg-slate-950 border border-emerald-500/50 rounded-xl text-sm font-bold text-emerald-300 focus:outline-none"
                  >
                    {statesList.map(s => (
                      <option key={s.code} value={s.name}>{s.name} ({s.type})</option>
                    ))}
                  </select>
                </div>

                {selectedStateInfo ? (
                  <div className="space-y-6 pt-2">
                    
                    {/* State Header Card */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-5">
                      <div className="space-y-1">
                        <span className="text-xs text-slate-400">State / UT Name</span>
                        <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                          <MapPin className="w-5 h-5 text-emerald-400" />
                          <span>{selectedStateInfo.name} ({selectedStateInfo.nameHi})</span>
                        </h2>
                        <p className="text-xs text-slate-300">Capital: <strong>{selectedStateInfo.capital}</strong> | Type: {selectedStateInfo.type}</p>
                      </div>

                      <div className="space-y-1">
                        <span className="text-xs text-slate-400">Agriculture Department</span>
                        <p className="text-xs font-semibold text-emerald-300">{selectedStateInfo.agriDepartmentName}</p>
                        <p className="text-xs text-slate-300 flex items-center space-x-1 pt-1">
                          <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                          <span>Helpline: <strong>{selectedStateInfo.helplineNumber}</strong></span>
                        </p>
                      </div>

                      <div className="space-y-1 sm:text-right">
                        <span className="text-xs text-slate-400">Farmer Statistics</span>
                        <p className="text-sm font-bold text-white">{selectedStateInfo.totalFarmersCount} Farmers</p>
                        <p className="text-xs text-slate-300">Arable Land: {selectedStateInfo.totalArableLandLakhHa} Lakh Hectares</p>
                        <div className="pt-2">
                          <a
                            href={selectedStateInfo.officialPortalUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center space-x-1 text-xs font-bold text-emerald-400 hover:underline"
                          >
                            <span>Open State Portal</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      </div>
                    </div>

                    {/* State Crops & Active Subsidies */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
                        <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Major State Crops</h4>
                        <div className="flex flex-wrap gap-1.5">
                          {selectedStateInfo.majorCrops.map(crop => (
                            <span key={crop} className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 text-xs font-medium rounded-lg border border-emerald-500/30">
                              🌱 {crop}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
                        <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">Key Active State Subsidies</h4>
                        <div className="flex flex-wrap gap-1.5">
                          {selectedStateInfo.activeSubsidies.map(sub => (
                            <span key={sub} className="px-2.5 py-1 bg-amber-500/20 text-amber-300 text-xs font-medium rounded-lg border border-amber-500/30">
                              💰 {sub}
                            </span>
                          ))}
                        </div>
                      </div>

                    </div>

                  </div>
                ) : (
                  <p className="text-xs text-slate-400">Select a state above to view details.</p>
                )}
              </div>

            </div>
          )}

          {/* TAB 3: SCHEME ELIGIBILITY WIZARD */}
          {activeTab === 'eligibilityWizard' && (
            <div className="space-y-6">
              
              <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-6 space-y-6">
                
                <div className="space-y-1">
                  <div className="inline-flex items-center space-x-2 px-3 py-1 bg-amber-500/20 text-amber-300 rounded-full text-xs font-semibold border border-amber-400/40">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Scheme Eligibility Assistant</span>
                  </div>
                  <h2 className="text-xl font-bold text-white">Find Schemes Tailored For Me (योजना सहाय्यक)</h2>
                  <p className="text-xs text-slate-400">Answer 5 simple questions about your farm to find the highest-matching government schemes and subsidies.</p>
                </div>

                {/* Step Progress Bar */}
                <div className="grid grid-cols-5 gap-2">
                  {[1, 2, 3, 4, 5].map((step) => (
                    <div
                      key={step}
                      className={`h-2 rounded-full transition ${
                        wizardStep >= step ? 'bg-amber-500' : 'bg-slate-800'
                      }`}
                    />
                  ))}
                </div>

                {/* Step Questions */}
                {wizardStep === 1 && (
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-white">1. Select Your State (तुमचे राज्य निवडा)</h3>
                    <select
                      value={wizardInputs.state}
                      onChange={(e) => setWizardInputs({ ...wizardInputs, state: e.target.value })}
                      className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-amber-500"
                    >
                      {statesList.map(s => (
                        <option key={s.code} value={s.name}>{s.name}</option>
                      ))}
                    </select>
                    <button
                      onClick={() => setWizardStep(2)}
                      className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm rounded-xl transition"
                    >
                      Next Step →
                    </button>
                  </div>
                )}

                {wizardStep === 2 && (
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-white">2. Land Size in Acres (जमिनीचे क्षेत्रफळ)</h3>
                    <input
                      type="number"
                      value={wizardInputs.landAcres}
                      onChange={(e) => setWizardInputs({ ...wizardInputs, landAcres: Number(e.target.value) || 1 })}
                      className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white"
                      placeholder="e.g. 4.5"
                    />
                    <div className="flex space-x-3">
                      <button onClick={() => setWizardStep(1)} className="px-4 py-2 bg-slate-800 text-white rounded-xl text-sm">Back</button>
                      <button onClick={() => setWizardStep(3)} className="px-6 py-2 bg-amber-500 text-slate-950 font-bold text-sm rounded-xl">Next Step →</button>
                    </div>
                  </div>
                )}

                {wizardStep === 3 && (
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-white">3. Primary Farming Activity (मुख्य शेती व्यवसाय)</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {['Crops Cultivation', 'Horticulture', 'Dairy/Livestock', 'Fisheries', 'Organic Farming', 'Infrastructure/Machinery'].map((act) => (
                        <button
                          key={act}
                          onClick={() => setWizardInputs({ ...wizardInputs, primaryActivity: act as any })}
                          className={`p-3 text-xs font-semibold rounded-xl border text-left transition ${
                            wizardInputs.primaryActivity === act
                              ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                              : 'bg-slate-950 text-slate-300 border-slate-800'
                          }`}
                        >
                          {act}
                        </button>
                      ))}
                    </div>
                    <div className="flex space-x-3 pt-2">
                      <button onClick={() => setWizardStep(2)} className="px-4 py-2 bg-slate-800 text-white rounded-xl text-sm">Back</button>
                      <button onClick={() => setWizardStep(4)} className="px-6 py-2 bg-amber-500 text-slate-950 font-bold text-sm rounded-xl">Next Step →</button>
                    </div>
                  </div>
                )}

                {wizardStep === 4 && (
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-white">4. Farmer Category (शेतकरी प्रकार)</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        'Small/Marginal (< 5 Acres)',
                        'Medium/Large (> 5 Acres)',
                        'Tenant/Sharecropper',
                        'Woman Farmer',
                        'SC/ST Farmer'
                      ].map((cat) => (
                        <button
                          key={cat}
                          onClick={() => setWizardInputs({ ...wizardInputs, farmerType: cat as any })}
                          className={`p-3 text-xs font-semibold rounded-xl border text-left transition ${
                            wizardInputs.farmerType === cat
                              ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                              : 'bg-slate-950 text-slate-300 border-slate-800'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                    <div className="flex space-x-3 pt-2">
                      <button onClick={() => setWizardStep(3)} className="px-4 py-2 bg-slate-800 text-white rounded-xl text-sm">Back</button>
                      <button onClick={() => setWizardStep(5)} className="px-6 py-2 bg-amber-500 text-slate-950 font-bold text-sm rounded-xl">Next Step →</button>
                    </div>
                  </div>
                )}

                {wizardStep === 5 && (
                  <div className="space-y-4">
                    <h3 className="text-sm font-bold text-white">5. Irrigation Source (सिंचन प्रकार)</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {['Drip/Sprinkler', 'Borewell/Well', 'Canal', 'Rainfed'].map((irr) => (
                        <button
                          key={irr}
                          onClick={() => setWizardInputs({ ...wizardInputs, irrigationType: irr as any })}
                          className={`p-3 text-xs font-semibold rounded-xl border text-left transition ${
                            wizardInputs.irrigationType === irr
                              ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                              : 'bg-slate-950 text-slate-300 border-slate-800'
                          }`}
                        >
                          {irr}
                        </button>
                      ))}
                    </div>
                    <div className="flex space-x-3 pt-4">
                      <button onClick={() => setWizardStep(4)} className="px-4 py-2 bg-slate-800 text-white rounded-xl text-sm">Back</button>
                      <button
                        onClick={handleRunWizard}
                        className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-sm rounded-xl shadow-lg transition flex items-center space-x-2"
                      >
                        <Sparkles className="w-4 h-4" />
                        <span>Calculate Eligible Schemes</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Step 6: Wizard Results */}
                {wizardStep === 6 && (
                  <div className="space-y-4 pt-2">
                    <div className="flex items-center justify-between">
                      <h3 className="text-base font-bold text-amber-300">Recommended Schemes For Your Profile ({wizardResults.length})</h3>
                      <button onClick={() => setWizardStep(1)} className="text-xs text-slate-400 underline">Recalculate</button>
                    </div>

                    <div className="space-y-3">
                      {wizardResults.map(res => (
                        <div key={res.id} className="bg-slate-950 border border-amber-500/30 rounded-xl p-4 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-white">{res.schemeNameEn}</span>
                            <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded-full text-xs font-extrabold border border-amber-400/40">
                              {res.matchPercentage}% Match
                            </span>
                          </div>

                          <p className="text-xs text-slate-300">{res.shortDescEn}</p>

                          <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 space-y-1">
                            <span className="text-[11px] font-semibold text-amber-400">Why this scheme is recommended:</span>
                            <ul className="text-[11px] text-slate-300 space-y-0.5">
                              {res.matchReasonsEn.map((r, idx) => (
                                <li key={idx}>✓ {r}</li>
                              ))}
                            </ul>
                          </div>

                          <div className="pt-1 flex items-center justify-between">
                            <span className="text-[10px] text-slate-400">Disclaimer: Check official eligibility guidelines on official portal.</span>
                            <a
                              href={res.officialWebsiteUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-3 py-1 bg-amber-500 text-slate-950 font-bold text-xs rounded-lg flex items-center space-x-1"
                            >
                              <span>Check Official Eligibility</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>

            </div>
          )}

        </div>
      </motion.div>
    </div>
  );
};
