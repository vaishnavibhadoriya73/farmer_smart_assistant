import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sprout,
  Plus,
  Calendar,
  Droplets,
  Thermometer,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Scan,
  Sparkles,
  Layers,
  ArrowRight,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CropItem } from '../types';

export const MyCropView: React.FC = () => {
  const { crops, addCrop, openModal, selectedCrop, setSelectedCrop } = useApp();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New crop form state
  const [newCropName, setNewCropName] = useState('Cotton (Bt Cotton)');
  const [newVariety, setNewVariety] = useState('RCH-659 BG-II');
  const [newPlotSize, setNewPlotSize] = useState('3.0');
  const [newCategory, setNewCategory] = useState<'Cash Crop' | 'Cereal' | 'Vegetable' | 'Oilseed' | 'Pulse'>('Cash Crop');

  const handleCreateCrop = (e: React.FormEvent) => {
    e.preventDefault();
    addCrop({
      name: newCropName,
      variety: newVariety,
      category: newCategory,
      sowingDate: 'Today',
      harvestDate: 'In 120 Days',
      plotSizeAcres: parseFloat(newPlotSize) || 2.0,
      stage: 'Sowing',
      progressPercentage: 10,
      healthStatus: 'Excellent',
      soilMoisture: 48,
      temperature: 27,
      nextAction: 'Ensure seed treatment with Trichoderma & Rhizobium culture before sowing',
      expectedYieldQuintals: 30,
      estimatedRevenue: 215000,
      image: 'https://images.unsplash.com/photo-1598965675045-45c5e72c7d05?auto=format&fit=crop&w=600&q=80',
    });
    setIsAddModalOpen(false);
  };

  const getStageColor = (stage: string) => {
    switch (stage) {
      case 'Flowering':
      case 'Fruiting':
        return 'text-amber-500 bg-amber-500/10 border-amber-500/30';
      case 'Harvesting':
        return 'text-purple-500 bg-purple-500/10 border-purple-500/30';
      case 'Vegetative':
        return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/30';
      default:
        return 'text-teal-500 bg-teal-500/10 border-teal-500/30';
    }
  };

  return (
    <div id="my-crops-dashboard" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header & Add Crop Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-2 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
              <Sprout className="w-5 h-5" />
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-emerald-950 dark:text-white font-outfit">
              My Active Crop Plots
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400">
            Real-time phenology tracking, satellite moisture telemetry, and automated agro schedules.
          </p>
        </div>

        <button
          id="add-crop-btn"
          onClick={() => setIsAddModalOpen(true)}
          className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Register New Crop Plot</span>
        </button>
      </div>

      {/* Overview Statistics Banner */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-xs">
          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-semibold">Total Cultivated Area</span>
          <div className="text-2xl font-extrabold text-emerald-950 dark:text-white font-outfit mt-1">
            {crops.reduce((sum, c) => sum + c.plotSizeAcres, 0).toFixed(1)} Acres
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-xs">
          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-semibold">Projected Farm Yield</span>
          <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 font-outfit mt-1">
            {crops.reduce((sum, c) => sum + c.expectedYieldQuintals, 0)} Quintals
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-xs">
          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-semibold">Estimated Gross Revenue</span>
          <div className="text-2xl font-extrabold text-amber-600 dark:text-amber-400 font-outfit mt-1">
            ₹{crops.reduce((sum, c) => sum + c.estimatedRevenue, 0).toLocaleString('en-IN')}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-emerald-950/60 border border-emerald-500/20 shadow-xs">
          <span className="text-[11px] text-zinc-500 dark:text-zinc-400 font-semibold">Crop Health Status</span>
          <div className="text-2xl font-extrabold text-emerald-500 font-outfit mt-1 flex items-center gap-1.5">
            <CheckCircle2 className="w-5 h-5" />
            <span>Optimal (94%)</span>
          </div>
        </div>
      </div>

      {/* Crop Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {crops.map((crop, idx) => (
          <motion.div
            key={crop.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: idx * 0.08 }}
            className="p-6 rounded-3xl bg-white/90 dark:bg-emerald-950/70 border border-emerald-500/20 shadow-xl space-y-5 group hover:border-emerald-500/40 transition-all"
          >
            {/* Header: Name, Variety, Stage Badge */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <img
                  src={crop.image}
                  alt={crop.name}
                  referrerPolicy="no-referrer"
                  className="w-14 h-14 rounded-2xl object-cover border border-emerald-500/20 shadow-xs group-hover:scale-105 transition-transform"
                />
                <div>
                  <h3 className="text-lg font-bold text-emerald-950 dark:text-white font-outfit">
                    {crop.name}
                  </h3>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400">
                    Variety: {crop.variety} • {crop.plotSizeAcres} Acres
                  </p>
                </div>
              </div>

              <span
                className={`text-xs font-bold px-3 py-1 rounded-full border ${getStageColor(
                  crop.stage
                )}`}
              >
                {crop.stage}
              </span>
            </div>

            {/* Growth Progress Bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-zinc-600 dark:text-zinc-400">Growth Stage Timeline</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-mono">
                  {crop.progressPercentage}% Complete
                </span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-emerald-100 dark:bg-emerald-900/40 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500"
                  style={{ width: `${crop.progressPercentage}%` }}
                />
              </div>
            </div>

            {/* Telemetry Sensor Gauges: Moisture & Temp */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/15">
                <span className="text-[10px] text-zinc-500 dark:text-zinc-400 block">Soil Moisture</span>
                <span className="text-sm font-extrabold text-emerald-700 dark:text-emerald-300 font-mono">
                  {crop.soilMoisture}%
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/15">
                <span className="text-[10px] text-zinc-500 dark:text-zinc-400 block">Canopy Temp</span>
                <span className="text-sm font-extrabold text-emerald-700 dark:text-emerald-300 font-mono">
                  {crop.temperature}°C
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/15">
                <span className="text-[10px] text-zinc-500 dark:text-zinc-400 block">Est. Revenue</span>
                <span className="text-sm font-extrabold text-amber-600 dark:text-amber-400 font-mono">
                  ₹{(crop.estimatedRevenue / 1000).toFixed(0)}k
                </span>
              </div>
            </div>

            {/* Next AI Recommended Farm Action */}
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-xs space-y-1">
              <span className="font-bold text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
                <span>Next Scheduled Agro Action:</span>
              </span>
              <p className="text-zinc-700 dark:text-zinc-300 pl-5">{crop.nextAction}</p>
            </div>

            {/* Card Footer Actions */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
              <button
                onClick={() => {
                  setSelectedCrop(crop);
                  openModal('diagnose');
                }}
                className="py-2 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-1 shadow-xs cursor-pointer"
              >
                <Scan className="w-3.5 h-3.5" />
                <span>Scan</span>
              </button>

              <button
                onClick={() => {
                  setSelectedCrop(crop);
                  openModal('cropLifecycle');
                }}
                className="py-2 px-2.5 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-teal-800 dark:text-teal-200 font-semibold text-xs flex items-center justify-center gap-1 cursor-pointer"
              >
                <Sprout className="w-3.5 h-3.5" />
                <span>Lifecycle</span>
              </button>

              <button
                onClick={() => {
                  setSelectedCrop(crop);
                  openModal('yieldPrediction');
                }}
                className="py-2 px-2.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-800 dark:text-sky-200 font-semibold text-xs flex items-center justify-center gap-1 cursor-pointer"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Yield</span>
              </button>

              <button
                onClick={() => {
                  setSelectedCrop(crop);
                  openModal('profitPrediction');
                }}
                className="py-2 px-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-800 dark:text-amber-200 font-semibold text-xs flex items-center justify-center gap-1 cursor-pointer"
              >
                <span>₹ Profit</span>
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Add Crop Plot Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-emerald-950/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-lg rounded-3xl bg-white dark:bg-[#072418] border border-emerald-500/30 p-6 shadow-2xl space-y-5"
            >
              <div className="flex items-center justify-between border-b border-emerald-500/20 pb-4">
                <div className="flex items-center gap-2">
                  <Sprout className="w-5 h-5 text-emerald-500" />
                  <h3 className="text-lg font-bold text-emerald-950 dark:text-white font-outfit">
                    Register New Crop Plot
                  </h3>
                </div>
                <button
                  onClick={() => setIsAddModalOpen(false)}
                  className="p-2 rounded-xl bg-emerald-100/50 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleCreateCrop} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1">
                    Crop Name
                  </label>
                  <input
                    type="text"
                    required
                    value={newCropName}
                    onChange={(e) => setNewCropName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-xs text-emerald-950 dark:text-emerald-100 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1">
                      Variety / Hybrid
                    </label>
                    <input
                      type="text"
                      required
                      value={newVariety}
                      onChange={(e) => setNewVariety(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-xs text-emerald-950 dark:text-emerald-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-emerald-950 dark:text-emerald-200 mb-1">
                      Plot Size (Acres)
                    </label>
                    <input
                      type="number"
                      step="0.5"
                      required
                      value={newPlotSize}
                      onChange={(e) => setNewPlotSize(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-900/30 border border-emerald-500/20 text-xs text-emerald-950 dark:text-emerald-100"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md"
                  >
                    Save Plot
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
