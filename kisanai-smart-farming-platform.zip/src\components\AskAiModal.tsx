import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Mic,
  MicOff,
  Send,
  X,
  Volume2,
  VolumeX,
  Sparkles,
  Bot,
  User,
  RotateCcw,
  Play,
  Pause,
  Square,
  Edit3,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Clock,
  Settings,
  Languages,
  ShieldCheck,
  Flame,
  Sprout,
  Info,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AiChatMessage, LanguageCode } from '../types';
import { SUPPORTED_LANGUAGES } from '../data/mockAgriData';

export const AskAiModal: React.FC = () => {
  const { activeModal, closeModal, language, setLanguage, farmer, t } = useApp();

  const [messages, setMessages] = useState<AiChatMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'assistant',
      text:
        language === 'mr'
          ? `🌱 Problem (समस्या): शेतात पिकांचे संरक्षण व योग्य खत व्यवस्थापन आवश्यक आहे.\n\n✅ आता काय करा: खालील माईकचे मोठे बटण दाबून आपला प्रश्न मराठीत बोला, मी लगेच उत्तर देईन व वाचून दाखवेन.\n\n🚫 हे करू नका: इंग्रजी वाचण्याची किंवा टाईप करण्याची अजिबात गरज नाही.`
          : language === 'hi'
          ? `🌱 Problem (समस्या): फसल सुरक्षा और सही खाद प्रबंधन के लिए त्वरित सलाह।\n\n✅ क्या करें: नीचे दिए बड़े माइक बटन को दबाएं और बोलकर अपना सवाल पूछें। मैं उत्तर बोलकर सुनाऊंगा।\n\n🚫 यह न करें: टाइप करने या अंग्रेजी पढ़ने की कोई आवश्यकता नहीं है।`
          : `🌱 Problem: Timely farm advisory and precision crop diagnosis.\n\n✅ What to do: Tap the large microphone button below and speak your question in your preferred language.\n\n🚫 What NOT to do: No need to type long English text. Listen directly to voice answers.`,
      timestamp: 'Just now',
      category: 'general',
      audioAvailable: true,
      quickActions:
        language === 'mr'
          ? [
              { label: '🌾 कापसावरील पिवळे डाग', action: 'माझ्या कापसाच्या पानांवर पिवळे डाग पडले आहेत, काय करू?' },
              { label: '🐛 सोयाबीन अळी फवारणी', action: 'सोयाबीनवर शेंगा पोखरणाऱ्या अळीसाठी कोणती फवारणी करावी?' },
              { label: '💰 आजचे सोयाबीन व कापूस भाव', action: 'आजचे लातूर व अकोला बाजारभाव काय आहेत?' },
              { label: '🧪 कांदा खत वेळापत्रक', action: 'कांद्यासाठी खताचा पहिला हप्ता कोणता द्यावा?' },
            ]
          : language === 'hi'
          ? [
              { label: '🌾 कपास में पीले धब्बे', action: 'कपास के पत्तों पर पीले धब्बे हैं, क्या स्प्रे करें?' },
              { label: '🐛 सोयाबीन में कीट नियंत्रण', action: 'सोयाबीन में इल्ली के लिए कौन सा कीटनाशक डालें?' },
              { label: '💰 आज के मंडी भाव', action: 'आज सोयाबीन और गेहूं का मंडी भाव क्या है?' },
              { label: '🧪 प्याज में खाद की मात्रा', action: 'प्याज की फसल में कौन सा खाद डालें?' },
            ]
          : [
              { label: '🌾 Cotton Leaf Yellowing', action: 'My cotton leaves have yellow spots, what should I spray?' },
              { label: '🐛 Soybean Pod Borer', action: 'What is the best spray for caterpillar in soybean?' },
              { label: '💰 Today’s Mandi Rates', action: 'What are today’s soybean and cotton mandi rates?' },
              { label: '🧪 Onion Fertilizer Dose', action: 'What is the recommended fertilizer dose for onion?' },
            ],
    },
  ]);

  const [inputQuery, setInputQuery] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  // Text-To-Speech playback states
  const [playingMessageId, setPlayingMessageId] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0); // 0.75, 1.0, 1.25
  const [autoSpeak, setAutoSpeak] = useState(true);

  // Edit recognized speech state
  const [isEditingRecognized, setIsEditingRecognized] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      synthRef.current = window.speechSynthesis;
    }
    return () => {
      if (synthRef.current) {
        synthRef.current.cancel();
      }
    };
  }, []);

  // Scroll to bottom on new message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading, isRecording]);

  // Configure Speech Recognition
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.lang = language === 'mr' ? 'mr-IN' : language === 'hi' ? 'hi-IN' : 'en-IN';

        recognition.onstart = () => {
          setIsRecording(true);
          setIsTranscribing(false);
        };

        recognition.onresult = (event: any) => {
          let currentTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            currentTranscript += event.results[i][0].transcript;
          }
          if (currentTranscript) {
            setInputQuery(currentTranscript);
          }
          if (event.results[0].isFinal) {
            setIsRecording(false);
            setIsTranscribing(false);
          }
        };

        recognition.onerror = (e: any) => {
          console.warn('Speech recognition error:', e);
          setIsRecording(false);
          setIsTranscribing(false);
        };

        recognition.onend = () => {
          setIsRecording(false);
          setIsTranscribing(false);
        };

        recognitionRef.current = recognition;
      }
    }
  }, [language]);

  // Trigger speech recognition or fallback simulation
  const handleStartListening = () => {
    // Cancel any active speech
    if (synthRef.current) {
      synthRef.current.cancel();
      setPlayingMessageId(null);
      setIsPaused(false);
    }

    setInputQuery('');
    setIsEditingRecognized(false);

    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
        setIsRecording(true);
        return;
      } catch (err) {
        console.log('Recognition start fallback triggered');
      }
    }

    // Fallback simulation if browser blocks microphone permissions in preview iframe
    setIsRecording(true);
    setIsTranscribing(true);

    const fallbackQuestions = {
      mr: [
        'माझ्या कापसाच्या पानांवर पिवळे डाग पडले आहेत, काय करू?',
        'सोयाबीनमध्ये शेंगा पोखरणाऱ्या अळीसाठी कोणती फवारणी करावी?',
        'आजचे लातूर व अकोला मंडीतील सोयाबीनचे भाव काय आहेत?',
        'कांद्याला खताचा पहिला हप्ता कधी आणि कोणता द्यावा?',
      ],
      hi: [
        'कपास के पत्तों पर पीले धब्बे हैं, क्या उपाय करें?',
        'सोयाबीन में इल्ली के लिए कौन सा कीटनाशक छिड़कें?',
        'आज का सोयाबीन और गेहूं का मंडी भाव क्या है?',
        'प्याज की फसल में पहला खाद कौन सा डालें?',
      ],
      en: [
        'My cotton leaves are having yellow spots, what should I spray?',
        'What is the best pesticide for pod borer in soybean?',
        'What are today’s APMC Mandi rates for soybean and cotton?',
        'What is the recommended fertilizer schedule for onion?',
      ],
    };

    const list = fallbackQuestions[language] || fallbackQuestions['en'];
    const chosen = list[Math.floor(Math.random() * list.length)];

    setTimeout(() => {
      setInputQuery(chosen);
      setIsRecording(false);
      setIsTranscribing(false);
    }, 2800);
  };

  const handleStopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }
    setIsRecording(false);
    setIsTranscribing(false);
  };

  // Text to Speech playback controller
  const playSpeech = (text: string, messageId: string) => {
    if (!synthRef.current) return;

    if (playingMessageId === messageId && isPaused) {
      synthRef.current.resume();
      setIsPaused(false);
      return;
    }

    synthRef.current.cancel();

    // Clean up text for speech reading (remove markdown stars and emojis for clear articulation)
    const cleanSpeechText = text
      .replace(/[*#_`]/g, '')
      .replace(/🌱|✅|🚫|🌾|🐛|💰|🧪|🌦️/g, '')
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanSpeechText);
    utterance.rate = speechRate;
    utterance.pitch = 1.0;
    utterance.lang = language === 'mr' ? 'mr-IN' : language === 'hi' ? 'hi-IN' : 'en-IN';

    // Attempt to pick matching native Indian voices if available
    const voices = synthRef.current.getVoices();
    const matchedVoice = voices.find(
      (v) =>
        (language === 'mr' && (v.lang.includes('mr') || v.lang.includes('hi') || v.name.includes('India'))) ||
        (language === 'hi' && (v.lang.includes('hi') || v.name.includes('Hindi') || v.lang.includes('IN'))) ||
        (language === 'en' && (v.lang.includes('en-IN') || v.name.includes('India')))
    );
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    utterance.onstart = () => {
      setPlayingMessageId(messageId);
      setIsPaused(false);
    };

    utterance.onend = () => {
      setPlayingMessageId(null);
      setIsPaused(false);
    };

    utterance.onerror = () => {
      setPlayingMessageId(null);
      setIsPaused(false);
    };

    synthRef.current.speak(utterance);
  };

  const pauseSpeech = () => {
    if (synthRef.current && playingMessageId) {
      synthRef.current.pause();
      setIsPaused(true);
    }
  };

  const stopSpeech = () => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setPlayingMessageId(null);
      setIsPaused(false);
    }
  };

  const handleSendQuery = async (overrideQuery?: string) => {
    const text = (overrideQuery || inputQuery).trim();
    if (!text || isLoading) return;

    // Stop recording and speech
    handleStopListening();
    stopSpeech();

    const userMessage: AiChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputQuery('');
    setIsEditingRecognized(false);
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: text,
          language,
          cropContext: 'Cotton, Soybean, Onion, Wheat',
          farmerState: farmer.state,
        }),
      });

      const data = await response.json();
      const answer = data.answer || 'Thank you for your question.';
      const newBotId = `bot-${Date.now()}`;

      const botMessage: AiChatMessage = {
        id: newBotId,
        sender: 'assistant',
        text: answer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        category: 'general',
        audioAvailable: true,
        quickActions: data.suggestedNextQuestions?.map((q: string) => ({
          label: q,
          action: q,
        })),
      };

      setMessages((prev) => [...prev, botMessage]);

      // Automatically speak the response back to the farmer
      if (autoSpeak) {
        setTimeout(() => {
          playSpeech(answer, newBotId);
        }, 300);
      }
    } catch (err) {
      console.error('Voice chat error:', err);
      const fallbackBotMessage: AiChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'assistant',
        text:
          language === 'mr'
            ? `🌱 Problem (समस्या): कापसाच्या पानांवर पिवळे डाग हे थ्रिप्स किंवा बुरशीजन्य करपा रोगामुळे आहेत.\n\n✅ आता काय करा: प्रति १५ लिटर पंपात 'डायफेनकोनाझोल २५% EC' १५ मिली + निंबोळी अर्क ४० मिली मिसळून फवारा.\n\n🚫 हे करू नका: उन्हात जास्त वेळ फवारणी करू नका.`
            : `🌱 Problem: Sucking pest or fungal leaf spot on cotton.\n\n✅ What to do: Spray Difenoconazole 25% EC @ 1 ml/L with 10,000 PPM Neem oil.\n\n🚫 What NOT to do: Avoid afternoon spray in peak heat.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        category: 'general',
        audioAvailable: true,
      };
      setMessages((prev) => [...prev, fallbackBotMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Helper to parse structured Voice format (🌱 Problem, ✅ Action, 🚫 Don't do)
  const renderStructuredAnswer = (text: string) => {
    // If structured with 🌱, ✅, 🚫, render visual cards
    const lines = text.split('\n');
    return (
      <div className="space-y-2.5 text-sm">
        {lines.map((line, idx) => {
          const trimmed = line.trim();
          if (!trimmed) return null;

          if (trimmed.startsWith('🌱') || trimmed.toLowerCase().includes('problem')) {
            return (
              <div
                key={idx}
                className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-950 dark:text-amber-200 font-medium"
              >
                <div className="flex items-center gap-2 font-bold text-amber-700 dark:text-amber-400 mb-0.5 text-xs">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{language === 'mr' ? 'समस्या (Problem)' : language === 'hi' ? 'समस्या' : 'Diagnosed Problem'}</span>
                </div>
                <div>{trimmed.replace(/^🌱\s*(Problem\s*(\(समस्या\))?:\s*)?/i, '')}</div>
              </div>
            );
          }

          if (trimmed.startsWith('✅') || trimmed.toLowerCase().includes('करा') || trimmed.toLowerCase().includes('what to do') || trimmed.toLowerCase().includes('करें')) {
            return (
              <div
                key={idx}
                className="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-950 dark:text-emerald-100 font-medium"
              >
                <div className="flex items-center gap-2 font-bold text-emerald-700 dark:text-emerald-300 mb-0.5 text-xs">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{language === 'mr' ? 'आता काय करा (Action Steps)' : language === 'hi' ? 'क्या करें' : 'Immediate Action Steps'}</span>
                </div>
                <div>{trimmed.replace(/^✅\s*(आता काय करा:\s*|क्या करें:\s*|What to do:\s*)?/i, '')}</div>
              </div>
            );
          }

          if (trimmed.startsWith('🚫') || trimmed.toLowerCase().includes('हे करू नका') || trimmed.toLowerCase().includes('not to do') || trimmed.toLowerCase().includes('न करें')) {
            return (
              <div
                key={idx}
                className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-950 dark:text-rose-200 font-medium"
              >
                <div className="flex items-center gap-2 font-bold text-rose-700 dark:text-rose-400 mb-0.5 text-xs">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{language === 'mr' ? 'हे करू नका (Precaution)' : language === 'hi' ? 'यह न करें' : 'Do NOT Do This'}</span>
                </div>
                <div>{trimmed.replace(/^🚫\s*(हे करू नका:\s*|यह न करें:\s*|What NOT to do:\s*|सल्ला:\s*)?/i, '')}</div>
              </div>
            );
          }

          return (
            <div key={idx} className="leading-relaxed text-slate-800 dark:text-emerald-100">
              {trimmed}
            </div>
          );
        })}
      </div>
    );
  };

  if (activeModal !== 'askAi') return null;

  return (
    <div
      id="askai-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-emerald-950/85 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.2 }}
        className="relative w-full max-w-4xl h-[92vh] max-h-[820px] rounded-3xl bg-white dark:bg-[#051c12] border border-emerald-500/30 shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Top Header */}
        <div className="px-4 sm:px-6 py-3.5 border-b border-emerald-500/20 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 dark:from-emerald-950/90 dark:via-teal-950/80 dark:to-emerald-950/90 flex flex-wrap items-center justify-between gap-3">
          {/* Title & Status */}
          <div className="flex items-center gap-3">
            <div className="relative w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-emerald-400 text-white flex items-center justify-center shadow-md">
              <Bot className="w-6 h-6" />
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-white dark:border-emerald-950 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-emerald-950 dark:text-white font-outfit">
                  {language === 'mr' ? 'किसान व्हॉइस AI (बोलून विचारा)' : language === 'hi' ? 'किसान वॉयस AI' : 'KisanAI Voice Agronomist'}
                </h3>
                <span className="hidden sm:inline-block px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 border border-emerald-500/30">
                  Voice-First
                </span>
              </div>
              <p className="text-xs text-emerald-700/80 dark:text-emerald-400/80 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                {language === 'mr' ? 'शेतकरी बोलेल → AI उत्तर बोलेल' : 'Speak in your language • Listen to AI'}
              </p>
            </div>
          </div>

          {/* Quick Language Buttons + Controls */}
          <div className="flex items-center gap-2 ml-auto">
            {/* Language Selector Pills */}
            <div className="flex items-center bg-white/80 dark:bg-emerald-900/60 p-1 rounded-xl border border-emerald-500/20 shadow-2xs">
              {(['mr', 'hi', 'en'] as LanguageCode[]).map((lCode) => (
                <button
                  key={lCode}
                  onClick={() => setLanguage(lCode)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    language === lCode
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-emerald-300 hover:text-emerald-600 dark:hover:text-emerald-100'
                  }`}
                >
                  {lCode === 'mr' ? 'मराठी' : lCode === 'hi' ? 'हिन्दी' : 'English'}
                </button>
              ))}
            </div>

            {/* Speech Rate Control */}
            <div className="hidden sm:flex items-center gap-1 bg-white/80 dark:bg-emerald-900/60 px-2 py-1 rounded-xl border border-emerald-500/20 text-xs">
              <span className="text-[11px] font-semibold text-slate-500 dark:text-emerald-300">वेग:</span>
              <button
                onClick={() => setSpeechRate((r) => (r === 0.75 ? 1.0 : r === 1.0 ? 1.25 : 0.75))}
                className="font-bold text-emerald-700 dark:text-emerald-300 px-1 hover:underline cursor-pointer"
                title="Change Speech Speed"
              >
                {speechRate}x
              </button>
            </div>

            {/* Auto Speak Toggle */}
            <button
              onClick={() => {
                if (playingMessageId) stopSpeech();
                setAutoSpeak(!autoSpeak);
              }}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                autoSpeak
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-700 dark:text-emerald-300'
                  : 'bg-zinc-100 dark:bg-zinc-800 border-zinc-300 dark:border-zinc-700 text-zinc-400'
              }`}
              title={autoSpeak ? 'Auto Voice Playback: ON' : 'Auto Voice Playback: OFF'}
            >
              {autoSpeak ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Close Button */}
            <button
              id="close-askai-modal-btn"
              onClick={() => {
                stopSpeech();
                handleStopListening();
                closeModal();
              }}
              className="p-2 rounded-xl bg-emerald-100/70 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-200 hover:bg-emerald-200 dark:hover:bg-emerald-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* TOP HERO VOICE INTERACTION CARD: The Central Large Microphone */}
        <div className="p-4 sm:p-6 bg-gradient-to-b from-emerald-500/10 via-teal-500/5 to-transparent border-b border-emerald-500/15 flex flex-col items-center justify-center text-center relative">
          {/* Animated Glow Rings behind Central Mic */}
          <div className="relative flex flex-col items-center justify-center my-1">
            {isRecording && (
              <>
                <motion.div
                  animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0.1, 0.6] }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
                  className="absolute w-36 h-36 rounded-full bg-red-500/20 -z-10"
                />
                <motion.div
                  animate={{ scale: [1, 1.7, 1], opacity: [0.4, 0.05, 0.4] }}
                  transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut', delay: 0.2 }}
                  className="absolute w-44 h-44 rounded-full bg-emerald-500/15 -z-10"
                />
              </>
            )}

            {/* Main Central Microphone Button */}
            <button
              id="central-voice-mic-btn"
              onClick={isRecording ? handleStopListening : handleStartListening}
              className={`group relative flex items-center justify-center gap-3 px-8 py-4 sm:px-10 sm:py-5 rounded-full font-extrabold text-base sm:text-lg shadow-xl cursor-pointer transition-all duration-300 transform active:scale-95 ${
                isRecording
                  ? 'bg-gradient-to-r from-red-600 via-rose-500 to-red-600 text-white shadow-red-500/40 border-2 border-red-300 scale-105'
                  : 'bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-700 hover:from-emerald-500 hover:to-teal-400 text-white shadow-emerald-700/35 hover:shadow-emerald-600/50 border-2 border-emerald-400/40 hover:scale-105'
              }`}
            >
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center ${
                  isRecording ? 'bg-white text-red-600 animate-pulse' : 'bg-white/20 text-white group-hover:scale-110'
                }`}
              >
                {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </div>

              <span>
                {isRecording
                  ? language === 'mr'
                    ? 'मी ऐकत आहे... (थांबवा)'
                    : language === 'hi'
                    ? 'मैं सुन रहा हूँ... (रोकें)'
                    : 'Listening... (Tap to Stop)'
                  : language === 'mr'
                  ? '🎤 बोलून विचारा'
                  : language === 'hi'
                  ? '🎤 बोलकर पूछें'
                  : '🎤 Tap & Speak'}
              </span>
            </button>
          </div>

          {/* Listening Live Waveform or Status Subtitle */}
          <div className="mt-3 min-h-[28px] flex items-center justify-center">
            {isRecording ? (
              <div className="flex items-center gap-2 text-red-600 dark:text-red-400 font-bold text-xs sm:text-sm">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
                </span>
                <span>
                  {language === 'mr'
                    ? '“मी ऐकत आहे... आपला शेतीविषयक प्रश्न बोला”'
                    : language === 'hi'
                    ? '“मैं सुन रहा हूँ... अपनी भाषा में सवाल बोलें”'
                    : '“Listening to your voice... Speak your agricultural query”'}
                </span>

                {/* Animated Waveform Visualizer */}
                <div className="flex items-center gap-1 ml-2">
                  {[16, 28, 20, 36, 24, 40, 18, 30, 22].map((h, idx) => (
                    <motion.div
                      key={idx}
                      animate={{ height: [6, h, 6] }}
                      transition={{ duration: 0.5, repeat: Infinity, delay: idx * 0.06 }}
                      className="w-1 bg-red-500 dark:bg-red-400 rounded-full"
                    />
                  ))}
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-600 dark:text-emerald-300/80 max-w-md">
                {language === 'mr'
                  ? 'शेतकरी बांधवांसाठी सोपा व्हॉइस असिस्टंट • इंग्रजी वाचण्याची गरज नाही'
                  : language === 'hi'
                  ? 'किसान भाइयों के लिए आसान वॉयस असिस्टेंट • टाइप करने की जरूरत नहीं'
                  : 'Farmer-friendly voice assistant • No typing or English required'}
              </p>
            )}
          </div>

          {/* Recognized Live Speech Preview & Submit Strip */}
          {inputQuery && !isRecording && (
            <motion.div
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-3 w-full max-w-xl p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 text-left"
            >
              <div className="flex-1 min-w-0">
                <div className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                  {language === 'mr' ? 'तुमचा ओळखलेला प्रश्न:' : 'Recognized Question:'}
                </div>
                {isEditingRecognized ? (
                  <input
                    type="text"
                    value={inputQuery}
                    onChange={(e) => setInputQuery(e.target.value)}
                    className="w-full text-xs font-semibold bg-white dark:bg-emerald-950 p-1.5 rounded-lg border border-emerald-500/40 text-emerald-950 dark:text-white mt-1"
                    autoFocus
                  />
                ) : (
                  <div className="text-xs sm:text-sm font-semibold text-emerald-950 dark:text-white truncate">
                    “{inputQuery}”
                  </div>
                )}
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => setIsEditingRecognized(!isEditingRecognized)}
                  className="p-2 rounded-xl bg-white dark:bg-emerald-900/60 text-slate-700 dark:text-emerald-200 hover:bg-emerald-100 text-xs flex items-center gap-1 font-medium cursor-pointer"
                  title="Edit recognized text"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{isEditingRecognized ? 'Done' : 'Edit'}</span>
                </button>
                <button
                  onClick={() => handleSendQuery()}
                  disabled={isLoading}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{language === 'mr' ? 'विचारा (Submit)' : 'Ask AI'}</span>
                </button>
              </div>
            </motion.div>
          )}

          {/* Quick Voice Prompt Badges (1-Tap Test in Marathi / Hindi / English) */}
          <div className="mt-3 flex flex-wrap items-center justify-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-emerald-400/80 mr-1 flex items-center gap-1">
              <Flame className="w-3 h-3 text-amber-500" />
              {language === 'mr' ? 'उदाहरणे:' : 'Try asking:'}
            </span>
            {(language === 'mr'
              ? [
                  'माझ्या कापसाच्या पानांवर पिवळे डाग पडले आहेत, काय करू?',
                  'सोयाबीनवर अळी पडली आहे, कोणती फवारणी करू?',
                  'आजचे लातूर व अकोला मंडीतील भाव काय आहेत?',
                  'कांद्याला खताचा पहिला हप्ता कोणता द्यावा?',
                ]
              : language === 'hi'
              ? [
                  'कपास के पत्तों पर पीले धब्बे हैं, क्या स्प्रे करें?',
                  'सोयाबीन में इल्ली के लिए कौन सा कीटनाशक डालें?',
                  'आज का सोयाबीन और गेहूं का मंडी भाव क्या है?',
                  'प्याज में पहला खाद कौन सा डालें?',
                ]
              : [
                  'My cotton leaves have yellow spots, what should I spray?',
                  'What is the best spray for caterpillar in soybean?',
                  'What are today’s soybean and cotton mandi rates?',
                  'What is the recommended fertilizer dose for onion?',
                ]
            ).map((prompt, pIdx) => (
              <button
                key={pIdx}
                onClick={() => handleSendQuery(prompt)}
                className="px-2.5 py-1 text-[11px] font-medium rounded-full bg-white dark:bg-emerald-950/90 border border-emerald-500/25 text-slate-700 dark:text-emerald-200 hover:bg-emerald-500 hover:text-white dark:hover:bg-emerald-600 transition-all cursor-pointer text-left shadow-2xs"
              >
                “{prompt.length > 38 ? prompt.substring(0, 36) + '...' : prompt}”
              </button>
            ))}
          </div>
        </div>

        {/* Conversation History & Structured Cards */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            const isPlayingThis = playingMessageId === msg.id;

            return (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shrink-0 mt-1 shadow-md">
                    <Sprout className="w-5 h-5" />
                  </div>
                )}

                <div className={`max-w-[92%] sm:max-w-[85%] space-y-2 ${isUser ? 'items-end' : 'items-start'}`}>
                  <div
                    className={`p-4 sm:p-5 rounded-3xl shadow-sm ${
                      isUser
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-br-xs'
                        : 'bg-white dark:bg-emerald-900/40 text-emerald-950 dark:text-emerald-100 border border-emerald-500/25 rounded-bl-xs'
                    }`}
                  >
                    {/* Message Content */}
                    {isUser ? (
                      <div className="text-sm font-medium leading-relaxed">{msg.text}</div>
                    ) : (
                      renderStructuredAnswer(msg.text)
                    )}

                    {/* Dedicated Text-To-Speech (🔊 ऐका) Control Bar on every Assistant Response */}
                    {!isUser && msg.audioAvailable && (
                      <div className="mt-4 pt-3 border-t border-emerald-500/20 flex flex-wrap items-center justify-between gap-2">
                        {/* Primary Big "🔊 ऐका" Play/Pause Button */}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              if (isPlayingThis) {
                                if (isPaused) playSpeech(msg.text, msg.id);
                                else pauseSpeech();
                              } else {
                                playSpeech(msg.text, msg.id);
                              }
                            }}
                            className={`px-3.5 py-1.5 rounded-full font-bold text-xs flex items-center gap-1.5 shadow-xs transition-all cursor-pointer ${
                              isPlayingThis && !isPaused
                                ? 'bg-amber-500 text-white hover:bg-amber-600 animate-pulse'
                                : 'bg-emerald-600 text-white hover:bg-emerald-500'
                            }`}
                          >
                            {isPlayingThis && !isPaused ? (
                              <>
                                <Pause className="w-3.5 h-3.5" />
                                <span>{language === 'mr' ? 'थांबवा (Pause)' : 'Pause'}</span>
                              </>
                            ) : (
                              <>
                                <Volume2 className="w-3.5 h-3.5" />
                                <span>{language === 'mr' ? '🔊 ऐका (Listen)' : language === 'hi' ? '🔊 सुनें' : '🔊 Listen'}</span>
                              </>
                            )}
                          </button>

                          {/* Stop button if playing */}
                          {isPlayingThis && (
                            <button
                              onClick={stopSpeech}
                              className="p-1.5 rounded-full bg-rose-500/20 text-rose-600 dark:text-rose-400 hover:bg-rose-500/30 text-xs flex items-center gap-1 font-semibold cursor-pointer"
                              title="Stop Voice"
                            >
                              <Square className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Replay Button */}
                          <button
                            onClick={() => playSpeech(msg.text, msg.id)}
                            className="p-1.5 rounded-full bg-slate-100 dark:bg-emerald-950/80 text-slate-600 dark:text-emerald-300 hover:bg-emerald-100 text-xs flex items-center gap-1 font-semibold cursor-pointer"
                            title="Replay Voice"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Speaking Waveform Animation */}
                        {isPlayingThis && !isPaused && (
                          <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold text-[11px]">
                            <span>{language === 'mr' ? 'बोलत आहे...' : 'Speaking...'}</span>
                            <div className="flex items-center gap-0.5">
                              {[12, 20, 14, 24, 16].map((h, i) => (
                                <motion.div
                                  key={i}
                                  animate={{ height: [4, h, 4] }}
                                  transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.1 }}
                                  className="w-1 bg-emerald-500 rounded-full"
                                />
                              ))}
                            </div>
                          </div>
                        )}

                        <span className="text-[10px] text-slate-400">{msg.timestamp}</span>
                      </div>
                    )}
                  </div>

                  {/* Suggested follow-up voice questions */}
                  {msg.quickActions && msg.quickActions.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {msg.quickActions.map((qa, i) => (
                        <button
                          key={i}
                          onClick={() => handleSendQuery(qa.action)}
                          className="px-3 py-1 text-xs rounded-full bg-white dark:bg-emerald-950/80 border border-emerald-500/25 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-500 hover:text-white transition-all shadow-2xs text-left cursor-pointer"
                        >
                          {qa.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-9 h-9 rounded-2xl bg-slate-200 dark:bg-emerald-800 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0 mt-1">
                    <User className="w-5 h-5" />
                  </div>
                )}
              </motion.div>
            );
          })}

          {/* AI Thinking Animation */}
          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-3 items-center text-xs text-emerald-600 dark:text-emerald-400 font-medium"
            >
              <div className="w-9 h-9 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-md">
                <Sparkles className="w-5 h-5 animate-spin" />
              </div>
              <div className="p-3.5 rounded-2xl bg-emerald-50/80 dark:bg-emerald-900/40 border border-emerald-500/20 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '0.2s' }} />
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '0.4s' }} />
                <span className="font-semibold text-emerald-900 dark:text-emerald-200">
                  {language === 'mr'
                    ? 'किसान AI कृषी तज्ञांशी चर्चा करत आहे...'
                    : language === 'hi'
                    ? 'किसान AI उत्तर तैयार कर रहा है...'
                    : 'KisanAI is consulting crop science database...'}
                </span>
              </div>
            </motion.div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Bottom Fallback Input Bar (Supports both typing and mic) */}
        <div className="p-3 sm:p-4 border-t border-emerald-500/20 bg-white/90 dark:bg-emerald-950/90 backdrop-blur-md">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendQuery();
            }}
            className="flex items-center gap-2"
          >
            {/* Mic trigger */}
            <button
              type="button"
              id="bottom-voice-mic-trigger"
              onClick={isRecording ? handleStopListening : handleStartListening}
              className={`p-3 rounded-2xl text-white transition-all cursor-pointer shadow-md ${
                isRecording
                  ? 'bg-red-500 hover:bg-red-600 animate-pulse'
                  : 'bg-emerald-600 hover:bg-emerald-500'
              }`}
              title={isRecording ? 'Stop Recording' : 'Speak to KisanAI'}
            >
              {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            {/* Text Input for typing alternative */}
            <input
              type="text"
              id="voice-chat-query-input"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder={
                language === 'mr'
                  ? 'किंवा येथे प्रश्न टाईप करा (उदा. कापूस खत, सोयाबीन भाव...)'
                  : language === 'hi'
                  ? 'या यहाँ सवाल टाइप करें (उदा. गेहूं में खाद, कपास मंडी भाव...)'
                  : 'Or type your question here...'
              }
              className="flex-1 px-4 py-3 rounded-2xl bg-emerald-50/70 dark:bg-emerald-900/30 border border-emerald-500/25 text-emerald-950 dark:text-emerald-100 placeholder-emerald-700/50 dark:placeholder-emerald-400/50 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />

            {/* Send Button */}
            <button
              type="submit"
              id="send-voice-chat-btn"
              disabled={!inputQuery.trim() || isLoading}
              className="p-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white font-bold transition-all shadow-md cursor-pointer disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  );
};
