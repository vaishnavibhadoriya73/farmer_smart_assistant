import { useState, useEffect, useCallback } from 'react';
import { governmentSchemesService, SchemeFilterOptions, EligibilityAssistantInput, SchemeMatchResult } from '../services/governmentSchemesService';
import { DetailedGovtSchemeRecord } from '../data/schemesDatabase';
import { StateInfo } from '../data/indianStates';

export function useGovernmentSchemes(initialFilters?: SchemeFilterOptions) {
  const [schemes, setSchemes] = useState<DetailedGovtSchemeRecord[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [source, setSource] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<SchemeFilterOptions>(initialFilters || { state: 'All', category: 'All', schemeType: 'All' });
  const [selectedStateInfo, setSelectedStateInfo] = useState<StateInfo | undefined>(undefined);
  const [wizardResults, setWizardResults] = useState<SchemeMatchResult[]>([]);

  const fetchSchemes = useCallback(async (currentFilters: SchemeFilterOptions) => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await governmentSchemesService.getSchemes(currentFilters);
      setSchemes(data.schemes);
      setTotalCount(data.totalCount);
      setLastUpdated(data.lastUpdated);
      setSource(data.source);

      if (currentFilters.state && currentFilters.state !== 'All') {
        const stateOverview = governmentSchemesService.getStateExplorerOverview(currentFilters.state);
        setSelectedStateInfo(stateOverview.stateInfo);
      } else {
        setSelectedStateInfo(undefined);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch government schemes');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSchemes(filters);
  }, [filters, fetchSchemes]);

  const updateFilters = (newFilters: Partial<SchemeFilterOptions>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  const retryFetch = () => {
    fetchSchemes(filters);
  };

  const runEligibilityWizard = (input: EligibilityAssistantInput) => {
    const results = governmentSchemesService.calculateEligibleSchemes(input);
    setWizardResults(results);
    return results;
  };

  const getStatesList = () => governmentSchemesService.getStatesList();

  return {
    schemes,
    totalCount,
    lastUpdated,
    source,
    isLoading,
    error,
    filters,
    selectedStateInfo,
    wizardResults,
    updateFilters,
    retryFetch,
    runEligibilityWizard,
    getStatesList
  };
}
