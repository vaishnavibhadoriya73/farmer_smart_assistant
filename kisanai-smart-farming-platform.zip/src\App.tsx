import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { HeroSection } from './components/HeroSection';
import { StatsSection } from './components/StatsSection';
import { FeaturesSection } from './components/FeaturesSection';
import { AboutSection } from './components/AboutSection';
import { SupportSection } from './components/SupportSection';
import { MyCropView } from './components/MyCropView';
import { FarmerProfileView } from './components/FarmerProfileView';
import { FarmerModeView } from './components/FarmerModeView';
import { CentralFarmerDashboard } from './components/CentralFarmerDashboard';
import { MobileBottomNav } from './components/MobileBottomNav';
import { AskAiModal } from './components/AskAiModal';
import { DiagnoseModal } from './components/DiagnoseModal';
import { MandiPricesModal } from './components/MandiPricesModal';
import { WeatherModal } from './components/WeatherModal';
import { SoilHealthModal } from './components/SoilHealthModal';
import { SchemesModal } from './components/SchemesModal';
import { FarmerLoginModal } from './components/FarmerLoginModal';
import { OnboardingModal } from './components/OnboardingModal';
import { CropRecommendationModal } from './components/CropRecommendationModal';
import { CropLifecycleModal } from './components/CropLifecycleModal';
import { YieldPredictionModal } from './components/YieldPredictionModal';
import { ProfitPredictionModal } from './components/ProfitPredictionModal';
import { MarketIntelligenceModal } from './components/MarketIntelligenceModal';
import { GpsLocationTrackerModal } from './components/GpsLocationTrackerModal';
import { FarmerSupplyChainModal } from './components/FarmerSupplyChainModal';
import { NotificationCenterModal } from './components/NotificationCenterModal';
import { OfflineNetworkBanner } from './components/OfflineNetworkBanner';
import { FarmerOnboardingFlow } from './components/FarmerOnboardingFlow';
import { KisanLogo } from './components/KisanLogo';
import {
  Mic,
  Sprout,
  Menu,
  ShieldCheck,
  HeartHandshake,
} from 'lucide-react';

const MainLayout: React.FC = () => {
  const { activeTab, setActiveTab, openModal, appMode, setAppMode, theme, isLoggedIn, isAuthChecking } = useApp();
  const [isOpenMobileSidebar, setIsOpenMobileSidebar] = useState<boolean>(false);
  const [activeDashboardView, setActiveDashboardView] = useState<string>('dashboard');

  // While Firebase Authentication is checking initial auth state
  if (isAuthChecking) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#f4f7f5] text-slate-800">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-xl shadow-emerald-600/20 animate-pulse">
            <Sprout className="w-9 h-9 text-white" />
          </div>
          <div className="text-center space-y-1">
            <h2 className="text-xl font-black tracking-wide text-emerald-800">KisanAI</h2>
            <p className="text-xs text-emerald-700/70">Checking authentication...</p>
          </div>
        </div>
      </div>
    );
  }

  // If farmer is not registered/logged in, show the Registration + Onboarding flow
  if (!isLoggedIn) {
    return <FarmerOnboardingFlow />;
  }

  return (
    <div className="min-h-screen flex bg-[#f4f7f5] text-slate-800 antialiased selection:bg-emerald-600 selection:text-white">
      <OfflineNetworkBanner />

      {/* Sidebar Navigation */}
      <Sidebar
        activeView={activeDashboardView}
        onNavigate={(viewKey) => {
          if (viewKey === 'home') {
            setActiveTab('home');
            setActiveDashboardView('home');
          } else {
            setActiveDashboardView(viewKey);
          }
        }}
        isOpenMobile={isOpenMobileSidebar}
        setIsOpenMobile={setIsOpenMobileSidebar}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* Top Header Navbar */}
        <Navbar />

        {/* Dynamic Body Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
          {activeDashboardView === 'dashboard' ? (
            <CentralFarmerDashboard />
          ) : activeTab === 'home' || activeDashboardView === 'home' ? (
            <div className="space-y-4">
              <HeroSection />
              <StatsSection />
              <FeaturesSection />
              <AboutSection />
              <SupportSection />
            </div>
          ) : activeTab === 'mycrop' ? (
            <MyCropView />
          ) : activeTab === 'profile' ? (
            <FarmerProfileView />
          ) : (
            <CentralFarmerDashboard />
          )}
        </main>

        {/* Modern Footer */}
        <footer id="app-footer" className="border-t border-emerald-100 bg-white/90 backdrop-blur-xl pt-8 pb-20 md:pb-8 text-xs text-slate-500">
          <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
            <KisanLogo size="sm" showTagline={true} />
            <p className="text-center md:text-right font-medium">
              © 2026 KisanAI Smart Agriculture & AI Farming Platform. All rights reserved.
            </p>
          </div>
        </footer>

      </div>

      {/* Modals Container */}
      <AskAiModal />
      <DiagnoseModal />
      <MandiPricesModal />
      <WeatherModal />
      <SoilHealthModal />
      <SchemesModal />
      <FarmerLoginModal />
      <OnboardingModal />
      <CropRecommendationModal />
      <CropLifecycleModal />
      <YieldPredictionModal />
      <ProfitPredictionModal />
      <MarketIntelligenceModal />
      <GpsLocationTrackerModal />
      <FarmerSupplyChainModal />
      <NotificationCenterModal />

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav />
    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}

export default App;
